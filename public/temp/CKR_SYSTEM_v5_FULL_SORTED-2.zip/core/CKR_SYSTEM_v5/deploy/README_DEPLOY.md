# Deploy Guide
1) Upload this folder to your GitHub repo.
2) In Lovable → Knowledge → Import, upload CKR_SYSTEM_v5.zip.
3) Apply Supabase schema from /schema.
4) Confirm GWA files loaded in your agent config.
