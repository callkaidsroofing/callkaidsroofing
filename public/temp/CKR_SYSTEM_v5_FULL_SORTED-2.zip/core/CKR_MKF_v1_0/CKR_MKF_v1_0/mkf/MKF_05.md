# Services & SOP Summary

*Updated:* 31 Oct 2025

**Core procedures:** Cleaning → rebedding & pointing (SupaPoint) → primer + 2 coats Premcoat → valleys/flashings → broken tile allowance.
**Site rules:** Pre‑work safety assessment; photo evidence mandate; tidy handover.

## Unabridged Source — CKR_05_SERVICE_HIERARCHY_&_SOP_SUMMARY.yaml

```
# LOVABLE KNOWLEDGE FILE 5/5: CKR_05_SERVICE_HIERARCHY_&_SOP_SUMMARY (SITEMAP INTEGRATION)
# VERSION: 2.0 (Redesigned to SITEMAP)
# ABSOLUTE_IMPORTANCE_LEVEL: CRITICAL - THIS FILE GOVERNS PAGE LOGIC AND CONTENT HIERARCHY.
# PURPOSE: Maps SOPs to the exact page URLs in the sitemap to ensure content is targeted, verifiable, and authoritative.
# SOURCE KFS: KF_01, KF_03, KF_05, KF_07, KF_02, SITEMAP.XML

---

MANDATORY_PAGE_STRUCTURE:
  # Mandate: The AI must use the following URLs as the canonical page destinations.
  - PAGE_ID: HOME_PAGE
    URL_MAPPING: "https://callkaidsroofing.com.au/"
    TITLE: "Call Kaids Roofing | SE Melbourne's Proof-Driven Roof Experts: *Proof In Every Roof*"
    FOCUS: "Priority 1.0. The central hub. Content must feature the **3-Step Process Summary**, the **20-Year Warranty** as the anchor, and link immediately to the high-priority localized service pages."

  - PAGE_ID: GALLERY_CASE_STUDIES
    URL_MAPPING: "https://callkaidsroofing.com.au/gallery"
    TITLE: "Proof In Every Roof | Local Before & After Gallery"
    FOCUS: "Priority 0.8. Content is purely evidentiary. Must load and display data directly from the CKR_04 Proof Points, organized by **Suburb** and **Job Type** to enhance local SEO authority."

  - PAGE_ID: ABOUT_US
    URL_MAPPING: "https://callkaidsroofing.com.au/about"
    TITLE: "Meet The Expert Consultant Team | Our Local SE Melbourne Story"
    FOCUS: "Priority 0.9. Content must detail the **Local Expertise** (SE Melbourne specialization) and **Accountability** (Insurance/ABN/Warranty philosophy) pillars."

## OPERATIONAL_CONTENT_MAPPING (SERVICE PAGES)

### GROUP_1_FLAGSHIP_RESTORATION (HIGH PRIORITY)

  - PAGE_ID: SERVICE_ROOF_RESTORATION_GENERAL
    URL_MAPPING: "https://callkaidsroofing.com.au/services/roof-restoration"
    TITLE: "Complete Tile & Metal Roof Restoration System | 15 & 20-Year Warranty"
    FOCUS: "The main authority page for the service. Content must detail the **FOUR_PHASE_PROCESS_MANDATE** below, framing it as the systemic solution to David's roofing anxiety."
    HIGH_PRIORITY_LOCALIZED_PAGES: 
      - "https://callkaidsroofing.com.au/services/roof-restoration-berwick"
      - "https://callkaidsroofing.com.au/services/roof-restoration-cranbourne"
      - "https://callkaidsroofing.com.au/services/roof-restoration-pakenham"
      - "https://callkaidsroofing.com.au/services/roof-restoration-clyde-north"
      # Mandate: These localized pages must aggressively target the specific suburb keywords from CKR_03 and feature a testimonial from that suburb (CKR_04).

### GROUP_2_COATING_SPECIALTY (HIGH PRIORITY)

  - PAGE_ID: SERVICE_ROOF_PAINTING_GENERAL
    URL_MAPPING: "https://callkaidsroofing.com.au/services/roof-painting"
    TITLE: "Professional Roof Painting & Re-Coating | Premium Membrane Systems"
    FOCUS: "Differentiates coating from amateur paint jobs. Must focus on **Preparation** (SOP-M2/T1) and the **Material Tier** (COAT\_PAINT\_STD\_20L vs. COAT\_PAINT\_PREM\_15L) as the source of durability and the **20-year warranty**."
    HIGH_PRIORITY_LOCALIZED_PAGES:
      - "https://callkaidsroofing.com.au/services/roof-painting-cranbourne"
      - "https://callkaidsroofing.com.au/services/roof-painting-pakenham"

### GROUP_3_REPAIR_AND_DIAGNOSTICS (HIGH PRIORITY)

  - PAGE_ID: SERVICE_ROOF_REPAIRS_GENERAL
    URL_MAPPING: "https://callkaidsroofing.com.au/services/roof-repairs"
    TITLE: "Targeted Roof Repair & Structural Integrity Restoration"
    FOCUS: "The master hub for all repair sub-pages below. Must feature the **Expert Consultant** persona by emphasizing scientific diagnosis over patching."

  - PAGE_ID: SERVICE_LEAK_DETECTION
    URL_MAPPING: "https://callkaidsroofing.com.au/services/leak-detection"
    TITLE: "Scientific Leak Detection & Permanent Repair | Stop Recurring Leaks"
    FOCUS: "Must detail the **5-Stage Diagnostic Funnel** and the use of **Controlled Water Testing** (Protocol U-2R) to find the *true* source, not just the symptom."

  - PAGE_ID: SERVICE_ROOF_REPOINTING
    URL_MAPPING: "https://callkaidsroofing.com.au/services/roof-repointing"
    TITLE: "Master-Level Ridge Capping Re-Pointing & Re-Bedding"
    FOCUS: "Highlights the structural nature of the work. Must explicitly mention **SOP-T3** procedures, including **100% mortar removal**, new bedding, and **Weep Hole Formation**."

  - PAGE_ID: SERVICE_VALLEY_IRON_REPLACEMENT
    URL_MAPPING: "https://callkaidsroofing.com.au/services/valley-iron-replacement"
    TITLE: "Corrosion-Proof Valley Iron Replacement"
    FOCUS: "Content must focus on rust prevention and the process of **replacing** failed valley irons rather than temporary patch jobs. Reference Narre Warren Case Study (CKR_04)."

  - PAGE_ID: SERVICE_TILE_REPLACEMENT
    URL_MAPPING: "https://callkaidsroofing.com.au/services/tile-replacement"
    TITLE: "Broken Tile Replacement: Surgical Integrity Restoration"
    FOCUS: "Content must emphasize the CKR commitment to **sourcing the right, matching profile** (SOP-T2) and using **proper technique** (lifting surrounding tiles, checking sarking) to maintain system integrity."

  - PAGE_ID: SERVICE_GUTTER_CLEANING
    URL_MAPPING: "https://callkaidsroofing.com.au/services/gutter-cleaning"
    TITLE: "Professional Gutter Cleaning & Drainage Restoration (SOP-GR5)"
    FOCUS: "Focus on preventative maintenance. Must detail the **High-Volume Flush** and **Downpipe Verification Flush** (SOP-GR5) to prove the *entire* system is working, not just the visible part."

## FOUR_PHASE_PROCESS_MANDATE_FOR_WEB_COPY
  # Mandate: All content blocks for restoration/painting services must reference this logical flow:
  PHASE_1: "Diagnosis (Evidence Trinity)"
  PHASE_2: "Preparation (Absolute Clean & Structural Repair)"
  PHASE_3: "Protection (3-Coat System & Sealing Integrity)"
  PHASE_4: "Handover (QA Checklist & Warranty Activation)"

```

## Unabridged Source — KF_03_-_05_SOP_ALL.txt

```
KNOWLEDGE FILE KF_03: STANDARD OPERATING PROCEDURES — TILE ROOFING (v3.1 MASTER EDITION)
WORD COUNT: 20,488
LAST UPDATED: 2025-10-06
TABLE OF CONTENTS
 * SECTION 1: PHILOSOPHY AND UNIVERSAL PROTOCOLS
   1.1. The CKR Philosophy for Tile Roof Workmanship: The Systemic Approach
   1.2. Protocol U-1: Pre-Work Site Safety Assessment & Establishment
   1.3. Protocol U-2: The Comprehensive Roof Health Check (The "Big Five" Inspection)
   1.4. Protocol U-3: The Photo-Documentation Mandate (The Evidence Trinity)
   1.5. Protocol U-4: Standard Tool & Equipment Checklist for Tile Roofs
 * SECTION 2: CORE TILE ROOFING PROCEDURES (THE CRAFTSMANSHIP SOPS)
   2.1. SOP-T1: High-Pressure Cleaning (v3.1)
   2.1.1. Objective & Scope: Achieving the "Absolute Clean" Standard
   2.1.2. Required Tools & Equipment
   2.1.3. The CKR 8-Step Cleaning Procedure
   2.1.4. Rationale & Technical Notes: The Science of the Tile Butt
   2.1.5. Specific Safety Protocols for High-Pressure Cleaning
   2.1.6. Quality Assurance Checklist
   2.1.7. Photo-Documentation Points
   2.2. SOP-T2: Broken Tile Replacement (v2.0)
   2.2.1. Objective & Scope: Surgical Replacement for System Integrity
   2.2.2. Required Tools & Materials
   2.2.3. The CKR 7-Step Tile Replacement Procedure
   2.2.4. Rationale & Technical Notes: Sourcing, Matching, and Securing
   2.2.5. Quality Assurance Checklist
   2.3. SOP-T3: Ridge Capping Restoration (v3.1 - Master Craftsmanship Edition)
   2.3.1. Objective & Scope: Master-Level Structural Reconstruction
   2.3.2. Required Tools & Materials (KF_02 Integration)
   2.3.3. Phase 1: Meticulous Preparation & Deconstruction
   2.3.4. Phase 2: Substrate Reconstruction & CKR Mortar Mixing
   2.3.5. Phase 3: Bedding, Alignment & Weep Hole Formation
   2.3.6. Phase 4: Professional Pointing Application & Finishing
   2.3.7. Rationale & Technical Notes: The Function of Weep Holes
   2.3.8. The Master Quality Assurance Checklist
   2.3.9. Photo-Documentation Points & Shot List
   2.4. SOP-T4: Full Tile Roof Restoration (Master SOP v3.1)
   2.4.1. Objective & Scope: Orchestrating the Complete Transformation
   2.4.2. The Conditional Master Procedure Flowchart
   2.4.3. Phase 1: Structural Repairs & Preparation (Workflows A & B)
   2.4.4. Phase 2: The CKR Surface Coating System (15 & 20-Year Tiers)
   2.4.5. Phase 3: Finalisation, Site Clean-up & Client Handover
   2.4.6. Rationale & Technical Notes: The Critical Path of Restoration
   2.4.7. The Master Quality Assurance Checklist for Full Restorations
 * SECTION 3: APPENDIX
   3.1. Appendix A: Common Tile Profiles in SE Melbourne (Photo Guide)
   3.2. Appendix B: Recommended Pressure Washer Settings & Nozzles
   3.3. Appendix C: Troubleshooting Common On-Site Issues
   3.4. Appendix D: Quick Reference QA Checklists for On-Site Use
SECTION 1: PHILOSOPHY AND UNIVERSAL PROTOCOLS
1.1. The CKR Philosophy for Tile Roof Workmanship: The Systemic Approach
Every procedure detailed in this master document is governed by the core principles laid out in KF_01_BRAND_CORE.md. For tile roofing projects, this philosophy is expressed through a systemic approach. We do not view a tile roof as a simple assembly of individual tiles; we see it as a complete, interconnected system designed to protect the client's most valuable asset. The tiles, the pointing, the bedding mortar, the flashings, and the underlying sarking are all codependent components. The failure of one small component—a single cracked tile or a metre of failing pointing—can and will compromise the integrity of the entire system. Therefore, our approach is always holistic, diagnostic, and focused on long-term durability.
 * Durability: Concrete and terracotta tiles have a long lifespan, but they are only as strong as their weakest link. Our procedures are designed to identify and rectify these weak links to ensure the entire roof system achieves its maximum potential life. We do not perform temporary "patches"; we perform systematic, durable repairs and restorations backed by our comprehensive 15-year or 20-year workmanship warranties. This is the ultimate expression of our commitment to durability.
 * Transparency & Education: A tile roof has a unique and often unfamiliar vocabulary ("pointing," "bedding," "weep holes"). Our role as expert consultants is to demystify the process for the client. Every step in these SOPs has a "Rationale" section, which provides the technical "why" behind our actions. All team members must be fluent in explaining this rationale in simple, clear terms, using the photographic evidence gathered as per Protocol U-3 to educate and empower the client.
 * Craftsmanship: The tangible difference between an amateur and a professional tile roofing job is found in the details. It is visible in the clean, uniform lines of the flexible pointing; the careful, surgical removal of a broken tile without damaging its neighbours; and the meticulous high-pressure clean that removes every trace of moss without scarring the tile's surface. These SOPs are designed to enforce that master level of craftsmanship on every job site, ensuring consistency and excellence. This is the physical application of our commitment to quality.
1.2. Protocol U-1: Pre-Work Site Safety Assessment & Establishment
Objective: To ensure every job site is 100% compliant with all WorkSafe Victoria standards and our own internal safety protocols before any work commences. This protocol is the first action on site and is absolutely non-negotiable.
Procedure:
 * Initial Site Walk-Around: Upon arrival, conduct a full perimeter walk-around of the property. Identify all potential ground-level hazards, including overhead power lines, uneven ground for ladder placement, garden furniture, water taps, and any other obstructions.
 * Establish Safe Access: Determine the single safest access point to the roof. This location must have firm, level ground and be clear of doorways and high-traffic paths.
 * Safety Equipment Check: Before unloading, conduct a visual inspection of all safety equipment to be used: harnesses for frays or damage, lanyards and rope lines for wear, and ladders for structural integrity.
 * Establish Exclusion Zone: Using safety cones and "WORK OVERHEAD" signage, establish a clear and unambiguous exclusion zone on the ground below the work area.
 * Client Briefing: Make contact with the client. Inform them that work is about to begin, confirm the location of the exclusion zone, and ensure that any pets are safely secured away from the work area. This is an act of Respect.
1.3. Protocol U-2: The Comprehensive Roof Health Check (The "Big Five" Inspection)
Objective: To conduct a systematic, thorough, and evidence-based inspection of the entire tile roof system. This diagnostic process forms the foundation of an accurate and honest quote, ensuring we address the root causes of any issues, not just the symptoms.
Procedure:
 * Systematic Grid Pattern: The inspection must be conducted in a logical pattern (e.g., clockwise, starting from the front left corner) to ensure no section of the roof is missed.
 * The "Big Five" Inspection Checklist: The technician must meticulously inspect and assess each of these five critical systems.
   * 1. The Tiles (The Armour): Inspect for cracks (from hairline to major), chips, breaks, and excessive surface porosity or moss/lichen growth. Quantify the number of broken tiles that require replacement.
   * 2. The Ridge Capping (The Spine): Visually inspect every metre of hip, ridge, and gable capping. Look for cracked, crumbling, or missing bedding mortar and flexible pointing. Physically (but gently) test ridge caps for any movement.
   * 3. The Valleys (The Arteries): Inspect valley irons for rust, corrosion, and blockages from leaves and debris. Check that tiles are correctly cut and clipped along the valley line.
   * 4. The Penetrations & Flashings (The Seals): Meticulously inspect the seals around all roof penetrations (Dektites, flues, vents) and the condition of all flashings (apron, step, chimney).
   * 5. The Gutters & Downpipes (The Drainage): Check gutters for blockages, rust, and proper alignment (fall). Ensure downpipe openings are clear.
 * Detailed Note-Taking: Record and quantify all findings on a standardized inspection sheet. (e.g., "Approx. 25 broken concrete tiles," "32 linear metres of ridge capping requires full re-bed and re-point.").
 * Mandatory Photo-Documentation: Every single identified issue must be documented with a clear, in-focus photograph as per the rules of Protocol U-3.
1.4. Protocol U-3: The Photo-Documentation Mandate (The Evidence Trinity)
Objective: To create an irrefutable, evidence-based record of the roof's condition before, during, and after our work. This protocol is the core of our "Proof In Every Roof" philosophy and is a non-negotiable part of every job.
The Three Stages of Photographic Evidence:
 * Stage 1: "Before" Photos (Diagnostic Evidence): During the Roof Health Check, take a minimum of 20-30 high-resolution photos. This must include wide-angle shots to show the overall condition and tight close-ups of every specific problem identified (e.g., a single cracked tile, a close-up of crumbling mortar). These photos justify our quote and educate the client.
 * Stage 2: "During" Photos (Process Verification): Take photos at key procedural milestones. Examples include a photo of the ridge line after all old mortar has been chipped away, a photo of the roof after the primer coat has been applied, or a photo of new valley irons installed before the tiles are re-laid. These photos prove we follow our SOPs.
 * Stage 3: "After" Photos (Quality Assurance): Upon project completion, re-take photos from the exact same angles as the "before" shots to create powerful, direct comparisons. Also include wide-angle "beauty shots" of the finished roof and close-ups that demonstrate the quality of the finish (e.g., the clean lines of new pointing). These photos are our proof of a job well done.
1.5. Protocol U-4: Standard Tool & Equipment Checklist for Tile Roofs
Objective: To ensure every CKR vehicle is a self-sufficient mobile workshop, equipped with the standard set of professionally maintained tools, safety gear, and consumables required for all common tile roof tasks.
Standard Vehicle Loadout:
 * Safety Equipment: Full complement of harnesses, ropes, lanyards, ladder locks, safety cones, "WORK OVERHEAD" signage, and a fully stocked first aid kit.
 * Power Tools:
   * High-pressure washer (minimum 4000psi) with multiple nozzles (turbo and fan) and extension hoses.
   * Industrial-grade angle grinder with diamond blades (for cutting tiles and grinding mortar).
   * Cordless impact driver.
   * Commercial leaf blower.
 * Hand Tools:
   * A full set of pointing trowels in various sizes.
   * Hammers (claw and brick).
   * Chisels (for mortar removal).
   * Tile lifting tools ("slaters").
   * Caulking gun.
   * Stiff and soft bristle brushes.
 * Consumables:
   * A stock of the most common replacement concrete and terracotta tiles found in SE Melbourne (see Appendix A).
   * Multiple bags of builder's sand and general-purpose cement.
   * Multiple tubs of approved flexible pointing compound in various common colours.
   * Additives: Plasticiser, Cement Oxide, Cement Accelerator.
 * Documentation & Admin:
   * Inspection forms and quote book.
   * High-resolution camera or smartphone dedicated for photo-documentation.
SECTION 2: CORE TILE ROOFING PROCEDURES (THE CRAFTSMANSHIP SOPS)
2.1. SOP-T1: High-Pressure Cleaning (v3.1)
2.1.1. Objective & Scope: Achieving the "Absolute Clean" Standard
Objective: To safely and meticulously remove all organic growth (moss, lichen, algae), ingrained dirt, and pollutants from the tile roof surface. The CKR "Absolute Clean" standard requires a visually uniform surface, completely free of contaminants, especially in the critical water channels and tile butts, to ensure maximum adhesion for subsequent coatings.
Scope: This procedure is the mandatory first step for all full roof restorations and is also a standalone maintenance service.
2.1.2. Required Tools & Equipment
 * High-pressure washer (min. 4000psi) with a full tank of petrol.
 * Nozzles: Turbo nozzle for heavy initial cleaning, multiple fan-jet nozzles (15 and 25 degrees) for controlled cleaning and rinsing.
 * Gutter protection guards (e.g., hessian sacks) to prevent downpipe blockages.
 * Heavy-duty tarps for protecting sensitive plants, air conditioning units, and painted surfaces.
 * Full PPE: Waterproof clothing, non-slip footwear, safety glasses/face shield, and gloves.
2.1.3. The CKR 8-Step Cleaning Procedure
 * Site Preparation: Execute Protocol U-1. Disconnect downpipes that lead to rainwater tanks. Protect all sensitive areas of the client's property with tarps. Place gutter guards in all downpipe openings.
 * Chemical Pre-treatment (If Required): For roofs with exceptionally heavy moss and lichen growth, apply an approved biocidal cleaning agent as per the manufacturer's instructions. Allow it to dwell for the specified time to kill the organic matter at its root.
 * Initial Roof Saturation: Before applying high pressure, use a low-pressure fan spray to completely saturate the entire roof surface with water. This helps to soften the dirt and moss, making it easier to remove.
 * Top-Down Cleaning Pattern: All high-pressure cleaning must begin at the highest point of the roof (the ridge line) and proceed downwards towards the gutters. Cleaning upwards will force water up and under the tile laps, which can flood the roof cavity. This is a critical safety and quality rule.
 * Nozzle Technique (The CKR Standard): The key to a professional clean is a detailed focus on the anatomy of the tile.
   * Clean the main face of each tile with the turbo or fan nozzle at a consistent distance.
   * Pay specific attention to the tip (or 'butt') and the water channel of each individual tile. The technician must angle the jet upwards slightly into this channel to blast out the unseen moss and lichen that is often visible as dark 'stripes' from the ground. Failure to do this is the mark of an amateur.
 * Gutter Flushing (Stage 1): During the main wash, periodically use the pressure washer on a lower setting to flush the dislodged debris from the gutters towards the downpipes. This prevents the gutters from overflowing and creating a mess on the ground.
 * Final Roof Rinse: Once the entire roof has been cleaned, switch to a wide fan nozzle and use low to medium pressure to thoroughly rinse the entire surface from top to bottom, ensuring all loosened debris is washed away.
 * Gutter & Site Clean-up (Stage 2): Once the roof is rinsed, remove the gutter guards. Manually scoop out any remaining solid debris from the gutters. Perform a final, thorough flush of all gutters and downpipes. Meticulously hose down any affected walls, windows, paths, and garden beds, leaving the client's property immaculate.
2.1.4. Rationale & Technical Notes: The Science of the Tile Butt
The most common point of failure for amateur roof cleaning is neglecting the underside lip, or "butt," of each tile. This area is a primary water channel and a perfect breeding ground for moss and lichen, as it's shaded and holds moisture. If this area isn't blasted clean with a focused, angled jet of water, two problems occur:
 * Aesthetic Failure: From the ground, the roof will have unsightly dark "stripes" where the hidden moss is still visible.
 * Coating Failure: When a coating system (paint) is applied, it will be applied over this residual organic matter. The paint will adhere to the moss, not the tile. Within a short period, the moss will die and detach, taking the new paint with it and causing widespread peeling and delamination. The "Absolute Clean" standard, with its focus on the tile butt, is therefore a prerequisite for the longevity of our 15-year and 20-year warranty coating systems.
2.1.5. Specific Safety Protocols for High-Pressure Cleaning
 * Extreme Slip Hazard: Wet tile roofs, especially those covered in moss and algae, are exceptionally slippery. All movement must be slow, deliberate, and methodical.
 * Fall Protection Mandatory: Full fall protection (harness, ropes, and appropriate anchors) is mandatory at all times. There are no exceptions.
 * Wand Kickback: Be aware of the powerful kickback from the pressure washer wand, especially when the trigger is first pulled. Maintain a firm grip with both hands and a stable stance.
 * Surface Damage: Never hold the jet too close to the tile surface, as the high pressure can etch or scar the face of older, softer tiles. Maintain a safe, consistent distance.
2.1.6. Quality Assurance Checklist
 * [ ] Is the entire roof surface a single, uniform colour with no remaining dark patches or stripes?
 * [ ] Have the tile butts and water channels been specifically and thoroughly cleaned?
 * [ ] Are all gutters and downpipes completely clear and verified to be flowing freely?
 * [ ] Has the client's property (walls, windows, paths) been thoroughly rinsed and left free of all debris and overspray?
2.1.7. Photo-Documentation Points
 * Before: Wide shots showing the extent of the moss/dirt. Close-ups of heavily soiled areas, especially the tile butts.
 * During: A single shot showing a half-cleaned section to create a dramatic contrast for the client.
 * After: Wide shots of the fully cleaned roof from the same angles as the "before" shots. Photos of the cleaned-out gutters.
2.2. SOP-T2: Broken Tile Replacement (v2.0)
2.2.1. Objective & Scope: Surgical Replacement for System Integrity
Objective: To surgically remove a single cracked, broken, or chipped tile and replace it with a structurally sound, matching tile, ensuring the continuity of the roof's primary protective layer.
Scope: This procedure applies to the replacement of individual tiles. It is a common standalone repair task and is also a mandatory prerequisite during any full restoration project.
2.2.2. Required Tools & Materials
 * Tools: Hammer, chisel, pry bar, tile lifting tools ("slaters"), wooden wedges.
 * Materials: Replacement tiles. These should be sourced from local tile recyclers to match the existing tile's profile, age, and colour as closely as possible. It's a CKR best practice to carry a small stock of the most common profiles in SE Melbourne. Approved items include MAT_TILE_REPC_CONC and MAT_TILE_REPC_TERRA.
2.2.3. The CKR 7-Step Tile Replacement Procedure
 * Isolate the Target Tile: Positively identify the broken tile to be replaced.
 * Lift & Wedge Surrounding Tiles: Carefully lift the overlapping tiles directly above and to the side of the broken one. Secure them in the raised position using wooden wedges. This creates the space needed to work.
 * Break & Remove: The broken tile cannot be simply slid out. Carefully break it further into smaller pieces using a hammer and chisel. Remove these pieces by hand, taking extreme care not to damage the underlying sarking or the adjacent tiles.
 * Inspect & Clear Debris: Once all pieces are removed, inspect the exposed sarking for any tears or holes. Clear all small fragments of tile and any other debris from the roof battens to ensure the new tile will sit flush.
 * Insert New Tile: Carefully slide the new replacement tile into position, ensuring its bottom edge interlocks correctly with the tiles below it and it is centred in the space.
 * Seat Overlapping Tiles: Gently remove the wooden wedges one by one, allowing the overlapping tiles to sit back down into their correct, natural position over the new tile.
 * Final Check: The new tile should be secure and sit flush with its neighbours. Manually check that it does not wobble or move.
2.2.4. Rationale & Technical Notes: Sourcing, Matching, and Securing
Sourcing the right replacement tile is a mark of craftsmanship. Using a new tile on a 20-year-old roof can look out of place. We prioritise sourcing weathered, second-hand tiles that match the existing roof's aesthetic. This demonstrates a level of care and detail that builds significant client trust.
2.2.5. Quality Assurance Checklist
 * [ ] Does the replacement tile's profile and colour match the existing roof as closely as possible?
 * [ ] Is the new tile correctly interlocked and seated flush with its neighbours?
 * [ ] Is the new tile secure and free of any wobble?
 * [ ] Was the underlying sarking inspected and confirmed to be undamaged?
2.3. SOP-T3: Ridge Capping Restoration (v3.1 - Master Craftsmanship Edition)
2.3.1. Objective & Scope: Master-Level Structural Reconstruction
Objective: To execute a master-level removal, reconstruction, and finishing process that restores the ridge line's structural integrity, waterproofing, and aesthetic appeal. This is one of the most critical procedures in tile roofing and a cornerstone of our craftsmanship reputation.
Scope: This SOP covers both a full "re-bed and re-point" and a "re-point only" service. It details the CKR master standard for all work on ridge, hip, and gable capping.
2.3.2. Required Tools & Materials (KF_02 Integration)
 * Tools: Angle grinder, hammer, chisels, pointing trowels, bedding frame, buckets for mixing.
 * Materials (from KF_02):
   * MAT_TILE_SAND_20KG (Builder's Sand)
   * MAT_TILE_CEMENT_20KG (General Purpose Cement)
   * MAT_TILE_FLEXPOINT_10L (Flexible Pointing)
 * Additives: Plasticiser, Cement Oxide (for colouring), Cement Accelerator (for cold weather).
2.3.3. Phase 1: Meticulous Preparation & Deconstruction
 * Surface Prep (Re-point only): For jobs where the bedding is sound, use an angle grinder to remove any loose pointing and wire brush the edges of the ridge caps and tiles to create a clean, sound surface for the new pointing to adhere to.
 * Ridge Cap Removal (Re-bedding): Carefully remove all ridge cap tiles from the section to be re-bedded. Stack them safely and securely on the roof.
 * Complete Mortar Removal (Re-bedding): Meticulously chip, grind, and scrape off 100% of the old, failed bedding mortar from both the roof tiles and the underside of the ridge caps. The substrate must be taken back to the bare tile.
2.3.4. Phase 2: Substrate Reconstruction & CKR Mortar Mixing
 * Broken Tile Re-cutting: Inspect the top course of tiles. Any tiles that were broken during removal must be replaced (SOP-T2). Any cuts must be re-cut neatly.
 * Alignment & Securing: Ensure all tile cuts are aligned correctly and are secured with clips to prevent movement.
 * Mortar Mixing (The CKR Ratio): This ratio is a CKR trade standard.
   * Ratio: Mix 2/5ths of a cement bag per 20L bucket of sand.
   * Additives: Integrate Plasticiser to improve workability, Cement Oxide to tint the mortar to a base grey, and Cement Accelerator in cold weather to ensure a proper cure.
   * Consistency: Add water slowly until a firm, workable consistency is achieved.
2.3.5. Phase 3: Bedding, Alignment & Weep Hole Formation
 * Lay Mortar Bed: Use a bedding frame to lay a consistent, uniform bed of the freshly mixed mortar along the ridge line.
 * Seat Ridge Caps: Firmly press the ridge caps into the mortar bed, ensuring they are set to the correct height and are perfectly straight. Use a string line for long ridges to ensure perfect alignment.
 * Form Weep Holes: As the bedding is laid, create "weep holes" every second ridge cap. These are small channels or gaps in the mortar bed on the lower side that allow any moisture that gets under the caps to escape.
 * Finish & Smooth: Smooth the excess mortar with a trowel for a neat finish.
2.3.6. Phase 4: Professional Pointing Application & Finishing
 * Curing: Allow the new bedding mortar to cure until it is firm to the touch (as per manufacturer specs).
 * Apply Pointing: Apply a thick, generous, and continuous bead of the approved MAT_TILE_FLEXPOINT_10L flexible pointing compound over the joins between the ridge caps and the roof tiles.
 * Tooling & Finishing (The Signature): This is the final step that showcases CKR craftsmanship. Use a pointing trowel to tool the pointing to a smooth, uniform, and slightly concave finish. The lines must be clean and sharp, with no smudges on the face of the tiles or ridge caps.
2.3.7. Rationale & Technical Notes: The Function of Weep Holes
Weep holes are a critical and often overlooked component of a durable ridge capping system. They are a mandatory part of the CKR standard. Trapped moisture and condensation can build up under ridge caps. Without an escape path, this moisture saturates the bedding mortar, leading to premature decay and failure. Weep holes provide this escape path, keeping the bedding dry and structurally sound for many years longer.
2.3.8. The Master Quality Assurance Checklist
 * [ ] For re-beds, has all old mortar been completely removed?
 * [ ] Are the new ridge caps bedded in a perfectly straight and level line?
 * [ ] Are weep holes present and clear of obstruction in all new bedding?
 * [ ] Is the flexible pointing applied in a thick, continuous bead with no gaps?
 * [ ] Is the final tooled finish smooth, uniform, and aesthetically flawless?
2.3.9. Photo-Documentation Points & Shot List
 * Before: Close-ups of the old, cracked, and failing pointing/bedding.
 * During: A shot of the ridge line cleaned back to bare tile. A photo of the new mortar bed with weep holes clearly visible.
 * After: Close-ups of the finished, clean lines of the new flexible pointing, showcasing the tooling quality.
2.4. SOP-T4: Full Tile Roof Restoration (Master SOP v3.1)
2.4.1. Objective & Scope: Orchestrating the Complete Transformation
Objective: To execute a complete, multi-stage tile roof restoration that rejuvenates, protects, and transforms the client's property. This master SOP orchestrates the preceding SOPs into a single, cohesive workflow, ensuring a flawless result that qualifies for a full CKR 15-year or 20-year workmanship warranty.
Scope: This SOP covers the entire process from start to finish for a full tile roof restoration, including cleaning, all repairs, and the application of a complete 3-coat coating system.
2.4.2. The Conditional Master Procedure Flowchart
The sequence of operations is critical and depends on the scope of the ridge capping repairs. Following the wrong sequence will compromise the quality of the job.
Workflow A: Full Restoration (with Full Re-bedding)
This is the correct sequence when a full re-bed and re-point is required.
 * Site Prep & Inspection: Protocols U-1 to U-4.
 * Structural Repairs First: Execute the re-bedding phases of SOP-T3 (v3.1).
 * Curing & Grinding: Allow the new bedding to cure fully, then grind edges smooth.
 * High-Pressure Cleaning: NOW execute SOP-T1 (v3.1). The clean will wash away all the dust from the grinding.
 * Secondary Repairs & Sealing: Now execute SOP-T2 for any broken tiles and complete the final pointing phase of SOP-T3 (v3.1).
 * Surface Coating System: Proceed to Phase 2 (2.4.4).
 * Finalisation & Clean-up: Proceed to Phase 3 (2.4.5).
Workflow B: Full Restoration (Re-pointing Only)
This is the correct sequence when the existing bedding is sound.
 * Site Prep & Inspection: Protocols U-1 to U-4.
 * High-Pressure Cleaning First: Execute SOP-T1 (v3.1). The roof must be clean before repairs.
 * All Repairs: Now execute SOP-T2 for broken tiles and the pointing phases of SOP-T3 (v3.1).
 * Surface Coating System: Proceed to Phase 2 (2.4.4).
 * Finalisation & Clean-up: Proceed to Phase 3 (2.4.5).
2.4.4. Phase 2: The CKR Surface Coating System (15 & 20-Year Tiers)
 * Masking: Meticulously mask off all adjacent surfaces not to be painted (gutters, fascias, walls, skylights).
 * Primer/Sealer Application: Apply one full, even coat of the specified primer/sealer using an airless sprayer. The product selection depends on the tile condition (e.g., COAT_PRIMER_RAWTILE_20L for raw/powdery tiles).
 * Top Coat Application (Warranty Tiers): This step defines the warranty level.
   * Standard 15-Year Warranty: Apply two full coats of COAT_PAINT_STD_20L (Premcoat Standard Top Coat).
   * Premium 20-Year Warranty: Apply two full coats of COAT_PAINT_PREM_15L (Premcoat Plus Premium Top Coat).
 * Curing Times: Strictly respect all manufacturer-specified curing times between coats.
2.4.5. Phase 3: Finalisation, Site Clean-up & Client Handover
 * De-masking: Carefully remove all masking tape and plastic sheeting once the final coat is sufficiently cured.
 * Final Quality Inspection: Conduct the Master Quality Assurance Checklist (2.4.7).
 * Exhaustive Site Clean-up: Perform a final, meticulous clean-up of the entire site, including gutters, ground areas, and any overspray.
 * Final Documentation: Take the full set of "After" photos from the same angles as the diagnostic shots.
 * Client Handover: Walk the client around the property, pointing out the completed work and explaining the transformation.
2.4.7. The Master Quality Assurance Checklist for Full Restorations
 * [ ] Have all repairs (tiles, pointing) been completed to the standard of their respective SOPs?
 * [ ] Is the final paint colour correct as per the client's selection?
 * [ ] Is the final paint finish uniform, with no runs, light patches, or overspray?
 * [ ] Have all masking materials been removed, leaving clean, sharp lines?
 * [ ] Are the gutters clean and downpipes fully functional?
 * [ ] Is the entire site, including the client's garden and driveway, immaculately clean?
SECTION 3: APPENDIX
3.1. Appendix A: Common Tile Profiles in SE Melbourne (Photo Guide)
 * Monier (Concrete): Elabana, Homestead, Atura.
 * Boral (Concrete): Macquarie, Slimline.
 * Terracotta (Wunderlich/Monier): Modern French, Swiss, Roman.
 * Note: This is a reference guide. Always confirm the profile on-site.
3.2. Appendix B: Recommended Pressure Washer Settings & Nozzles
| Tile Type | Recommended PSI | Nozzle Type(s) | Key Considerations |
|---|---|---|---|
| Standard Concrete | 3500-4000 PSI | Turbo & 15° Fan | Robust tile, can handle high pressure. Focus on tile butts. |
| Older, Porous Concrete | 3000-3500 PSI | 25° Fan Jet | Reduce pressure to avoid damaging the weathered surface. |
| Glazed Terracotta | 3000-3500 PSI | 25° Fan Jet | High pressure can chip the glaze. Use a wider fan and greater distance. |
3.3. Appendix C: Troubleshooting Common On-Site Issues
 * Issue: Unforeseen sarking/timber damage is discovered after removing tiles.
   * Protocol: STOP WORK immediately in that area. Photograph the damage extensively. Contact the CKR Project Manager. A formal variation quote must be generated and approved by the client before any further work is done to rectify the unforeseen damage.
 * Issue: Sudden weather change (unexpected rain).
   * Protocol: Immediately cease all pointing or painting work. Secure all materials. Inform the client of the unavoidable delay. Safety and quality are paramount.
 * Issue: Client requests additional work mid-job (e.g., "Can you also paint the shed roof?").
   * Protocol: Politely acknowledge the request. Explain that it is outside the current scope of work. A formal variation quote for the additional work must be generated and approved before it can be scheduled. Do not proceed on a verbal agreement.
3.4. Appendix D: Quick Reference QA Checklists for On-Site Use
QA: SOP-T3 Ridge Capping
 * [ ] Old Mortar 100% Gone? (Re-bed)
 * [ ] Bedding Straight & Level? (Re-bed)
 * [ ] Weep Holes Present? (Re-bed)
 * [ ] Pointing Bead Thick & Continuous?
 * [ ] Tooling Smooth & Clean?
QA: SOP-T4 Full Restoration
 * [ ] All Repairs Done to SOP Standard?
 * [ ] Correct Paint Products Used?
 * [ ] Finish is Uniform (No Runs/Patches)?
 * [ ] No Overspray on Gutters/Fascias?
 * [ ] Site is Immaculately Clean?
KNOWLEDGE FILE KF_04: STANDARD OPERATING PROCEDURES — METAL ROOFING
WORD COUNT (TOTAL): 20,980
LAST UPDATED: 2025-10-06
TABLE OF CONTENTS
 * SECTION 1: PHILOSOPHY & SUBCONTRACTOR ENGAGEMENT PROTOCOL
   1.1. The CKR Philosophy for Subcontracted Metal Roof Projects
   1.2. The "CKR Standard": A Unified Quality Mandate
   1.3. Protocol SE-1: Subcontractor Vetting, Onboarding & Compliance
   1.4. Protocol SE-2: Project Briefing & Scope of Work Handover
   1.5. Protocol SE-3: The Non-Negotiable Photo-Documentation Mandate for Subcontractors
 * SECTION 2: UNIVERSAL ON-SITE PROTOCOLS (SUBCONTRACTOR EDITION)
   2.1. Protocol U-1M: Site Safety Assessment & Establishment
   2.2. Protocol U-2M: The Comprehensive Metal Roof Health Check (Inspection)
   2.3. Protocol U-3M: Standard Tool & Equipment Requirements
 * SECTION 3: SERVICE-SPECIFIC SOPS (THE SUBCONTRACTOR PLAYBOOK)
   3.1. SOP-M1: Metal Roof High-Pressure Cleaning
   3.2. SOP-M2: Surface Preparation & Rust Treatment
   3.3. SOP-M3: Metal Roof Painting System (v3.0)
   3.4. SOP-M4: Metal Sheet & Fastener Replacement
 * SECTION 4: CKR QUALITY ASSURANCE & PROJECT HANDOVER
   4.1. Protocol QA-1: The CKR Final Inspection Checklist
   4.2. Protocol QA-2: Photo-Documentation Submission & Review
   4.3. Protocol QA-3: Project Handover, Invoicing & Warranty Activation
 * SECTION 5: APPENDIX
   5.1. Appendix A: Approved Materials & Supplier Doctrine
   5.2. Appendix B: Common Metal Roof Profiles (Corrugated, Trimdek, etc.)
   5.3. Appendix C: Troubleshooting Subcontractor Performance Issues
SECTION 1: PHILOSOPHY & SUBCONTRACTOR ENGAGEMENT PROTOCOL
1.1. The CKR Philosophy for Subcontracted Metal Roof Projects
Call Kaids Roofing stakes its reputation on the principles detailed in KF_01: Durability, Transparency, Craftsmanship, Accountability, and Proof. Our clients hire CKR for a specific standard of quality and peace of mind, and they are entitled to receive that standard regardless of who is physically performing the labour. The subcontractor's role is to provide their licensed expertise, while CKR's role is to provide the brand promise, quality assurance framework, and the final workmanship warranty (15 or 20 years).
1.2. The "CKR Standard": A Unified Quality Mandate
The "CKR Standard" is the benchmark for all work performed under the Call Kaids Roofing brand.
Key Tenets of the CKR Standard:
 * No Shortcuts: All procedures, especially in surface preparation, must be followed to the letter.
 * Approved Materials Only: Only materials specified in KF_02_PRICING_MODEL.json and the project brief are to be used.
 * Absolute Accountability: The subcontractor is accountable to CKR; CKR is accountable to the client. This chain is backed by our 15-year or 20-year warranty.
 * Proof is Mandatory: The photo-documentation protocols are a non-negotiable part of the job.
1.3. Protocol SE-1: Subcontractor Vetting, Onboarding & Compliance
This protocol details the multi-phase process for a subcontractor to become "CKR-Approved".
Phase 1: Initial Application & Screening:
 * Submission of formal application including business details, ABN, and contact information.
 * Provision of a current, valid VBA license for Roof Plumbing.
 * Provision of a current Certificate of Currency for Public Liability Insurance (minimum $10 million).
 * Submission of a portfolio of recent work (minimum 5 projects with photos).
 * Provision of three industry references.
Phase 2: Practical Assessment & SOP Review:
 * Successful applicants will be invited to a practical assessment, which may involve a paid, small-scale repair job on a non-critical project to assess real-world skills and adherence to safety protocols.
 * A formal review of the CKR Standard Operating Procedures (this document and others) will be conducted to ensure the subcontractor understands our quality and documentation requirements.
Phase 3: CKR Systems Onboarding & Agreement:
 * Training is provided on our communication and photo-documentation submission process.
 * The subcontractor must sign the "SOP Adherence Agreement" (see template below), formally acknowledging their commitment to uphold the CKR Standard on all contracted works.
Template: SOP Adherence Agreement
This agreement is made between Call Kaids Roofing (CKR) and [Subcontractor Name/Business]. The subcontractor hereby acknowledges they have received, read, and understood the CKR Standard Operating Procedures. The subcontractor agrees to perform all works contracted by CKR in strict accordance with these SOPs, including all protocols related to safety, material usage, workmanship quality, and photo-documentation. Failure to adhere to these SOPs may result in rectification orders, withholding of payment, or termination of the subcontractor agreement.
1.4. Protocol SE-2: Project Briefing & Scope of Work Handover
This protocol ensures that every project begins with absolute clarity. The CKR Project Manager will provide a complete digital package for each job, containing the following:
 * Client & Site Details: Full name, address, phone number, and any specific site access notes (e.g., "dog must be secured," "access via side gate").
 * The CKR Quote: The full quote document provided to the client, detailing the agreed-upon scope of work and price.
 * "Before" Photo Gallery: A link to the complete gallery of diagnostic photos taken during the initial inspection.
 * Itemized Materials List: A specific list of all required materials with their product codes from KF_02, including quantities, paint colours, etc.
 * Scope of Work Document: A formal document that explicitly lists the required tasks and references the relevant SOPs from the Knowledge Files (e.g., "Task 1: High-Pressure Clean roof surface as per KF_04, SOP-M1.").
1.5. Protocol SE-3: The Non-Negotiable Photo-Documentation Mandate for Subcontractors
This protocol is the cornerstone of our "Proof In Every Roof" philosophy.
Subcontractor Shot List (Minimum Requirements):
 * During - Preparation:
   * A photo showing the full roof masked and protected before painting.
   * For rust treatment jobs, a close-up photo of a treated area after mechanical grinding but BEFORE the primer is applied. This proves the rust was removed.
 * After - Completion:
   * Wide shots of the completed roof from multiple angles, replicating the "Before" photo angles where possible.
   * Close-ups of detailed work, such as newly installed fasteners, clean paint lines, or repaired sections.
   * A photo showing the worksite is clean and free of debris.
     Submission: All photos must be submitted to the CKR Project Manager within 24 hours of project completion. Final payment is conditional upon the receipt and approval of these photos.
SECTION 2: UNIVERSAL ON-SITE PROTOCOLS (SUBCONTRACTOR EDITION)
2.1. Protocol U-1M: Site Safety Assessment & Establishment
The subcontractor is solely responsible for establishing and maintaining a safe work environment compliant with all WorkSafe Victoria regulations. CKR has a zero-tolerance policy for safety breaches. This includes the subcontractor conducting their own Job Safety Analysis (JSA) or Safe Work Method Statement (SWMS) for each site, and using all necessary, certified safety equipment (e.g., harnesses, ropes, edge protection) at all times when working at heights.
2.2. Protocol U-2M: The Comprehensive Metal Roof Health Check (Inspection)
This section provides an exhaustive checklist for the diagnostic inspection of a metal roof.
Inspection Checklist:
 * Corrosion Assessment:
   * [ ] Surface Rust: Note any light, orange-coloured rust.
   * [ ] Pitting Rust: Check for deeper corrosion with a rough texture.
   * [ ] Perforation: Probe any severe rust to check for holes.
   * [ ] Cut-Edge Rust: Inspect the edges of sheets, especially near the gutters.
 * Coating & Sheet Condition:
   * [ ] Chalking/Oxidation: Wipe a dark cloth on the surface. Note the amount of chalky residue.
   * [ ] Delamination/Peeling: Check for any areas where the paint is lifting or peeling.
   * [ ] Dents & Damage: Note any dents from hail or foot traffic.
 * Fasteners:
   * [ ] Washer Condition: Inspect EPDM washers for perishing, cracking, or splitting.
   * [ ] Fastener Tightness: Check for any loose or "popped" screws.
   * [ ] Corrosion: Note any rust on the screw heads.
 * Flashings & Penetrations:
   * [ ] Seals: Inspect all silicone seals on flashings, end laps, and penetrations.
   * [ ] Dektites: Check rubber boots for UV degradation and cracks.
2.3. Protocol U-3M: Standard Tool & Equipment Requirements
This section specifies the minimum professional standard for equipment used on a CKR project.
 * Safety: Full compliance kit for working at heights.
 * Cleaning: Petrol-powered pressure washer (min. 3000psi).
 * Preparation: Industrial angle grinders, wire wheels, sanders.
 * Painting: Professional-grade airless spray unit (e.g., Graco, Wagner) with a minimum PSI of 3300, capable of supporting a .017 tip.
 * Repairs: Cordless impact driver, nibblers or power shears (no angle grinders for on-roof sheet cutting), caulking guns.
SECTION 3: SERVICE-SPECIFIC SOPS (THE SUBCONTRACTOR PLAYBOOK)
This section contains the master-level Standard Operating Procedures for all common metal roofing tasks. Adherence to these procedures is mandatory for all CKR team members and subcontractors. They are the foundation of the "CKR Standard" and the basis for our 15 and 20-year workmanship warranties.
3.1. SOP-M1: Metal Roof High-Pressure Cleaning
3.1.1. Objective & Scope: To meticulously clean a metal roof surface of all dirt, chalking oxidation, organic growth, and other contaminants to ensure a chemically clean substrate, ready for subsequent repair or coating.
3.1.2. Required Equipment:
 * Petrol-powered pressure washer (min. 3000psi, max 4000psi).
 * 15-degree and 25-degree fan nozzles. Note: Turbo nozzles are strictly forbidden on metal roofs.
 * Property protection equipment (tarps, plastic sheeting).
 * Gutter and downpipe flushing attachments.
3.1.3. Step-by-Step Procedure:
 * Site & Property Protection: Establish safety zones per Protocol U-1M. Use tarps to protect sensitive areas such as air conditioning units, skylights, and delicate garden beds from overspray.
 * Top-Down Cleaning: Always begin cleaning at the ridge (highest point) and work downwards towards the gutters. This method uses gravity to its advantage and prevents forcing water uphill under sheet laps.
 * Nozzle Technique: Use a 15 or 25-degree fan nozzle. Hold the wand at a 45-degree angle to the surface, maintaining a consistent distance of 20-30cm. Clean with the direction of the ribs or laps, not against them. Use long, even, overlapping strokes.
 * Thorough Rinsing: After the initial pass, perform a full, low-pressure rinse of the entire roof from top to bottom to wash away all dislodged contaminants and cleaning residues.
 * Gutter & Site Clean: Meticulously clean out all gutters and flush all downpipes to ensure they are free of debris from the roof clean. Perform a final wash-down of any affected walls or ground surfaces.
3.1.4. Rationale & Technical Notes:
 * Why No Turbo Nozzles: A turbo nozzle creates a high-impact, circular jet of water. On a metal roof, this can cause micro-dents and damage the delicate galvanized or Zincalume coating beneath the paint, leading to premature corrosion. A fan nozzle provides a safe and effective clean.
 * Chalking Oxidation: The primary purpose of cleaning an older Colorbond roof is to remove the fine, chalky powder of oxidized paint. If this layer is not completely removed, the new primer and paint will not adhere to the solid substrate, causing delamination (peeling).
3.2. SOP-M2: Surface Preparation & Rust Treatment
3.2.1. Objective & Scope: To mechanically and chemically treat any areas of corrosion, flaking paint, or failed sealant to create a sound, stable, and rust-free surface ready for priming. This is the most critical stage for long-term paint durability.
3.2.2. Rust Severity Classification:
 * Level 1 (Surface Rust): Light, orange-coloured rust on the surface, often from a scratch or swarf. No pitting is visible.
 * Level 2 (Pitting Rust): Deeper corrosion where the rust has started to eat into the metal, creating a rough, pitted texture.
 * Level 3 (Perforation): The rust has gone completely through the metal sheet, creating a hole.
3.2.3. Step-by-Step Procedure:
 * Mechanical Removal: For Level 1 and 2 rust, use an angle grinder with a wire wheel, flap disc, or a sander to remove all loose paint and corrosion. The area must be taken back to clean, sound, bare metal.
 * Feather Edges: Sand the edges of all repaired areas to create a smooth, tapered "feathered" transition from the bare metal to the surrounding sound paint. This prevents the repaired area from being visible as a ridge in the final top coats.
 * Rust Treatment: Apply one coat of the approved rust converter/treatment to all bare metal areas. This chemical process neutralizes any microscopic residual rust and etches the surface for priming. Allow to cure as per the manufacturer's technical data sheet.
 * Spot Priming: Apply one coat of the approved metal primer (COAT_PRIMER_METAL_20L) specifically to the treated areas. This provides the first layer of protection and seals the repaired patch.
 * Perforation Repair (Level 3): If perforation is found, the procedure stops. The subcontractor must photograph the damage and contact the CKR Project Manager immediately. Repairing a perforation requires either a professional patch or a full sheet replacement (SOP-M4) and must be quoted as a variation.
3.2.4. Rationale & Technical Notes: Painting over rust without proper mechanical removal and chemical treatment is a guaranteed failure. The rust will continue to grow under the new paint, causing it to bubble and peel within 12-24 months.
3.3. SOP-M3: Metal Roof Painting System (v3.0)
3.3.1. Objective & The CKR Standard: To apply a complete, multi-stage coating system using an airless sprayer to achieve a durable, uniform, and aesthetically pleasing finish that meets or exceeds the original manufacturer's specifications and qualifies for the specified CKR Workmanship Warranty.
3.3.2. Required Equipment & Approved Materials:
 * Airless spray unit (min. 3300 PSI, capable of supporting a .017 tip).
 * Masking equipment.
 * Approved Primer: COAT_PRIMER_METAL_20L (Premcoat Metal Primer).
 * Approved Top Coats (as per quote):
   * Standard (15-Year Warranty): COAT_PAINT_STD_20L (Premcoat).
   * Premium (20-Year Warranty): COAT_PAINT_PREM_15L (Premcoat Plus).
3.3.3. Step-by-Step Procedure:
 * Masking: Meticulously mask all adjacent surfaces not to be painted.
 * Full Primer Coat: Apply one full, even coat of COAT_PRIMER_METAL_20L and allow to cure.
 * First Top Coat: Apply the first full coat of the specified top coat membrane (Premcoat for Standard jobs, Premcoat Plus for Premium jobs).
 * Second Top Coat: Apply the second and final top coat of the same membrane.
 * De-masking: Carefully remove all masking materials once the paint is cured.
3.3.4. Technique Deep Dive: Airless Spraying on Metal Roofs
 * Tip Selection: Use a 515 or 517 tip for broad surfaces. A 517 tip provides a 10-inch (25cm) fan width and is ideal for corrugated or Trimdek profiles.
 * Pressure Setting: Set the sprayer pressure just high enough to achieve a complete, even fan with no "tails" or "fingering" at the edges. Too much pressure creates excessive overspray; too little results in an uneven finish.
 * Technique: Maintain a consistent spray distance of approximately 30cm from the roof surface. Keep the gun perpendicular to the surface. Move at a steady, consistent speed. Overlap each spray pass by 50% to ensure even film build and avoid "striping".
3.4. SOP-M4: Metal Sheet & Fastener Replacement
3.4.1. Objective & Scope: To replace damaged metal roof sheets or failed fasteners to CKR standards, ensuring structural integrity and long-term waterproofing.
3.4.3. Step-by-Step Procedure:
 * Removal: Remove old fasteners and lift the damaged sheet carefully, starting from the ridge and working down.
 * Substrate Inspection: Inspect exposed battens and sarking, reporting any damage to the CKR Project Manager.
 * Installation: Install the new sheet, ensuring it is correctly aligned and the side lap is facing away from the prevailing weather.
 * Fastening: Fasten the new sheet according to code (typically on every second rib in the field, and every rib at the ends and edges). Use a torque-set driver to compress the EPDM washer without over-tightening.
 * Swarf Removal (CRITICAL): Immediately after installing new sheets or screws, completely remove all sharp metal shavings (swarf) from the entire roof surface. This must be done with a combination of a leaf blower, soft brush, and, if necessary, a magnet.
3.4.4. Rationale & Technical Notes:
 * Cutting: On-roof cutting of metal sheets should be done with nibblers or shears. Angle grinders must not be used to cut sheets on the roof. The hot sparks from an angle grinder will permanently damage the surrounding paint and coating.
 * Swarf: Swarf is the collection of small metal filings left after cutting or drilling. If left on the roof, these particles will rust within hours of the first dew or rain, creating hundreds of small, ugly rust stains all over the new roof. Meticulous removal is the sign of a true professional.
SECTION 4: CKR QUALITY ASSURANCE & PROJECT HANDOVER
This section details the critical final phase of every project. The CKR brand promise is not just about doing the work, but about verifying and proving that the work was done to the highest possible standard. These protocols ensure a consistent and professional handover for every client.
4.1. Protocol QA-1: The CKR Final Inspection Checklist
Objective: To provide the CKR Project Manager with a systematic and non-negotiable checklist for conducting the final quality assurance inspection upon project completion. This sign-off is the final gate before project handover.
Procedure: The Project Manager will physically attend the site and perform a walkthrough of the entire roof area, using the following checklist. Any item marked as "Fail" must be rectified by the subcontractor before the project can be considered complete.
Final Inspection Checklist:
 * Part A: Surface & Coating Finish
   * [ ] Uniformity of Colour: Is the final top coat colour uniform across all roof faces, with no patchiness or light spots?
   * [ ] Consistency of Sheen: Is the gloss level consistent, with no dull or flat patches? (Indicates missed areas or incorrect film build).
   * [ ] No Over-spray: Inspect all adjacent surfaces (gutters, fascias, walls, windows, skylights) for any signs of paint over-spray.
   * [ ] No Runs or Drips: Inspect all vertical surfaces and sheet edges for any paint runs or drips.
   * [ ] No "Striping": When viewed from multiple angles in good light, is the finish free of any linear marks or "stripes" that would indicate poor spray technique?
   * [ ] Adhesion Check (Spot Test): In an inconspicuous area, perform a cross-hatch adhesion test as per Australian Standards if there is any doubt about surface preparation.
 * Part B: Repairs & Structural Integrity
   * [ ] Fastener Check: Are all new fasteners secure and correctly tensioned (EPDM washer is compressed but not squashed)?
   * [ ] Sheet Security: Are all new sheets correctly lapped, aligned, and secure?
   * [ ] Sealant Application: Are all new silicone beads (on flashings, etc.) neat, professionally tooled, and fully cured?
   * [ ] Rust Treatment: Are all previously identified rust spots fully treated and coated, with no signs of bubbling or staining?
 * Part C: Site Cleanliness
   * [ ] Swarf Free: Has the entire roof surface been meticulously cleared of all swarf (metal filings)?
   * [ ] Gutters & Downpipes: Are all gutters and downpipes clean, clear, and free of project debris?
   * [ ] Ground Clean-up: Is the ground area around the property completely clean of all masking tape, plastic, paint flakes, and other rubbish?
   * [ ] Property Protection: Has all CKR-related property protection (tarps, etc.) been removed?
4.2. Protocol QA-2: Photo-Documentation Submission & Review
Objective: To verify that the subcontractor has provided the required photographic evidence to support the "Proof In Every Roof" philosophy.
Procedure: The CKR Project Manager will review the subcontractor's submitted "During" and "After" photos against the project's "Before" gallery and the required shot list (Protocol SE-3).
 * Verification Checklist:
   * [ ] Have all required "During" shots been provided (e.g., rust treatment, full prime coat)?
   * [ ] Do the "After" photos clearly demonstrate the quality of the work and the completion of all scope items?
   * [ ] Are the photos of sufficient quality (in focus, good lighting) to be used for client handover and marketing purposes?
4.3. Protocol QA-3: Project Handover, Invoicing & Warranty Activation
Objective: To formally close out the project and activate the CKR warranty.
Procedure:
 * Once the on-site inspection (QA-1) and photo review (QA-2) are passed, the CKR manager formally signs off on the project.
 * This sign-off authorizes the CKR office to process the subcontractor's final invoice for payment.
 * Simultaneously, the CKR office activates the applicable 15-year or 20-year workmanship warranty for the client and sends them the final documentation, including the "after" photo set.
SECTION 5: APPENDIX
5.1. Appendix A: Approved Materials & Supplier Doctrine
All approved materials, their product codes, and their baseCost are centrally managed in the KF_02_PRICING_MODEL.json file. This file is the single source of truth for all materials to be used on any CKR project. No unauthorized substitutions are permitted. Subcontractors must refer to the specific material codes provided in their project brief and must not deviate without explicit written permission from the CKR Project Manager.
5.2. Appendix B: Common Metal Roof Profiles
 * Corrugated: The classic, wavy Australian profile. Characterized by continuous, rounded curves.
 * Trimdek / Monoclad: A modern, trapezoidal or square-ribbed profile. Characterized by high, flat-topped ribs and wide, flat pans between them.
 * Kliplok: A concealed-fix profile where sheets are "clipped" onto brackets, so no fasteners are visible on the surface. Characterized by high, prominent ribs with no visible screw heads.
5.3. Appendix C: Troubleshooting Subcontractor Performance Issues
This section provides the official CKR protocol for handling common performance issues with subcontractors.
 * Issue: Incomplete Photo-Documentation
   * Protocol: Withhold final payment until all required photos as per the project shot list are provided and meet quality standards.
 * Issue: Failed QA Inspection (Minor Issues)
   * Protocol: The CKR Project Manager will create a detailed "punch list" of all items that failed the QA checklist. The subcontractor is required to rectify all items on the list at their own cost within a specified timeframe (typically 48 hours). A re-inspection will be performed.
 * Issue: Failed QA Inspection (Major Issues)
   * Protocol: For major failures in workmanship or safety, CKR may, at its discretion, hire a different CKR-Approved subcontractor to rectify the work. The cost of this rectification will be deducted from the original subcontractor's invoice. A major failure will result in an immediate and formal review of the subcontractor's "CKR-Approved" status.
 * Issue: Unauthorized Use of Materials
   * Protocol: If a subcontractor uses a non-approved material, CKR is not obligated to pay for that material. If the non-approved material compromises the integrity or warranty of the project, the subcontractor may be required to remove it and replace it with the correct material at their own cost.
KNOWLEDGE FILE KF_05: STANDARD OPERATING PROCEDURES — GENERAL & MINOR REPAIRS (INTERNAL TEAM MANUAL)
WORD COUNT: 20,115
LAST UPDATED: 2025-10-06
TABLE OF CONTENTS
 * SECTION 1: PHILOSOPHY & UNIVERSAL PROTOCOLS (INTERNAL TEAM EDITION)
   1.1. The CKR Philosophy for Repair & Maintenance Work: The Frontline of Trust
   1.2. The "Craftsmanship in the Details" Mandate: Micro-Actions, Macro-Impact
   1.2.1. The Psychology of a Perfect Repair
   1.2.2. The Financial Impact of "First Time Right"
   1.3. Protocol U-1R: Pre-Work Site Safety for Repair Tasks (Expanded Doctrine)
   1.3.1. Phase 1: The 360-Degree Vehicle Arrival Check
   1.3.2. Phase 2: The Dynamic On-Site Risk Assessment
   1.3.3. Phase 3: Client Communication & Site Establishment
   1.4. Protocol U-2R: The Diagnostic Approach to Leak Detection (Masterclass Edition)
   1.4.1. The Foundational Principle: "Source is Always Above"
   1.4.2. The Science of Water Ingress: Debunking Common Myths
   1.4.3. The CKR 5-Stage Diagnostic Funnel
   1.4.4. Advanced Technique: Controlled Water Testing Methodology
   1.5. Protocol U-3R: The Photo-Documentation Mandate for Repairs (The Evidence Trinity)
   1.5.1. The Diagnostic "Before" Photo: Justifying the Work
   1.5.2. The Procedural "During" Photo: Verifying the Craftsmanship
   1.5.3. The Quality Assurance "After" Photo: Proving the Value
   1.6. Protocol U-4R: Standard Repair & Maintenance Tool Kit (The Mobile Workshop)
   1.6.1. The Primary "Go-Bag": First-Response Tools
   1.6.2. The Vehicle Arsenal: Comprehensive Tooling & Consumables
   1.6.3. The Daily Restocking & Maintenance Protocol
 * SECTION 2: METAL ROOF MAINTENANCE & MINOR REPAIRS (INTERNAL SOPS)
   2.1. SOP-GR1: Systematic Fastener Replacement (v2.0)
   2.1.1. Objective & Scope: Targeted vs. Systematic Replacement
   2.1.2. Required Tools & Approved Materials (KF_02 Integration)
   2.1.3. The CKR 7-Step Fastener Replacement Procedure
   2.1.4. Rationale & Technical Notes: The Science of the Seal
   2.1.5. Specific Safety Protocols for Fastener Replacement
   2.1.6. The Master Quality Assurance Checklist
   2.1.7. Photo-Documentation Points & Shot List
   2.2. SOP-GR2: Professional Silicone Application & Minor Leak Sealing (v2.0)
   2.2.1. Objective & Scope: The CKR Sealant Standard
   2.2.2. Required Tools & Approved Materials
   2.2.3. The CKR 5-Step Sealing Process: A Deep Dive
   2.2.4. Rationale & Technical Notes: The Science of Adhesion
   2.2.5. Specific Safety Protocols for Sealant Application
   2.2.6. The Master Quality Assurance Checklist
   2.2.7. Photo-Documentation Points & Shot List
 * SECTION 3: FLASHING & PENETRATION REPAIRS (INTERNAL SOPS)
   3.1. SOP-GR3: General Flashing Maintenance & Resealing (v2.0)
   3.1.1. Objective & Scope: Proactive Flashing Integrity Management
   3.1.2. Required Tools & Approved Materials
   3.1.3. Step-by-Step Procedure for Common Flashing Types
   3.1.4. Rationale & Technical Notes: Understanding Thermal Expansion
   3.1.5. The Master Quality Assurance Checklist & Photo Points
   3.2. SOP-GR4: Dektite / Pipe Flashing Replacement (v2.0)
   3.2.1. Objective & Scope: Restoring the Primary Penetration Seal
   3.2.2. Required Tools & Approved Materials
   3.2.3. The CKR 8-Step Dektite Replacement Procedure
   3.2.4. Rationale & Technical Notes: Sizing, Tension & Secondary Seals
   3.2.5. The Master Quality Assurance Checklist & Photo Points
 * SECTION 4: GUTTER SYSTEMS (INTERNAL CLEANING & SUBCONTRACTOR MANAGEMENT)
   4.1. SOP-GR5: Gutter & Downpipe Cleaning (v2.0)
   4.1.1. Objective & Scope: Full System Drainage Restoration
   4.1.2. Required Tools & Equipment
   4.1.3. The CKR 6-Step Gutter Cleaning Procedure
   4.1.4. Rationale & Technical Notes: The High-Volume Flush Technique
   4.1.5. The Master Quality Assurance Checklist & Photo Points
   4.2. Protocol-GR6: Managing Subcontracted Gutter Installation & Major Repairs (v2.0)
   4.2.1. Objective & Scope: Upholding the CKR Standard via Proxy
   4.2.2. The Decision Protocol: When to Engage a Licensed Roof Plumber
   4.2.3. The Handover Package for Gutter Work: Setting the Standard
   4.2.4. The CKR Quality Assurance Checklist for Subcontracted Gutter Installation
 * SECTION 5: APPENDIX
   5.1. Appendix A: Approved Sealants, Fasteners & Materials (Master List)
   5.2. Appendix B: Leak Detection Diagnostic Tree (Visual Flowchart)
   5.3. Appendix C: Common Points of Failure on SE Melbourne Roofs (Photo Guide)
   5.4. Appendix D: Quick Reference QA Checklists for On-Site Use
SECTION 1: PHILOSOPHY & UNIVERSAL PROTOCOLS (INTERNAL TEAM EDITION)
1.1. The CKR Philosophy for Repair & Maintenance Work: The Frontline of Trust
This document serves as the master manual for the CKR in-house technical team. The tasks detailed herein—minor repairs, diagnostic leak detection, sealing, and proactive maintenance—represent the most fundamental and intimate interaction we have with our clients and their properties. While large-scale restorations are the flagship of our service offering, it is the expert and meticulous execution of these smaller, detailed tasks that truly forges our reputation and builds the foundation of lasting client trust. A minor repair is not a minor task; it is a major opportunity.
A client who contacts us with a small but stressful leak is placing a significant amount of trust in our hands. Their positive experience, from the initial phone call to the final, clean worksite, is our most powerful marketing tool. A perfectly executed repair transforms a worried homeowner into a brand advocate. That client will remember our professionalism, our transparency (backed by photos), and our durability for years to come. They will be the first to call us when their roof is ready for a full restoration, and they will be the first to recommend us to their friends and neighbours in the community.
Therefore, every action, every decision, and every procedure outlined in this manual must be executed with the full weight of the CKR brand behind it. The core principles from KF_01 are not diluted for smaller jobs; they are concentrated and magnified.
 * Honesty: We diagnose accurately and recommend only the necessary work. We do not upsell a full restoration when a targeted repair will suffice.
 * Craftsmanship: We follow every step of every SOP, ensuring our repairs are not just functional but also neat, professional, and durable.
 * Reliability: We show up on time, communicate clearly with the client, and complete the work as promised.
 * Accountability: We stand behind even the smallest repair. While a full 15 or 20-year warranty may not apply to every minor repair, our workmanship is always guaranteed to be to the highest standard.
 * Respect: We treat the client's property with the utmost care, ensuring we protect their home and leave the worksite immaculately clean.
These are not just values; they are our operational playbook. Adherence to this philosophy is what differentiates a CKR technician from every other operator in the market.
1.2. The "Craftsmanship in the Details" Mandate: Micro-Actions, Macro-Impact
For the work detailed in this SOP, craftsmanship is the defining metric of success. The physical and reputational difference between a temporary, amateur "patch-up" and a professional, CKR-standard repair is built upon a foundation of meticulous details. These micro-actions, when combined, create a macro-impact on the durability of the repair and the client's perception of our brand.
1.2.1. The Psychology of a Perfect Repair
A client who may never step foot on their own roof will judge the quality of our work by the visible details from the ground. A clean, perfectly straight bead of sealant, a new fastener that sits flush, or a replaced tile that matches seamlessly are all powerful psychological signals of quality. They see the care we took in the small things and intuitively trust that we took the same care in the things they cannot see. A sloppy, messy repair, even if it is technically waterproof for a short time, screams "quick and dirty" and erodes trust, regardless of the underlying technical skill. Our mandate is to ensure that the aesthetic quality of our repairs matches their functional quality.
1.2.2. The Financial Impact of "First Time Right"
A call-back to fix a failed repair is one of the most financially damaging events for our business. It not only costs us time, labour, and materials to rectify, but it also inflicts significant damage on our reputation. Adhering to the detailed procedures in this document is a direct investment in profitability. Proper surface preparation, correct material selection, and methodical technique are the insurance we take out against call-backs. Cutting a corner to save ten minutes on a job can easily cost us three hours and hundreds of dollars a week later, completely erasing the profit from the original job and potentially losing a client for life. The "First Time Right" approach is not just a goal; it is a non-negotiable financial and operational strategy.
1.3. Protocol U-1R: Pre-Work Site Safety for Repair Tasks (Expanded Doctrine)
Objective: To instill a non-negotiable, systematic safety culture for all minor repair and maintenance tasks. These jobs, often of short duration, carry a high risk of complacency. This protocol is designed to eliminate that risk through a mandatory, multi-phase safety check on every single site visit, without exception.
1.3.1. Phase 1: The 360-Degree Vehicle Arrival Check
Safety begins the moment the CKR vehicle arrives at the property.
 * Assess Street Position: Park the vehicle in a position that is legally and safely off the road, does not obstruct traffic or driveways, and allows for safe removal of ladders and equipment.
 * Identify Overhead Hazards: Before exiting the vehicle, perform a slow, 360-degree visual scan. The primary objective is to identify the location of all overhead power lines (service lines to the house and street-level power lines). Verbally confirm their location. Note any large, overhanging tree branches that could pose a risk.
 * Plan Equipment Route: Mentally map the safest path to carry ladders and tools from the vehicle to the proposed work area. Identify any ground-level hazards on this path (e.g., uneven pavers, garden hoses, children's toys).
1.3.2. Phase 2: The Dynamic On-Site Risk Assessment
This assessment is performed before any tools are removed from the vehicle.
 * Confirm Roof Access Point: Walk the perimeter of the property to identify the single safest point for ladder access. The ideal location has firm, level ground and is clear of doorways, windows, and overhead hazards.
 * Assess Substrate Condition: From the ground, visually assess the condition of the roof itself. Is it a steep pitch? Does the surface look excessively mossy and slippery? Are the tiles visibly brittle? This initial assessment will inform the specific fall protection strategy required.
 * Weather Check: Check the immediate weather conditions. Is there rain approaching? Are wind speeds picking up? Work must not commence if rain is imminent or if wind conditions make handling ladders or working at heights unsafe.
 * Formulate Fall Protection Plan: Based on the roof access point and substrate condition, determine the anchor points and rope lines that will be used. Fall protection (harness, ropes, and appropriate anchors) is mandatory for any work on any roof, regardless of height or duration. There are zero exceptions to this rule.
1.3.3. Phase 3: Client Communication & Site Establishment
 * Professional Greeting: Make contact with the client. Introduce yourself and the company. Briefly and clearly explain the work you are about to perform.
 * Confirm Work Area & Exclusion Zone: Point out the area where you will be working and establish a clear exclusion zone underneath it. Inform the client that, for their safety, they and any other occupants (including pets) must remain clear of this area while work is overhead.
 * Secure Site: Place safety cones and, if necessary, "WORK OVERHEAD" signage to clearly demarcate the exclusion zone.
 * Ladder & Harness Setup: Only after the site is secure and the client has been briefed, proceed to retrieve the ladder and set it up correctly (correct angle, secured at the top). Put on your harness and prepare your fall protection equipment. The first time your feet leave the ground, you must be connected to a compliant fall arrest system.
1.4. Protocol U-2R: The Diagnostic Approach to Leak Detection (Masterclass Edition)
Objective: To elevate leak detection from a guessing game to a systematic science. This protocol ensures that every CKR technician can accurately identify the true source of water ingress, not just its symptom, leading to permanent, reliable repairs that form the bedrock of our reputation.
1.4.1. The Foundational Principle: "Source is Always Above"
This is the immutable law of leak detection. Water, under the force of gravity, flows downhill. The location where water is visible inside a property (e.g., a stain on a ceiling) is merely the final exit point. The true entry point—the failure on the roof—is almost always located somewhere above that point on the roof's slope. Technicians must resist the temptation to simply seal the area directly above the visible internal damage. This is the mark of an amateur and the cause of failed repairs. The investigation must always begin at the symptom and methodically trace a path upwards.
1.4.2. The Science of Water Ingress: Debunking Common Myths
 * Myth 1: "Water finds the shortest path." Reality: Water finds the path of least resistance. It can travel significant distances sideways along sarking, rafters, or the top of ceiling joists before finding a penetration (like a light fitting) or a low point to drip through. A leak appearing in the living room could originate from a cracked tile ten metres away near the ridge line.
 * Myth 2: "A leak only happens when it rains." Reality: Capillary action can draw water into tiny cracks or under flashings long after rain has stopped. Slow, seeping leaks can be caused by condensation or blocked gutters that remain full of water.
 * Myth 3: "More silicone is the answer." Reality: Applying copious amounts of sealant over a problem area without proper diagnosis and preparation is a guaranteed failure. It often traps moisture, exacerbates the problem, and makes a future professional repair more difficult and costly. Our approach is surgical, not smothering.
1.4.3. The CKR 5-Stage Diagnostic Funnel
This is a systematic process that starts broad and narrows down to the precise point of failure.
 * Stage 1: Internal Reconnaissance & Client Interview:
   * Start inside the property. Ask the client specific questions: When does it leak (only in heavy rain, windy rain, etc.)? How long has it been happening? Has anyone tried to repair it before?
   * If access is possible, enter the roof cavity with a powerful torch. Look for water tracks, stains on timber, and daylight. This is the single most effective way to pinpoint a leak's general location. Note the position relative to roof penetrations (pipes, vents).
 * Stage 2: External Correlation & Visual Sweep:
   * Go onto the roof and locate the area directly corresponding to the internal findings.
   * Perform a broad visual sweep of this entire roof face, from the gutter to the ridge. Look for anything that appears out of place or in poor condition.
 * Stage 3: The Point-of-Failure Checklist:
   * Working systematically upwards from the symptom area, meticulously inspect every potential point of failure. Use the Diagnostic Tree in Appendix B as a mental checklist.
   * Tiles: Check for cracks (especially hairline cracks), chips, and slipped or dislodged tiles.
   * Metal: Check for failed fastener washers, holes, and corroded sheets.
   * Ridge Capping: Check for cracked or missing pointing and bedding.
   * Flashings: Check all flashings (apron, step, barge) for failed seals or gaps.
   * Penetrations: Check Dektites, skylights, and vents for perished seals.
   * Watercourses: Check valleys and gutters for blockages that could cause water to dam up and overflow.
 * Stage 4: Physical & Tactile Inspection:
   * Do not rely on sight alone. Gently try to lift ridge caps. Press on flashings to see if they move. Run a gloved hand along the underside of joins and laps to feel for moisture.
 * Stage 5: Confirmation & Photo-Documentation:
   * Once a definitive point of failure is identified, take a clear, close-up photograph as per Protocol U-3R. This becomes the evidence that justifies the repair.
1.4.4. Advanced Technique: Controlled Water Testing Methodology
This technique is to be used ONLY when a visual and physical inspection fails to reveal the source of the leak. It is a time-consuming process that must be quoted and approved by the client as a separate diagnostic service.
 * Team Requirement: This is a two-person job. One technician is positioned inside the property (in the roof cavity or observing the ceiling) with communication (a mobile phone). The second technician is on the roof with a hose.
 * Isolate the Area: Based on the diagnostic funnel, isolate the most likely roof face or section where the leak originates.
 * Low-to-High Application: The technician on the roof uses the hose (on a medium, steady flow, not a high-pressure jet) to apply water to the roof, starting at the lowest point of the suspected area (e.g., the gutter line).
 * Dwell Time: Apply water to a small, specific section (e.g., a single valley) for 5-10 minutes. The inside technician watches for any sign of water ingress.
 * Systematic Progression: If no leak appears, the outside technician stops the water flow and moves up to the next logical section (e.g., the mid-point of the valley, a section of flashing). The process is repeated: apply water, wait, observe.
 * Confirmation: When the inside technician yells "stop" or confirms water is appearing, the outside technician has definitively located the point of ingress. The water test is stopped immediately.
 * Documentation: The confirmed entry point is then photographed and the repair can be quoted with 100% confidence.
1.5. Protocol U-3R: The Photo-Documentation Mandate for Repairs (The Evidence Trinity)
Objective: To create an irrefutable, evidence-based record of every repair, forming the core of our "Proof In Every Roof" philosophy and serving as a powerful tool for transparency, client education, and quality assurance. This protocol is non-negotiable for every billable repair task.
1.5.1. The Diagnostic "Before" Photo: Justifying the Work
 * Purpose: This photo is the evidence. It shows the client the specific problem we have identified and justifies the need for the repair. It is the foundation of our honest and transparent approach.
 * Technical Requirements:
   * Clarity: The photo must be in sharp focus.
   * Context: The shot should be close enough to clearly show the failure (e.g., the crack in the sealant), but wide enough to give context to its location on the roof.
   * Indication: Where possible, use a finger or a tool to point directly at the failure point in the photo.
   * Example Shot: A close-up of a rusted roof screw with its EPDM washer split and perished.
1.5.2. The Procedural "During" Photo: Verifying the Craftsmanship
 * Purpose: This photo proves that we follow our own high standards of preparation. It is the visual evidence of the "Craftsmanship in the Details" mandate and is a key differentiator from competitors who cut corners.
 * Technical Requirements:
   * Timing: The photo is taken after the preparation stage but before the final repair is complete.
   * Content: It must showcase the quality of the preparation. This could be a photo of a flashing join that has been completely stripped of old silicone and chemically cleaned, ready for the new bead. Or it could be the area around a screw hole that has been wire-brushed clean before a new fastener is installed.
   * Example Shot: A photo showing a clean, bare metal surface where old, cracked sealant used to be, with a roll of painter's tape already in place, ready for the new application.
1.5.3. The Quality Assurance "After" Photo: Proving the Value
 * Purpose: This is the "hero" shot. It demonstrates the quality of the finished repair and provides the client with a tangible record of the value they have received. It creates the powerful before-and-after comparison that is central to our marketing and client satisfaction.
 * Technical Requirements:
   * Angle: The "After" photo must be taken from the exact same angle and distance as the "Before" photo to create a direct, compelling comparison.
   * Detail: The photo must clearly show the completed repair in a positive light—the clean, uniform bead of new sealant, the shiny new fastener with its perfectly compressed washer, or the neatly installed Dektite.
   * Example Shot: A photo from the same angle as the "Before" shot, now showing a brand new, clean Tek screw, its black EPDM washer perfectly seated and compressed against the metal sheet.
1.6. Protocol U-4R: Standard Repair & Maintenance Tool Kit (The Mobile Workshop)
Objective: To ensure every CKR vehicle is a self-sufficient mobile workshop, equipped with the standardised tools and a comprehensive inventory of approved consumables required to complete over 90% of common repair tasks on the first visit.
1.6.1. The Primary "Go-Bag": First-Response Tools
This is a dedicated, portable tool bag that the technician carries onto the roof for the initial inspection and for most minor repairs. It must contain:
 * Diagnostics: High-powered LED torch, moisture meter, camera/smartphone, chalk for marking.
 * Hand Tools: Multiple sizes of trowels and spatulas for tooling sealant, utility knife with spare blades, hammer, chisel, pry bar, wire brushes.
 * Power Tools: Cordless impact driver with a full set of driver bits and sockets (especially 5/16" hex for Tek screws), spare battery.
 * Sealants: At least one caulking gun and one tube each of the most common approved sealants (e.g., Translucent, Grey, Black).
1.6.2. The Vehicle Arsenal: Comprehensive Tooling & Consumables
The vehicle itself serves as the main toolbox and warehouse. It must be organised and stocked with:
 * Safety Gear: Full complement of harnesses, ropes, lanyards, ladder locks, safety cones, signage, and a fully stocked first aid kit.
 * Ladders: A range of extension ladders and step ladders appropriate for various property heights.
 * Power Tools: A second impact driver, cordless angle grinder with wire wheels and cutting discs, leaf blower.
 * Consumables Inventory (Organised & Labelled):
   * Fasteners: A multi-compartment case containing a full range of approved Buildex Class 4 fasteners of different gauges and lengths.
   * Sealants: A dedicated storage box containing a bulk supply of all approved neutral-cure silicones and sealants in various colours.
   * Repair Components: A range of commonly used Dektites (by pipe size), spare concrete and terracotta tiles (common profiles), and off-cuts of lead flashing.
   * Cleaning Supplies: Bulk methylated spirits, numerous clean rags, rubbish bags.
1.6.3. The Daily Restocking & Maintenance Protocol
 * End of Day Reconciliation: At the end of each workday, the technician is responsible for reconciling the consumables used against the jobs completed.
 * Restock Request: The technician must submit a formal restock request for any items that have fallen below the prescribed minimum quantity.
 * Tool Maintenance: All power tools must be placed on charge overnight. All hand tools must be cleaned and returned to their designated storage location.
 * Weekly Audit: Every Monday morning, a mandatory 15-minute audit of the entire vehicle kit must be performed against the master checklist to ensure nothing has been missed. This protocol ensures we never arrive at a job site unprepared, which is a key component of our brand's reliability.</blockquote>
2.1. SOP-GR1: Systematic Fastener Replacement (v2.0)
2.1.1. Objective & Scope: Targeted vs. Systematic Replacement
Objective: To restore the waterproofing integrity and structural security of a metal roof system by replacing failed or corroded fasteners with superior, compliant components, executed to the CKR Standard of precision.
Scope: This Standard Operating Procedure governs two distinct levels of intervention:
 * Targeted Replacement: This is the default approach for minor repairs where a small number of specific fasteners have been identified as the source of a leak or have failed prematurely. This is typically applicable to newer roofs or for isolated damage.
 * Systematic Replacement: This is a more comprehensive maintenance procedure recommended when a widespread, systemic failure of the fasteners is identified during a Roof Health Check. As a general rule, if more than 20% of the fasteners on a single roof face show signs of significant corrosion or washer failure, a Systematic Replacement of all fasteners on that face must be recommended to the client. This is an act of Honesty and Accountability; it provides a long-term, durable solution rather than a temporary "patch" that will inevitably lead to further call-backs as adjacent, aging fasteners also fail. The decision to recommend a Systematic Replacement must be based on clear photographic evidence.
2.1.2. Required Tools & Approved Materials (KF_02 Integration)
 * Primary Tool: High-quality cordless impact driver with adjustable torque settings and multiple fully charged batteries.
 * Driver Sockets: Magnetic 5/16" (8mm) hex head driver socket is standard for most roofing Tek screws. A full set of metric sockets should be available.
 * Surface Preparation Tools: Stiff wire brush (handheld), cordless drill with wire wheel attachment, multiple clean and dry rags.
 * Approved Fasteners: The only approved fasteners are those listed in KF_02_PRING_MODEL.json. The standard for all CKR work is Buildex brand, minimum Class 4 corrosion resistance, with a pre-assembled EPDM washer.
   * itemId: MAT_METAL_SCREWS_100 (or equivalent approved item).
   * Gauge Selection: The replacement screw must be of the same gauge if the original was secure. If the hole's thread is stripped, a larger gauge screw (e.g., 14g instead of 12g) must be used to ensure a new, tight purchase in the timber or metal batten.
 * Safety Equipment: As per Protocol U-1R, including cut-resistant gloves.
2.1.3. The CKR 7-Step Fastener Replacement Procedure
This procedure must be followed meticulously for every single fastener replacement.
 * Step 1: Identify and Assess: Positively identify the target fastener. Assess the failure mode: Is it rust on the head, a perished washer, or is it loose? This assessment informs the selection of the replacement screw gauge.
 * Step 2: Set Driver Torque (Removal): Set the impact driver to a low-to-medium torque setting for removal. Begin slowly. The goal is to back the screw out without shearing the head off or damaging the thread in the batten. If the screw spins freely, it is stripped; a larger gauge replacement is mandatory.
 * Step 3: Mechanical Surface Preparation: Once the old screw is removed, use a wire brush to meticulously clean the area on the metal sheet where the washer will sit. Remove all old washer residue, rust flakes, moss, and dirt. The goal is a clean, sound metal substrate for the new washer to seal against. This step is non-negotiable and is a key part of the "Craftsmanship in the Details" mandate.
 * Step 4: Chemical Surface Preparation: For a premium result, after mechanical cleaning, wipe the area with a rag dampened with methylated spirits. This removes any residual grease or fine dust, guaranteeing a perfect surface for adhesion.
 * Step 5: Select Replacement Fastener: Based on the assessment in Step 1, select the correct replacement screw from the kit. Ensure the length is correct for the roof profile and the gauge is appropriate for the condition of the batten thread.
 * Step 6: Installation & The "Goldilocks" Torque Rule:
   * Set the impact driver to a low torque setting for installation. This is the most critical technical step.
   * Position the new screw in the existing hole and begin driving.
   * Drive the screw until the EPDM washer makes contact with the roof sheet, then slow down.
   * Continue to drive slowly until the washer compresses slightly and forms a visible, cushioned seal. You are looking for a slight "bulge."
   * The Rule: The washer must be perfectly compressed. Over-tightening is the single most common failure point, as it splits the washer and destroys its sealing capability. Under-tightening will not create a seal at all. The technician must learn the feel and sound of a perfectly seated screw.
 * Step 7: Final Check & Clean-up: The new fastener should be secure with no wobble. The washer must be visibly sealed. All old, removed screws and any metal swarf created must be collected and removed from the roof to prevent future rust stains.
2.1.4. Rationale & Technical Notes: The Science of the Seal
 * The EPDM Washer: The washer is a sophisticated synthetic rubber (Ethylene Propylene Diene Monomer) designed for extreme UV and ozone resistance. Its function is to create a flexible, durable, and waterproof seal that can accommodate the thermal expansion and contraction of the metal roof sheet. Over-compressing the washer fractures its internal structure and exposes it to premature UV degradation, leading to leaks.
 * Corrosion Classes (AS 3566): Australian Standards dictate fastener classes. SE Melbourne's environment, being temperate and relatively close to the coast, is classified as a minimum Category 3 (mild marine/industrial). Therefore, using Class 4 fasteners provides a superior level of protection and longevity, aligning with our brand pillar of Durability. For properties within direct sight of Port Phillip Bay, Class 5 should be considered.
 * Galvanic Corrosion: This is an electrochemical process where one metal corrodes preferentially when in contact with another in the presence of an electrolyte (water). Using cheap, non-compliant screws (e.g., zinc-plated instead of properly coated) can cause a galvanic reaction with the Colorbond or Zincalume sheet, leading to accelerated rust around the fastener. Using the approved Buildex fasteners eliminates this risk.
2.1.5. Specific Safety Protocols for Fastener Replacement
 * Swarf Hazard: Metal shavings (swarf) created during screw removal/installation are extremely sharp and can cause cuts. Always wear gloves.
 * Eye Protection: Safety glasses are mandatory to protect from flying debris or a snapping screw head.
 * Tool Control: Maintain firm control of the impact driver to prevent it from slipping off the screw head, which can damage the roof sheet or cause injury.
2.1.6. The Master Quality Assurance Checklist
 * [ ] Has the correct corrosion class (min. Class 4) and gauge of screw been used?
 * [ ] Was the substrate both mechanically and chemically cleaned before installation?
 * [ ] Is the new EPDM washer compressed correctly according to the "Goldilocks Rule"?
 * [ ] Is the new fastener secure and free of any wobble?
 * [ ] Have all old fasteners and all swarf been completely removed from the site?
2.1.7. Photo-Documentation Points & Shot List
 * "Before" Shot: A clear, close-up photo of the identified failed fastener, showing the rust or the cracked EPDM washer.
 * "During" Shot: A photo of the clean, prepared surface around the empty screw hole. This provides proof of our meticulous preparation process.
 * "After" Shot: A photo taken from the same angle as the "before" shot, now showing the new, clean fastener with its perfectly compressed washer.
2.2. SOP-GR2: Professional Silicone Application & Minor Leak Sealing (v2.0)
2.2.1. Objective & Scope: The CKR Sealant Standard
Objective: To execute a durable, waterproof, and aesthetically perfect sealant application for minor leaks, cracks, or joins in flashings and other roof components. The CKR Sealant Standard dictates that the finished application must be functionally superior and visually flawless, acting as a clear signature of our craftsmanship.
Scope: This SOP is the master procedure for all sealant applications performed by the CKR team. It applies equally to sealing a tiny crack in a flashing, finishing the base of a Dektite, or sealing the corners of a newly installed gutter system. Its principles are universal and adherence is mandatory.
2.2.2. Required Tools & Approved Materials
 * Applicator: High-quality, professional-grade caulking gun (drip-free model preferred).
 * Approved Sealant: As per KF_02_PRICING_MODEL.json. The standard is a Neutral Cure, UV-stabilised, roof-grade silicone. Acetic Cure silicones are strictly forbidden on metal surfaces.
   * itemId: MAT_METAL_SILICONE_300ML
 * Solvent: Methylated spirits.
 * Cleaning: Multiple clean, lint-free rags. A stiff-bristled plastic brush and metal scrapers/blades for removing old sealant.
 * Finishing: High-quality painter's tape (e.g., 3M Blue). A set of sealant tooling spatulas in various profiles, or a supply of paddle pop sticks. A spray bottle containing a water/dish soap solution.
 * PPE: Nitrile gloves, safety glasses.
2.2.3. The CKR 5-Step Sealing Process: A Deep Dive
This is the core of the CKR Sealant Standard. Each step is critical and must be performed in sequence.
 * Step 1: Aggressive Mechanical Preparation:
   * The goal is to remove 100% of the old, failed sealant, as well as any loose paint, rust, dirt, or debris. New sealant cannot adhere to old, failing sealant.
   * Use a combination of scrapers, blades, and wire wheels to take the substrate back to a clean, sound, solid surface. The prepared area must extend at least 2cm on either side of the join to be sealed.
 * Step 2: Meticulous Chemical Cleaning:
   * This step removes the invisible contaminants (grease, oils, fine dust) that cause adhesion failure.
   * Apply methylated spirits to a clean, lint-free rag.
   * Wipe the entire prepared area firmly. The rag will likely show visible dirt.
   * Using a second, completely clean rag, wipe the area again to remove any residue left by the first wipe.
   * Allow the solvent to flash off completely (typically 1-2 minutes). The surface must be perfectly clean and bone-dry before proceeding.
 * Step 3: Masking for a Professional Edge:
   * This step is what separates a CKR technician from an amateur. For any visible, straight-line seal, apply painter's tape to create a clean, sharp channel for the sealant.
   * Apply the tape in long, straight runs, ensuring the edge is firmly pressed down to prevent the sealant from bleeding underneath. The gap between the two lines of tape should be the exact desired width of the final sealant bead.
 * Step 4: Controlled Application:
   * Cut the nozzle of the sealant tube to a size slightly smaller than the masked gap, at a 45-degree angle.
   * Puncture the inner seal of the tube.
   * Apply a consistent, steady pressure to the caulking gun trigger while moving at a smooth, constant speed along the join. The goal is to apply a continuous, uniform bead of sealant that slightly overfills the gap, ensuring it makes full contact with both surfaces.
 * Step 5: Professional Tooling and Finishing:
   * Immediately after applying the bead, lightly spray the sealant and the surrounding area with the soap and water solution. This acts as a lubricant and prevents the sealant from sticking to the tooling spatula.
   * Select the appropriately sized tooling spatula. Press it firmly into the join at a 45-degree angle and draw it along the entire length of the bead in one single, smooth, continuous motion. This action forces the sealant deep into the join, removes the excess, and creates a perfect, concave, smooth finish.
   * CRITICAL: While the sealant is still wet, immediately and carefully peel away the painter's tape, pulling it back on itself at a 45-degree angle away from the join. This will reveal a razor-sharp, perfectly straight sealant line.
2.2.4. Rationale & Technical Notes: The Science of Adhesion
 * Surface Energy & Adhesion: A professional seal is a feat of chemical engineering. For silicone to adhere, its liquid surface tension must be lower than the surface energy of the substrate. Cleaning with a solvent like methylated spirits removes low-surface-energy contaminants (like oils and grease) and maximizes the substrate's surface energy, allowing the silicone to "wet out" and form a powerful, permanent chemical bond. Skipping this step is the primary cause of sealant failure.
 * Neutral Cure vs. Acetic Cure: Acetic cure silicones (which smell like vinegar) release acetic acid as part of their curing process. This acid aggressively attacks the protective coatings on metal roofing materials like Colorbond, Zincalume, and galvanised steel, causing corrosion and rust. Using acetic cure silicone on a metal roof is a critical failure and a direct violation of this SOP. We exclusively use neutral cure silicones, which release alcohol as they cure and are non-corrosive.
 * The Function of Tooling: Tooling is not merely for aesthetics. It converts a simple bead of sealant into a high-performance gasket. The pressure applied during tooling eliminates air voids, ensures the sealant is in intimate contact with both substrates, and creates a shape that sheds water and resists dirt accumulation.
2.2.5. Specific Safety Protocols for Sealant Application
 * Ventilation: Work with solvents in a well-ventilated area.
 * Skin Contact: Avoid prolonged skin contact with sealants and solvents. Always wear nitrile gloves.
 * Eye Protection: Wear safety glasses to prevent accidental splashes of solvent or sealant into the eyes.
2.2.6. The Master Quality Assurance Checklist
 * [ ] Was the substrate completely free of all old sealant and debris before application?
 * [ ] Was the area chemically cleaned with methylated spirits?
 * [ ] Was the correct, approved Neutral Cure sealant used?
 * [ ] Is the final bead continuous, uniform, smooth, and free of any air bubbles or gaps?
 * [ ] Are the edges of the sealant line clean and razor-sharp?
 * [ ] Has all associated rubbish (empty tubes, used rags, masking tape) been removed from the site?
2.2.7. Photo-Documentation Points & Shot List
 * "Before" Shot: A clear close-up of the old, failed sealant, showing the cracking, peeling, or gaps.
 * "During" Shot: A photo of the join after it has been fully prepared—mechanically scraped, chemically cleaned, and masked with painter's tape. This is irrefutable proof of our professional process.
 * "After" Shot: A photo from the same angle as the "before" shot, showing the new, perfectly smooth, and sharp-edged bead of professionally tooled sealant.
SECTION 3: FLASHING & PENETRATION REPAIRS (INTERNAL SOPS)
3.1. SOP-GR3: General Flashing Maintenance & Resealing (v2.0)
3.1.1. Objective & Scope: Proactive Flashing Integrity Management
Objective: To systematically inspect, maintain, and repair common metal flashings to ensure they remain 100% waterproof, secure, and functional. This SOP focuses on preventative maintenance and minor repairs to what is one of the most critical components of any roof system.
Scope: This procedure covers the three most common types of flashings found on SE Melbourne properties:
 * Apron Flashings: Found where a sloped roof meets a vertical wall (e.g., at the front of a carport or extension).
 * Step Flashings: A series of individual flashings used where a roof meets a side wall, inter-woven with the tiles or roof sheets.
 * Barge Flashings (Barge Capping): Covers the edge of the roof sheeting at a gable end.
This SOP is focused on resealing and re-securing existing flashings. The full replacement of flashings is a major repair that may require a subcontractor as per Protocol-GR6.
3.1.2. Required Tools & Approved Materials
 * Primary Tool Kit: The full tool kit as per SOP-GR2 is required, including caulking gun, approved neutral cure sealants, solvents, rags, and tooling spatulas.
 * Fastening Tools: An impact driver with appropriate sockets for re-securing or replacing any loose fasteners.
 * Approved Fasteners & Sealants: All materials must be as per Appendix A.
   * itemId: MAT_METAL_SILICONE_300ML
   * itemId: MAT_METAL_SCREWS_100
3.1.3. Step-by-Step Procedure for Common Flashing Types
The core process for all flashing maintenance follows the principles of SOP-GR1 (for fasteners) and SOP-GR2 (for sealing). However, the application varies based on the flashing type.
A. Apron Flashing Maintenance:
 * Visual Inspection: Inspect the top sealed edge where the flashing meets the vertical wall. Look for any signs of cracking, peeling, or gaps in the sealant. Check all fasteners along the bottom edge to ensure they are secure and not corroded.
 * Fastener Check: Physically check the tightness of each fastener. If any are loose or rusted, replace them following the full 7-step procedure in SOP-GR1.
 * Sealant Removal & Preparation: If the sealant has failed, it must be completely removed. Use scrapers and a wire brush to take the join back to the bare, clean substrates (both the flashing and the wall). Perform the meticulous chemical clean as per Step 2 of SOP-GR2.
 * Professional Resealing: Apply a new, continuous bead of approved neutral-cure sealant along the entire top edge of the flashing. Tool the bead to a professional, concave finish to ensure a perfect waterproof seal that sheds water effectively.
B. Step Flashing Maintenance:
 * Visual Inspection: This is more detailed. Each individual "step" flashing must be inspected. Check the seal at the back (against the wall) and at the top. Most importantly, check that each step correctly overlaps the one below it, ensuring water is directed down the roof.
 * Lifting & Cleaning: Carefully check for debris and leaf litter that can get trapped behind the step flashings, causing water to dam and bypass the flashing. If necessary, and if the flashing is not fixed in place with mortar, gently lift the flashing to clean behind it.
 * Targeted Resealing: Unlike apron flashings, step flashings are often not continuously sealed. Apply sealant only where it is functionally required, typically at the top corner of each step where it meets the wall, to prevent water from driving in behind it. Over-sealing can sometimes trap water. Diagnose and seal with precision.
C. Barge Flashing (Barge Capping) Maintenance:
 * Visual Inspection: Check the fasteners along the top face and the side face of the flashing. These are often exposed to high winds and can work loose. Look for any signs of the flashing lifting or separating from the fascia.
 * Fastener Replacement: Systematically check and replace any failed or corroded fasteners as per SOP-GR1. This is the most common maintenance requirement for barge flashings.
 * Scribing & Sealing: Check the "scribed" section where the barge flashing is cut to fit over the profile of the roof sheets. If there are gaps, apply a neat, tooled bead of sealant to close them off and prevent wind-driven rain from entering.
3.1.4. Rationale & Technical Notes: Understanding Thermal Expansion
Metal flashings experience significant thermal expansion and contraction with daily temperature changes. This constant movement places extreme stress on the sealants and fasteners. This is why the material selection and application technique are so critical. A low-quality sealant will become brittle and crack under this strain. A professionally applied, high-quality flexible sealant (as per SOP-GR2) can accommodate this movement for years, ensuring a durable repair. Similarly, correctly torqued fasteners allow for micro-movements without failing.
3.1.5. The Master Quality Assurance Checklist & Photo Points
 * QA Checklist:
   * [ ] Are all fasteners on the flashing secure, correctly torqued, and free of corrosion?
   * [ ] Has all old, failed sealant been 100% removed before new application?
   * [ ] Is the new sealant bead continuous (where required), professionally tooled, and aesthetically clean?
   * [ ] For step flashings, is the overlap sequence correct and are they free of trapped debris?
 * Photo Points: Before-and-after photos focusing on the primary failure point. For example, a "before" shot of a cracked sealant line on an apron flashing, and an "after" shot of the new, perfectly tooled bead.
3.2. SOP-GR4: Dektite / Pipe Flashing Replacement (v2.0)
3.2.1. Objective & Scope: Restoring the Primary Penetration Seal
Objective: To correctly and permanently replace a failed, cracked, or perished Dektite (flexible roof flashing), restoring a 100% waterproof seal around a roof penetration (such as a vent pipe, flue, or mast).
Scope: This SOP covers the complete removal of an existing Dektite and the full installation of a new, compliant Dektite. It is one of the most common and critical repair tasks performed. A failed Dektite is a primary and guaranteed source of significant water ingress.
3.2.2. Required Tools & Approved Materials
 * New Dektite: DEKS Dektite® brand or equivalent as per Appendix A. The size must be correctly selected based on the Outer Diameter (OD) of the pipe.
 * Tools: Impact driver, sharp utility knife/Stanley knife, high-quality caulking gun, methylated spirits, and clean rags.
 * Consumables: Approved neutral-cure silicone (itemId: MAT_METAL_SILICONE_300ML), approved Class 4 fasteners (itemId: MAT_METAL_SCREWS_100).
3.2.3. The CKR 8-Step Dektite Replacement Procedure
 * Step 1: Preparatory Cutting: Use a utility knife to carefully cut and remove the bulk of the old silicone sealant around the base of the existing Dektite. This exposes the fasteners.
 * Step 2: Fastener Removal: Use an impact driver to remove all screws holding the old Dektite's base to the roof sheet.
 * Step 3: Old Dektite Removal: Make a vertical cut up the side of the old rubber boot to the top. This allows you to peel the Dektite off the pipe. Remove and dispose of the entire old component.
 * Step 4: Ultimate Surface Preparation: This is the most critical phase. Using scrapers, blades, and finally methylated spirits on a clean rag, remove every last trace of the old silicone from the roof sheet. The surface must be taken back to a perfectly clean, dry, and sound state. The new Dektite's seal will fail if it is applied over old silicone residue.
 * Step 5: Prepare the New Dektite:
   * Identify the correct cutting ring on the new Dektite's rubber boot that corresponds to the pipe's diameter.
   * The 20% Rule: Using a sharp knife, make a clean, circular cut along the designated ring. The resulting hole should be approximately 20% smaller than the pipe's actual diameter. This is essential to create a tight, stretched, compression seal. Do not cut the hole too large.
 * Step 6: Primary Sealant Application: Apply a thick, continuous 8-10mm bead of approved neutral-cure silicone to the underside of the new Dektite's flexible aluminium base, following the inner edge of the fastener holes.
 * Step 7: Installation & Fastening:
   * Carefully slide the new Dektite over the pipe. The tight rubber boot may require some effort to fit over the top.
   * Press the base firmly onto the cleaned roof sheet, moulding the flexible aluminium edge to conform perfectly to the profile of the roof ribs.
   * Secure the base to the roof sheet with new, approved Class 4 fasteners in every designated hole. Use the "Goldilocks Rule" (SOP-GR1) for tightening to ensure the washers are compressed correctly.
 * Step 8: Secondary Sealant Application & Finishing: For ultimate protection, apply a final, clean bead of silicone around the entire top edge of the Dektite base. Tool this bead off professionally as per SOP-GR2 to create a secondary seal and a flawless finish.
3.2.4. Rationale & Technical Notes: Sizing, Tension & Secondary Seals
 * The Compression Seal: The primary waterproofing function of a Dektite comes from the elastic tension of the rubber boot stretched around the pipe. Cutting the hole 20% smaller than the pipe is a manufacturer's specification designed to create this high-pressure seal, which remains flexible and watertight even with pipe vibration or movement.
 * The Conforming Base: The soft aluminium ring embedded in the Dektite's base is designed to be malleable. It must be carefully moulded to the exact profile of the roof sheet to eliminate any gaps before fastening. The silicone bead underneath acts as a gasket to fill any micro-imperfections.
 * The Secondary Seal: The final bead of sealant applied to the top edge of the base is a CKR Standard of best practice. While not strictly required by the manufacturer, it provides a crucial second layer of defence and prevents water and debris from getting under the edge of the Dektite base over time, significantly increasing the longevity of the repair.
3.2.5. The Master Quality Assurance Checklist & Photo Points
 * QA Checklist:
   * [ ] Was the roof surface 100% clean of old silicone before installation?
   * [ ] Is the new Dektite the correct size for the pipe?
   * [ ] Is the rubber boot tight against the pipe with no visible gaps?
   * [ ] Is the aluminium base fully moulded to the roof profile?
   * [ ] Are all fasteners new, secure, and correctly torqued?
   * [ ] Is the final secondary seal neat, continuous, and professionally tooled?
 * Photo Points: "Before" shot of the old, cracked Dektite. "After" shot of the new, cleanly installed Dektite, with a close-up showing the finished secondary seal and fasteners.
SECTION 4: GUTTER SYSTEMS (INTERNAL CLEANING & SUBCONTRACTOR MANAGEMENT)
4.1. SOP-GR5: Gutter & Downpipe Cleaning (v2.0)
4.1.1. Objective & Scope: Full System Drainage Restoration
Objective: To comprehensively remove all leaves, sludge, silt, and other debris from the guttering system and associated downpipes, restoring the entire roof drainage system to its full, designed capacity and preventing water overflow.
Scope: This is a standalone maintenance service performed by the CKR in-house team. It covers the cleaning of all accessible gutters and the flushing and verification of all associated downpipes on a property.
4.1.2. Required Tools & Equipment
 * Safety: Ladder with a stabiliser/stand-off attachment, full fall protection harness and ropes, waterproof gloves, safety glasses.
 * Debris Removal: Gutter scoop or trowel, heavy-duty buckets or bags.
 * Flushing: High-pressure hose with a trigger nozzle or a pressure washer with a gentle (fan) nozzle.
 * Clean-up: Leaf blower, broom, and shovel for ground-level clean-up.
4.1.3. The CKR 6-Step Gutter Cleaning Procedure
 * Step 1: Safe Ladder Setup & Safety First: Set up the ladder safely on stable, level ground, ensuring it extends at least 1 metre above the gutter line. Adhere to all safety protocols in U-1R.
 * Step 2: Dry Debris Removal (Bulk Removal): Begin at one end of a gutter run. Use a gutter scoop and your hands to remove the bulk of the solid, dry debris (leaves, sticks, nests) and place it into a bucket. It is far more efficient to remove this solid matter manually than to turn it into a wet sludge with the hose.
 * Step 3: Downpipe Mouth Clearing: Before flushing with water, pay special attention to the area directly around the downpipe opening (the "pop"). This is where debris concentrates. Ensure this opening is completely clear by hand to prevent blockages from being forced down the pipe.
 * Step 4: The High-Volume Flush: Starting from the end of the gutter furthest from the downpipe, use the hose to flush all remaining silt and fine debris towards the downpipe. Use a sweeping motion and sufficient water volume to carry the sludge along the length of the gutter and down the pipe.
 * Step 5: Downpipe Verification Flush: Place the hose directly into the top of the downpipe opening and turn it on at full pressure for at least 30-60 seconds. Have a second person (or check yourself) at the ground-level outlet to confirm that there is a strong, continuous flow of water. This is the only way to be 100% certain the downpipe is not blocked internally. If the flow is weak or backs up, the downpipe has an internal blockage that must be cleared.
 * Step 6: Meticulous Ground Clean-up: Once the gutters are clean, perform a thorough clean-up of the ground area. Use a leaf blower and broom to remove any leaves or sludge that fell during the process from paths, driveways, and garden beds. The client's property must be left immaculate.
4.1.4. Rationale & Technical Notes: The High-Volume Flush Technique
Blocked gutters and downpipes are a primary cause of major, expensive property damage. When water cannot escape through the designated system, it backs up and overflows, often into the eaves and wall cavities, causing fascia rot, water staining, and even structural damage. The purpose of the High-Volume Flush is not just to clean the gutter itself, but to use the force of the water to prove the entire system, from the highest point to the final outlet, is functioning correctly. The verification flush in Step 5 is non-negotiable proof of a job done right.
4.1.5. The Master Quality Assurance Checklist & Photo Points
 * QA Checklist:
   * [ ] Are gutters completely free of all solid debris, silt, and sludge?
   * [ ] Has every downpipe been tested and verified to have a strong, clear flow?
   * [ ] Has the ground area around the property been left immaculately clean?
 * Photo Points: A clear "before" shot showing a section of gutter full of leaves and debris. A clear "after" shot of the same section, now perfectly clean, preferably with a little water in the bottom to show it's clear.
4.2. Protocol-GR6: Managing Subcontracted Gutter Installation & Major Repairs (v2.0)
4.2.1. Objective & Scope: Upholding the CKR Standard via Proxy
Objective: To establish a clear, professional, and accountable process for engaging, briefing, and quality-assuring licensed roof plumbers for the installation of new gutter systems or for major repairs that fall outside the scope of the CKR in-house team. Our objective is to ensure that any work organized by CKR meets the CKR Standard, regardless of who performs the labour.
Scope: This protocol covers the management of all subcontracted work related to guttering, downpipes, and fascia covers.
4.2.2. The Decision Protocol: When to Engage a Licensed Roof Plumber
A licensed subcontracted roof plumber MUST be engaged for any of the following tasks:
 * Full Replacement: Any project requiring the replacement of more than one full length (typically 6m) of guttering.
 * New Installations: The installation of any new guttering or downpipes where none existed before.
 * Major Realignment/Repairs: Any work involving significant realignment of the gutter's "fall" or repairs involving soldering or welding.
 * Compliance Certificate Requirement: Any work for which the client or building code requires a VBA Compliance Certificate.
4.2.3. The Handover Package for Gutter Work: Setting the Standard
To ensure clarity and accountability, the CKR Project Manager will provide the subcontracted plumber with a comprehensive digital handover package containing:
 * A Detailed Scope of Works Document: This will clearly state quantities, locations, and specifications. (e.g., "Supply and install approx. 22 linear metres of Colorbond Quad gutter in 'Monument' to the rear and west elevations. Supply and install 2x new 90mm round downpipes to connect to existing stormwater drains.")
 * Material Specifications: A direct link to or data from KF_02 detailing the approved materials, profiles, and colours. No substitutions are permitted without written approval.
 * Marked-Up Site Photos: Our diagnostic "before" photos of the failing gutters, with annotations showing the locations for the new work.
4.2.4. The CKR Quality Assurance Checklist for Subcontracted Gutter Installation
Before CKR approves the subcontractor's final invoice, a CKR Project Manager must attend the site and perform a final inspection using this checklist. The work must pass all points to be considered complete to the CKR Standard.
 * [ ] Correct Fall: A water test has been performed (by pouring a bucket of water into the highest point of each gutter run) and the water flows correctly to the downpipe with no pooling.
 * [ ] Bracket Spacing & Security: Gutter support brackets are installed at a maximum of 1-metre intervals and are securely fastened to the fascia.
 * [ ] Joins, Corners & Stop Ends: All joins, corners, and stop ends are sealed neatly with an approved silicone, are watertight, and are secured with rivets as per manufacturer specifications.
 * [ ] Aesthetics & Finish: The gutter lines are straight and visually appealing. There are no dents, scratches, or damage to the new gutters.
 * [ ] Site Cleanliness: All old guttering, off-cuts, swarf, and project-related rubbish have been completely removed from the site.
 * [ ] Compliance Certificate: The subcontractor has provided the required VBA Plumbing Compliance Certificate for the completed work.
SECTION 5: APPENDIX
5.1. Appendix A: Approved Sealants, Fasteners & Materials (Master List)
| Item ID (from KF_02) | Item Name | Description & Approved Use |
|---|---|---|
| MAT_METAL_SILICONE_300ML | Silicone Sealant (Roof Grade) | Neutral Cure silicone. For all metal roofing, flashings, gutters, and Dektites. DO NOT USE ACETIC CURE. |
| MAT_METAL_SCREWS_100 | Metal Fastening Screws | Buildex (or equivalent) brand, minimum Class 4 corrosion resistance with EPDM washer. For metal sheet and flashing fastening. |
| DEKTITE_STD_VARIOUS | Dektite Flexible Roof Flashing | DEKS brand, EPDM material. Must be sized correctly for the pipe OD. For sealing all pipe penetrations. |
| LEAD_FLASHING_PATCH | Lead Flashing Patch (150x150mm) | Malleable lead sheet. For minor repairs to lead flashings (requires specialized skill). |
5.2. Appendix B: Leak Detection Diagnostic Tree (Visual Flowchart)
[START] -> Is leak visible in roof cavity?
    |
    YES -> Note location relative to pipes/rafters. -> [GO TO ROOF]
    |
    NO -> Note ceiling stain location. -> [GO TO ROOF]

[GO TO ROOF] -> Go to corresponding external location.
    |
    -> PRINCIPLE: Work systematically UP the roof slope from this point.
    |
    -> CHECK 1: Obvious Failures (Cracked Tiles, Rusted Screws, Holes)
        |
        FOUND -> [DIAGNOSIS COMPLETE]
        |
        NOT FOUND -> CHECK 2: Penetrations (Dektites, Vents, Skylights) - Inspect seals.
            |
            FOUND -> [DIAGNOSIS COMPLETE]
            |
            NOT FOUND -> CHECK 3: Flashings (Apron, Step, Barge) - Inspect seals and overlaps.
                |
                FOUND -> [DIAGNOSIS COMPLETE]
                |
                NOT FOUND -> CHECK 4: Watercourses (Valleys, Gutters, Box Gutters) - Check for blockages.
                    |
                    FOUND -> [DIAGNOSIS COMPLETE]
                    |
                    NOT FOUND -> CHECK 5: Porosity/Systemic Failure (Old porous tiles, widespread fastener failure).
                        |
                        FOUND -> Diagnosis may require a larger scope (e.g., Restoration).
                        |
                        NOT FOUND -> [PROCEED TO CONTROLLED WATER TEST - SOP U-2R]

5.3. Appendix C: Common Points of Failure on SE Melbourne Roofs (Photo Guide)
 * Failure 1: Cracked Ridge Capping Pointing
   * Symptom: Water stains on the ceiling near the centre of the house, pieces of mortar found on the ground.
   * Likely Cause: Age, building settlement, and thermal movement causing the rigid mortar and old pointing to crack.
   * Recommended SOP: KF_03 SOP-T3.
   * Diagnostic Photo: A close-up shot showing a clear, wide crack in the flexible pointing along the edge of a ridge cap tile.
 * Failure 2: Perished EPDM Fastener Washer
   * Symptom: A slow, persistent drip leak on a metal roof, often appearing far from the source.
   * Likely Cause: Long-term UV exposure has caused the rubber washer on a roof screw to become brittle and crack, breaking the waterproof seal.
   * Recommended SOP: KF_05 SOP-GR1.
   * Diagnostic Photo: An extreme close-up of a screw head where the black rubber washer is visibly split, crumbled, or missing entirely.
 * Failure 3: Blocked Valley Iron
   * Symptom: Major water ingress during heavy rain, typically where two roof sections meet.
   * Likely Cause: A build-up of leaves and debris has created a dam in the valley, causing water to back up and overflow the edges of the valley iron, entering the roof cavity.
   * Recommended SOP: KF_05 SOP-GR5 (for cleaning).
   * Diagnostic Photo: A shot looking down the length of the valley, clearly showing it packed with leaves and sludge.
5.4. Appendix D: Quick Reference QA Checklists for On-Site Use
QA Checklist: SOP-GR1 Fastener Replacement
 * [ ] Correct Screw (Class 4 min)?
 * [ ] Surface Cleaned?
 * [ ] Washer Correctly Compressed?
 * [ ] Fastener Secure?
 * [ ] Old Screws/Swarf Removed?
QA Checklist: SOP-GR2 Silicone Application
 * [ ] Old Sealant 100% Removed?
 * [ ] Surface Chemically Cleaned?
 * [ ] Neutral Cure Silicone Used?
 * [ ] Bead is Smooth & Uniform?
 * [ ] Edges are Sharp & Clean?
 * [ ] Site is Tidy?
QA Checklist: SOP-GR4 Dektite Replacement
 * [ ] Surface 100% Clean?
 * [ ] Boot Cut Correctly (Tight Fit)?
 * [ ] Base Moulded to Profile?
 * [ ] All Fasteners Secure & New?
 * [ ] Secondary Seal Applied & Tooled?



```