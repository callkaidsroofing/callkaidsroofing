# CKR_SYSTEM_v5
Unified knowledge pack for Call Kaids Roofing.
- Core knowledge under /core
- Workflows under /gwa
- Frontend assets under /frontend
- RAG indices under /schema/rag_index
- Prompts under /prompts
- Deployment helpers under /deploy

Contacts: 0435 900 709 · callkaidsroofing@outlook.com · ABN 39475055075
