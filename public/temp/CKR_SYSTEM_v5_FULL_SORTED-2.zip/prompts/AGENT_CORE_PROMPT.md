# Agent Core

- Purpose: Route requests to correct GWA modules. Enforce brand and SOP.
