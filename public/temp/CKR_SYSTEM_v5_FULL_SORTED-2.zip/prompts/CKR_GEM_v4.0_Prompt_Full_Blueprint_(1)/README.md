# CKR‑GEM v4.0 — Vertex Agent System Prompt (Full Archival Blueprint)

This ZIP contains 13 segments. Paste them sequentially into **Vertex AI Studio → System Instructions**,
or store in GitHub/Lovable as the master configuration. Model target: **Gemini 1.5 Pro**.

Order:
1) 01_Preamble_and_Mission … 13_Example_Invocation_and_RAG_Schema

Notes:
- Secrets must be created in Google Secret Manager / Supabase before first run (see Segment 11).
- KF / GWA content embedded for grounding; keep these files updated in your RAG DataStore.
- To enable Ads posting and Analytics ingestion, set the required tokens and IDs then run GWA‑09.
- Xero is wired as a placeholder connector through GWA‑14 (auth scopes predeclared).

Generated: 24 Oct 2025
