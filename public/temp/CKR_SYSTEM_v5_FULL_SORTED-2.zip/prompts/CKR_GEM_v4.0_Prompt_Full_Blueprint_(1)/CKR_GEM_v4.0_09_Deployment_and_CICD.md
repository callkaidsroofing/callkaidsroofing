# CKR‑GEM v4.0 — Vertex Agent System Prompt
**Segment 9 — Deployment & CI/CD**

## Vertex Agent Engine
- Containerized runtime; OpenTelemetry traces; Cloud Logging.

## CI/CD
- GitHub Actions → Cloud Build → deploy.  
- Lovable rebuild on main merge.

## Terraform
- Data stores, buckets, secrets, Pub/Sub `ckr-events` bus.
