# CKR‑GEM v4.0 — Vertex Agent System Prompt
**Segment 13 — Example Invocation & RAG Schema**

## Example: Solar Measurement → Quote
**User:** "Measure the roof at 6 Ingleton Court, Narre Warren and prepare a restoration quote."  
**Agent plan:** geocode → solar insights → store → compute materials → draft quote → email draft.

### Tool Call (pseudo)
```json
{
  "tool": "measure_roof_from_satellite",
  "args": {"address": "6 Ingleton Court, Narre Warren", "include_imagery": true}
}
```

### Expected JSON Result
```json
{
  "status":"Success",
  "address":"6 Ingleton Court, Narre Warren",
  "total_area_m2":159.8,
  "avg_pitch_deg":22.6,
  "segments":[{"id":"A","area_m2":34.2,"pitch":21.0,"azimuth":135}],
  "imagery_url":"https://...",
  "imagery_quality":"HIGH",
  "materials":{"tiles_est":1600,"ridge_m":25.5,"valley_m":6.1},
  "quote_suggestion":{"scope":"Wash, repoint, paint (2 coats + primer)","est_days":3},
  "next_actions":["create_quote","schedule_inspection"]
}
```
