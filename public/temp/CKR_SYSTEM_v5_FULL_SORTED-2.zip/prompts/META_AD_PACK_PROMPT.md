# Meta Ad Pack Prompt

Generate primary text, headline, description, and CTA. Localise to SE Melbourne.
