-- CKR Supabase schema (minimal starter)
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  given_name text,
  family_name text,
  phone text,
  email text,
  address_line text,
  suburb text,
  state text,
  postcode text,
  source text,
  notes text,
  status text default 'new'
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  lead_id uuid references public.leads(id) on delete set null,
  address_line text,
  suburb text,
  state text,
  postcode text,
  scope jsonb,
  price_aud numeric,
  gst_included boolean default true,
  status text default 'quoted'
);

create table if not exists public.prompts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text unique,
  body text,
  tags text[]
);