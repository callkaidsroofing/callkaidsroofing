# Visual Guidance
- Real jobsite photos only. No stock.
- Before/after transformations.
- Colour accents: #007ACC on dark neutrals.
- Warranty badges: 7–10 year wording.