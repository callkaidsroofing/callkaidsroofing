export default function SkeletonCard(){
  return <div className="h-24 rounded-xl animate-pulse bg-slate-200" />;
}
