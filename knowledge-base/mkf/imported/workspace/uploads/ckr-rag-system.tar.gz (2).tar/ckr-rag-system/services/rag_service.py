#!/usr/bin/env python3
"""
CKR RAG Ingestion Service
FastAPI service for real-time document ingestion with GitHub webhook support
Author: Call Kaids Roofing
Version: 1.0.0
"""

import os
import hmac
import hashlib
import json
import time
import io
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, Header, Request, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from pypdf import PdfReader
from pinecone import Pinecone, ServerlessSpec
from openai import OpenAI
import requests

load_dotenv()

# Environment variables
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
INDEX_NAME = os.getenv("INDEX_NAME", "ckr-knowledge")
PINECONE_ENV = os.getenv("PINECONE_ENV", "us-east-1")
GITHUB_SECRET = os.getenv("GITHUB_WEBHOOK_SECRET", "")
RAG_TOKEN = os.getenv("RAG_TOKEN", "")
ALLOWED_REPO = os.getenv("ALLOWED_REPO", "")

# Initialize clients
pc = Pinecone(api_key=PINECONE_API_KEY)
oai = OpenAI(api_key=OPENAI_API_KEY)

# Initialize FastAPI app
app = FastAPI(
    title="CKR RAG Ingestion Service",
    description="Real-time document ingestion service for Call Kaids Roofing",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- Embedding Functions ----------
def embed_texts(texts: List[str], model="text-embedding-3-small") -> List[List[float]]:
    """Generate embeddings for a list of texts."""
    resp = oai.embeddings.create(model=model, input=texts)
    return [d.embedding for d in resp.data]


def embedding_dim() -> int:
    """Get the dimension of the embedding model."""
    return len(embed_texts(["probe"])[0])


# ---------- Pinecone Index Management ----------
def ensure_index(index_name: str, dim: int):
    """Create Pinecone index if it doesn't exist."""
    names = {i["name"] for i in pc.list_indexes().indexes}
    if index_name not in names:
        pc.create_index(
            name=index_name,
            dimension=dim,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region=PINECONE_ENV)
        )
        while True:
            if pc.describe_index(index_name).status["ready"]:
                break
            time.sleep(1)
        print(f"✓ Created index: {index_name}")


# Initialize index on startup
ensure_index(INDEX_NAME, embedding_dim())
index = pc.Index(INDEX_NAME)


# ---------- Utility Functions ----------
def sha24(s: str) -> str:
    """Generate a short SHA256 hash for ID generation."""
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:24]


def split_text(text: str, size=1200, overlap=100) -> List[str]:
    """Split text into overlapping chunks."""
    out, i, n = [], 0, len(text)
    while i < n:
        j = min(i + size, n)
        out.append(text[i:j])
        i = j - overlap if j < n else n
    return out


def read_pdf_bytes(b: bytes) -> str:
    """Extract text from PDF bytes."""
    reader = PdfReader(io.BytesIO(b))
    parts = []
    for p in reader.pages:
        try:
            parts.append(p.extract_text() or "")
        except Exception:
            parts.append("")
    return "\n".join(parts).strip()


def as_text(path: str, b: bytes) -> str:
    """Convert file bytes to text based on extension."""
    pl = path.lower()
    if pl.endswith(".pdf"):
        return read_pdf_bytes(b)
    # Try decode as UTF-8
    try:
        return b.decode("utf-8")
    except Exception:
        return ""


# ---------- Document Processing ----------
def upsert_document(text: str, metadata: Dict[str, Any], source_path: str):
    """
    Chunk, embed, and upsert a document to Pinecone.
    
    Args:
        text: Document text content
        metadata: Document metadata
        source_path: Unique source path identifier
    """
    chunks = split_text(text)
    embeds = embed_texts(chunks) if chunks else []
    uid = sha24(source_path)
    vectors = []
    
    for i, (ch, emb) in enumerate(zip(chunks, embeds)):
        vid = f"{uid}-{i:04d}"
        meta = dict(metadata)
        meta.update({"text": ch, "source_path": source_path})
        vectors.append({"id": vid, "values": emb, "metadata": meta})
    
    if vectors:
        index.upsert(vectors=vectors, namespace="ckr")
        print(f"✓ Upserted {len(vectors)} vectors for {source_path}")


def delete_by_source_path(source_path: str):
    """Delete all vectors associated with a source path."""
    index.delete(namespace="ckr", filter={"source_path": {"$eq": source_path}})
    print(f"✓ Deleted vectors for {source_path}")


# ---------- Security Functions ----------
def verify_github_signature(payload: bytes, signature: str):
    """Verify GitHub webhook signature."""
    if not GITHUB_SECRET:
        raise HTTPException(500, "Webhook secret not set")
    mac = hmac.new(GITHUB_SECRET.encode(), msg=payload, digestmod=hashlib.sha256)
    expected = "sha256=" + mac.hexdigest()
    if not hmac.compare_digest(expected, signature or ""):
        raise HTTPException(401, "Bad signature")


def require_bearer(auth: Optional[str] = Header(None)):
    """Require bearer token authentication."""
    if not auth or not auth.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    token = auth.split(" ", 1)[1]
    if token != RAG_TOKEN:
        raise HTTPException(403, "Invalid token")


# ---------- GitHub Integration ----------
def fetch_raw(owner_repo: str, sha: str, path: str) -> bytes:
    """Fetch raw file content from GitHub."""
    url = f"https://raw.githubusercontent.com/{owner_repo}/{sha}/{path}"
    r = requests.get(url, timeout=20)
    if r.status_code == 200:
        return r.content
    return b""


WATCH_GLOBS = (".pdf", ".txt", ".md", ".json")


def should_watch(path: str) -> bool:
    """Check if a file path should be watched for ingestion."""
    pl = path.lower()
    if not pl.endswith(WATCH_GLOBS):
        return False
    # Add folder restrictions if needed
    # return pl.startswith(("data/", "knowledge/", "docs/"))
    return True


# ---------- API Endpoints ----------
@app.get("/")
async def root():
    """Root endpoint with service information."""
    return {
        "service": "CKR RAG Ingestion Service",
        "version": "1.0.0",
        "status": "operational",
        "index": INDEX_NAME
    }


@app.get("/health")
async def health():
    """Health check endpoint."""
    try:
        # Check Pinecone connection
        stats = index.describe_index_stats()
        return {
            "status": "healthy",
            "index": INDEX_NAME,
            "vectors": stats.total_vector_count,
            "namespaces": list(stats.namespaces.keys()) if stats.namespaces else []
        }
    except Exception as e:
        raise HTTPException(500, f"Health check failed: {str(e)}")


@app.post("/webhooks/github")
async def github_webhook(
    request: Request,
    x_hub_signature_256: Optional[str] = Header(None),
    x_github_event: str = Header("push")
):
    """
    Handle GitHub webhook events for automatic document ingestion.
    
    Processes push events to automatically ingest changed files.
    """
    body = await request.body()
    verify_github_signature(body, x_hub_signature_256)
    event = json.loads(body.decode("utf-8"))
    
    if x_github_event != "push":
        return {"ok": True, "ignored": x_github_event}

    repo = event.get("repository", {}).get("full_name", "")
    if ALLOWED_REPO and repo != ALLOWED_REPO:
        raise HTTPException(403, "Repository not allowed")

    after = event.get("after") or "main"
    changes = {
        "added": [],
        "modified": [],
        "removed": []
    }
    
    for c in event.get("commits", []):
        changes["added"] += c.get("added", [])
        changes["modified"] += c.get("modified", [])
        changes["removed"] += c.get("removed", [])

    upserted = 0
    deleted = 0

    # Process upserts
    for path in set(changes["added"] + changes["modified"]):
        if not should_watch(path):
            continue
        raw = fetch_raw(repo, after, path)
        text = as_text(path, raw)
        if not text:
            continue
        
        meta = {
            "type": "repo",
            "repo": repo,
            "commit": after,
            "path": path,
            "source": "github",
            "date": time.strftime("%Y-%m-%d")
        }
        upsert_document(text, meta, source_path=f"git://{repo}@{after}/{path}")
        upserted += 1

    # Process deletes
    for path in set(changes["removed"]):
        if not should_watch(path):
            continue
        delete_by_source_path(f"git://{repo}@{after}/{path}")
        deleted += 1

    return {
        "ok": True,
        "repo": repo,
        "commit": after,
        "upserted": upserted,
        "deleted": deleted
    }


@app.post("/upsert")
async def upsert(payload: Dict[str, Any], auth=Depends(require_bearer)):
    """
    Manually upsert a document to the RAG system.
    
    Request body:
    {
      "text": "document content",
      "metadata": {...},
      "source_path": "backend://jobs/123"
    }
    """
    text = payload.get("text", "")
    meta = payload.get("metadata", {}) or {}
    source_path = payload.get("source_path", "")
    
    if not text or not source_path:
        raise HTTPException(400, "text and source_path required")
    
    upsert_document(text, meta, source_path)
    
    return {
        "ok": True,
        "source_path": source_path,
        "chunks": len(split_text(text))
    }


@app.post("/delete")
async def delete(payload: Dict[str, Any], auth=Depends(require_bearer)):
    """
    Delete a document from the RAG system.
    
    Request body:
    {
      "source_path": "backend://jobs/123"
    }
    """
    sp = payload.get("source_path", "")
    if not sp:
        raise HTTPException(400, "source_path required")
    
    delete_by_source_path(sp)
    
    return {
        "ok": True,
        "source_path": sp
    }


@app.post("/query")
async def query(payload: Dict[str, Any], auth=Depends(require_bearer)):
    """
    Query the RAG system for relevant documents.
    
    Request body:
    {
      "query": "search query",
      "top_k": 8,
      "filter": {...}
    }
    """
    query_text = payload.get("query", "")
    top_k = payload.get("top_k", 8)
    filter_meta = payload.get("filter", {})
    
    if not query_text:
        raise HTTPException(400, "query required")
    
    # Generate query embedding
    q_emb = embed_texts([query_text])[0]
    
    # Query Pinecone
    res = index.query(
        vector=q_emb,
        top_k=top_k,
        namespace="ckr",
        include_metadata=True,
        filter=filter_meta or {}
    )
    
    # Format results
    matches = []
    for m in res.matches:
        matches.append({
            "id": m.id,
            "score": m.score,
            "metadata": m.metadata
        })
    
    return {
        "ok": True,
        "query": query_text,
        "matches": matches
    }


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
