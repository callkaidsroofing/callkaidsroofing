#!/usr/bin/env python3
"""
CKR Supabase Pull Worker
Polls the Supabase rag_queue table and processes pending RAG operations
Author: Call Kaids Roofing
Version: 1.0.0
"""

import os
import time
import json
import logging
from datetime import datetime
from typing import Dict, Any, List
from dotenv import load_dotenv
import requests
from supabase import create_client, Client

load_dotenv()

# Environment variables
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")
RAG_URL = os.getenv("RAG_URL", "http://localhost:8080")
RAG_TOKEN = os.getenv("RAG_TOKEN")
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", "3"))  # seconds
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "50"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("ckr-rag-worker")

# Initialize Supabase client
if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
    raise ValueError("SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set")

sb: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)


class RAGWorker:
    """Worker that polls Supabase and processes RAG operations."""
    
    def __init__(self):
        self.processed_count = 0
        self.error_count = 0
        self.start_time = datetime.now()
        
    def process_operation(self, row: Dict[str, Any]) -> bool:
        """
        Process a single RAG operation.
        
        Args:
            row: Queue row from Supabase
            
        Returns:
            True if successful, False otherwise
        """
        try:
            operation = row["op"]
            source_path = row["source_path"]
            
            if operation == "delete":
                # Process delete operation
                response = requests.post(
                    f"{RAG_URL}/delete",
                    headers={
                        "Authorization": f"Bearer {RAG_TOKEN}",
                        "Content-Type": "application/json"
                    },
                    json={"source_path": source_path},
                    timeout=30
                )
                response.raise_for_status()
                logger.info(f"✓ Deleted: {source_path}")
                
            elif operation == "upsert":
                # Process upsert operation
                payload = row.get("payload", {})
                metadata = row.get("metadata", {})
                
                # Convert payload to text if it's a dict
                if isinstance(payload, dict):
                    text = json.dumps(payload, ensure_ascii=False)
                else:
                    text = str(payload)
                
                response = requests.post(
                    f"{RAG_URL}/upsert",
                    headers={
                        "Authorization": f"Bearer {RAG_TOKEN}",
                        "Content-Type": "application/json"
                    },
                    json={
                        "text": text,
                        "metadata": metadata,
                        "source_path": source_path
                    },
                    timeout=30
                )
                response.raise_for_status()
                logger.info(f"✓ Upserted: {source_path}")
            
            else:
                logger.warning(f"Unknown operation: {operation}")
                return False
            
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"✗ Request failed for {row['source_path']}: {str(e)}")
            return False
        except Exception as e:
            logger.error(f"✗ Unexpected error for {row['source_path']}: {str(e)}")
            return False
    
    def mark_processed(self, row_id: int, success: bool, error_msg: str = None):
        """
        Mark a queue item as processed.
        
        Args:
            row_id: Queue row ID
            success: Whether processing was successful
            error_msg: Error message if failed
        """
        try:
            if success:
                sb.table("rag_queue").update({
                    "processed_at": datetime.now().isoformat()
                }).eq("id", row_id).execute()
                self.processed_count += 1
            else:
                sb.table("rag_queue").update({
                    "processed_at": datetime.now().isoformat(),
                    "error": error_msg or "Unknown error"
                }).eq("id", row_id).execute()
                self.error_count += 1
                
        except Exception as e:
            logger.error(f"Failed to mark row {row_id} as processed: {str(e)}")
    
    def cycle(self):
        """Process one batch of pending operations."""
        try:
            # Fetch pending operations
            response = sb.table("rag_queue")\
                .select("*")\
                .is_("processed_at", "null")\
                .order("created_at")\
                .limit(BATCH_SIZE)\
                .execute()
            
            rows = response.data
            
            if not rows:
                return  # No pending operations
            
            logger.info(f"📦 Processing batch of {len(rows)} operations...")
            
            # Process each operation
            for row in rows:
                row_id = row["id"]
                retry_count = row.get("retry_count", 0)
                
                # Skip if max retries exceeded
                if retry_count >= MAX_RETRIES:
                    logger.warning(f"⚠️  Skipping row {row_id}: max retries exceeded")
                    self.mark_processed(row_id, False, f"Max retries ({MAX_RETRIES}) exceeded")
                    continue
                
                # Process the operation
                success = self.process_operation(row)
                
                # Mark as processed
                if success:
                    self.mark_processed(row_id, True)
                else:
                    # Increment retry count
                    sb.table("rag_queue").update({
                        "retry_count": retry_count + 1
                    }).eq("id", row_id).execute()
                    
                    # Mark as failed if max retries reached
                    if retry_count + 1 >= MAX_RETRIES:
                        self.mark_processed(row_id, False, f"Failed after {MAX_RETRIES} attempts")
            
            logger.info(f"✅ Batch complete. Processed: {self.processed_count}, Errors: {self.error_count}")
            
        except Exception as e:
            logger.error(f"Cycle error: {str(e)}")
    
    def run(self):
        """Main worker loop."""
        logger.info("🚀 CKR RAG Worker starting...")
        logger.info(f"   RAG Service: {RAG_URL}")
        logger.info(f"   Poll Interval: {POLL_INTERVAL}s")
        logger.info(f"   Batch Size: {BATCH_SIZE}")
        logger.info(f"   Max Retries: {MAX_RETRIES}")
        logger.info("")
        
        while True:
            try:
                self.cycle()
            except KeyboardInterrupt:
                logger.info("\n👋 Worker stopped by user")
                break
            except Exception as e:
                logger.error(f"Unexpected error in main loop: {str(e)}")
            
            # Wait before next cycle
            time.sleep(POLL_INTERVAL)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get worker statistics."""
        uptime = (datetime.now() - self.start_time).total_seconds()
        return {
            "uptime_seconds": uptime,
            "processed_count": self.processed_count,
            "error_count": self.error_count,
            "success_rate": (
                self.processed_count / (self.processed_count + self.error_count)
                if (self.processed_count + self.error_count) > 0
                else 0
            )
        }


def check_queue_stats():
    """Check and display queue statistics."""
    try:
        response = sb.rpc("get_rag_queue_stats").execute()
        stats = response.data[0] if response.data else {}
        
        print("\n" + "="*60)
        print("RAG QUEUE STATISTICS")
        print("="*60)
        print(f"Total Pending:    {stats.get('total_pending', 0)}")
        print(f"Total Processed:  {stats.get('total_processed', 0)}")
        print(f"Total Errors:     {stats.get('total_errors', 0)}")
        print(f"Oldest Pending:   {stats.get('oldest_pending', 'N/A')}")
        print(f"Avg Process Time: {stats.get('avg_processing_time', 'N/A')}")
        print("="*60 + "\n")
        
    except Exception as e:
        logger.error(f"Failed to get queue stats: {str(e)}")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description="CKR Supabase RAG Worker - Process pending RAG operations"
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="Show queue statistics and exit"
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="Process one batch and exit (useful for testing)"
    )
    
    args = parser.parse_args()
    
    if args.stats:
        check_queue_stats()
    elif args.once:
        worker = RAGWorker()
        worker.cycle()
        print(f"\nProcessed: {worker.processed_count}, Errors: {worker.error_count}")
    else:
        worker = RAGWorker()
        try:
            worker.run()
        except KeyboardInterrupt:
            print("\n")
            stats = worker.get_stats()
            print("="*60)
            print("WORKER STATISTICS")
            print("="*60)
            print(f"Uptime:        {stats['uptime_seconds']:.0f}s")
            print(f"Processed:     {stats['processed_count']}")
            print(f"Errors:        {stats['error_count']}")
            print(f"Success Rate:  {stats['success_rate']*100:.1f}%")
            print("="*60)
