-- CKR RAG System - Supabase Database Schema
-- This schema creates the necessary tables and triggers for RAG queue management
-- Author: Call Kaids Roofing
-- Version: 1.0.0

-- ============================================================================
-- RAG Queue Table
-- ============================================================================
-- This table stores pending RAG operations (upsert/delete) for processing

CREATE TABLE IF NOT EXISTS rag_queue (
  id BIGSERIAL PRIMARY KEY,
  source_path TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  op TEXT NOT NULL CHECK (op IN ('upsert', 'delete')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  error TEXT,
  retry_count INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT valid_operation CHECK (op IN ('upsert', 'delete'))
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_rag_queue_processed ON rag_queue(processed_at) WHERE processed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_rag_queue_created ON rag_queue(created_at);
CREATE INDEX IF NOT EXISTS idx_rag_queue_source_path ON rag_queue(source_path);

-- Add comments for documentation
COMMENT ON TABLE rag_queue IS 'Queue for RAG ingestion operations triggered by database changes';
COMMENT ON COLUMN rag_queue.source_path IS 'Unique identifier for the document source (e.g., backend://jobs/123)';
COMMENT ON COLUMN rag_queue.payload IS 'Full document data as JSONB';
COMMENT ON COLUMN rag_queue.metadata IS 'Document metadata for filtering and retrieval';
COMMENT ON COLUMN rag_queue.op IS 'Operation type: upsert or delete';
COMMENT ON COLUMN rag_queue.processed_at IS 'Timestamp when the operation was processed (NULL = pending)';
COMMENT ON COLUMN rag_queue.error IS 'Error message if processing failed';
COMMENT ON COLUMN rag_queue.retry_count IS 'Number of times this operation has been retried';


-- ============================================================================
-- Trigger Function: Enqueue RAG Changes
-- ============================================================================
-- This function automatically enqueues RAG operations when records change

CREATE OR REPLACE FUNCTION enqueue_rag_change() 
RETURNS TRIGGER AS $$
BEGIN
  -- Handle DELETE operations
  IF (TG_OP = 'DELETE') THEN
    INSERT INTO rag_queue(source_path, payload, metadata, op)
    VALUES (
      'backend://' || TG_TABLE_NAME || '/' || OLD.id,
      '{}'::jsonb,
      jsonb_build_object(
        'type', TG_TABLE_NAME,
        'doc_id', OLD.id,
        'deleted_at', NOW()
      ),
      'delete'
    );
    RETURN OLD;
  END IF;

  -- Handle INSERT and UPDATE operations
  INSERT INTO rag_queue(source_path, payload, metadata, op)
  VALUES (
    'backend://' || TG_TABLE_NAME || '/' || NEW.id,
    to_jsonb(NEW),
    jsonb_build_object(
      'type', TG_TABLE_NAME,
      'doc_id', NEW.id,
      'suburb', COALESCE(NEW.suburb, ''),
      'status', COALESCE(NEW.status, ''),
      'date', COALESCE(NEW.date, NOW()::date),
      'updated_at', NOW()
    ),
    'upsert'
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION enqueue_rag_change() IS 'Trigger function to automatically enqueue RAG operations on table changes';


-- ============================================================================
-- Triggers for Jobs Table
-- ============================================================================

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS trg_rag_jobs ON jobs;

-- Create trigger for jobs table
CREATE TRIGGER trg_rag_jobs 
AFTER INSERT OR UPDATE OR DELETE ON jobs
FOR EACH ROW 
EXECUTE FUNCTION enqueue_rag_change();

COMMENT ON TRIGGER trg_rag_jobs ON jobs IS 'Automatically enqueue RAG operations when jobs are created, updated, or deleted';


-- ============================================================================
-- Triggers for Quotes Table
-- ============================================================================

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS trg_rag_quotes ON quotes;

-- Create trigger for quotes table
CREATE TRIGGER trg_rag_quotes 
AFTER INSERT OR UPDATE OR DELETE ON quotes
FOR EACH ROW 
EXECUTE FUNCTION enqueue_rag_change();

COMMENT ON TRIGGER trg_rag_quotes ON quotes IS 'Automatically enqueue RAG operations when quotes are created, updated, or deleted';


-- ============================================================================
-- Triggers for Leads Table (Optional)
-- ============================================================================

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS trg_rag_leads ON leads;

-- Create trigger for leads table
CREATE TRIGGER trg_rag_leads 
AFTER INSERT OR UPDATE OR DELETE ON leads
FOR EACH ROW 
EXECUTE FUNCTION enqueue_rag_change();

COMMENT ON TRIGGER trg_rag_leads ON leads IS 'Automatically enqueue RAG operations when leads are created, updated, or deleted';


-- ============================================================================
-- Triggers for Testimonials Table (Optional)
-- ============================================================================

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS trg_rag_testimonials ON testimonials;

-- Create trigger for testimonials table
CREATE TRIGGER trg_rag_testimonials 
AFTER INSERT OR UPDATE OR DELETE ON testimonials
FOR EACH ROW 
EXECUTE FUNCTION enqueue_rag_change();

COMMENT ON TRIGGER trg_rag_testimonials ON testimonials IS 'Automatically enqueue RAG operations when testimonials are created, updated, or deleted';


-- ============================================================================
-- Helper Functions
-- ============================================================================

-- Function to manually enqueue a RAG operation
CREATE OR REPLACE FUNCTION manual_enqueue_rag(
  p_table_name TEXT,
  p_record_id BIGINT,
  p_operation TEXT DEFAULT 'upsert'
)
RETURNS BIGINT AS $$
DECLARE
  v_queue_id BIGINT;
  v_record JSONB;
BEGIN
  -- Validate operation
  IF p_operation NOT IN ('upsert', 'delete') THEN
    RAISE EXCEPTION 'Invalid operation: %. Must be upsert or delete', p_operation;
  END IF;

  -- For upsert, fetch the record
  IF p_operation = 'upsert' THEN
    EXECUTE format('SELECT to_jsonb(t.*) FROM %I t WHERE id = $1', p_table_name)
    INTO v_record
    USING p_record_id;
    
    IF v_record IS NULL THEN
      RAISE EXCEPTION 'Record not found: %.id = %', p_table_name, p_record_id;
    END IF;
  ELSE
    v_record := '{}'::jsonb;
  END IF;

  -- Insert into queue
  INSERT INTO rag_queue(source_path, payload, metadata, op)
  VALUES (
    'backend://' || p_table_name || '/' || p_record_id,
    v_record,
    jsonb_build_object(
      'type', p_table_name,
      'doc_id', p_record_id,
      'manual_enqueue', TRUE,
      'enqueued_at', NOW()
    ),
    p_operation
  )
  RETURNING id INTO v_queue_id;

  RETURN v_queue_id;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION manual_enqueue_rag IS 'Manually enqueue a RAG operation for a specific record';


-- Function to get queue statistics
CREATE OR REPLACE FUNCTION get_rag_queue_stats()
RETURNS TABLE(
  total_pending BIGINT,
  total_processed BIGINT,
  total_errors BIGINT,
  oldest_pending TIMESTAMPTZ,
  avg_processing_time INTERVAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(*) FILTER (WHERE processed_at IS NULL) AS total_pending,
    COUNT(*) FILTER (WHERE processed_at IS NOT NULL AND error IS NULL) AS total_processed,
    COUNT(*) FILTER (WHERE error IS NOT NULL) AS total_errors,
    MIN(created_at) FILTER (WHERE processed_at IS NULL) AS oldest_pending,
    AVG(processed_at - created_at) FILTER (WHERE processed_at IS NOT NULL) AS avg_processing_time
  FROM rag_queue;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION get_rag_queue_stats IS 'Get statistics about the RAG queue';


-- Function to retry failed operations
CREATE OR REPLACE FUNCTION retry_failed_rag_operations(max_retries INT DEFAULT 3)
RETURNS INTEGER AS $$
DECLARE
  v_count INTEGER;
BEGIN
  UPDATE rag_queue
  SET 
    processed_at = NULL,
    retry_count = retry_count + 1,
    error = NULL
  WHERE 
    error IS NOT NULL 
    AND retry_count < max_retries
    AND processed_at IS NOT NULL;
  
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION retry_failed_rag_operations IS 'Reset failed operations for retry (up to max_retries)';


-- ============================================================================
-- Row Level Security (RLS) Policies
-- ============================================================================

-- Enable RLS on rag_queue table
ALTER TABLE rag_queue ENABLE ROW LEVEL SECURITY;

-- Policy: Service role can do everything
CREATE POLICY "Service role has full access to rag_queue"
ON rag_queue
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Policy: Authenticated users can view queue status (read-only)
CREATE POLICY "Authenticated users can view rag_queue"
ON rag_queue
FOR SELECT
TO authenticated
USING (true);


-- ============================================================================
-- Grants
-- ============================================================================

-- Grant necessary permissions to service role
GRANT ALL ON rag_queue TO service_role;
GRANT USAGE, SELECT ON SEQUENCE rag_queue_id_seq TO service_role;
GRANT EXECUTE ON FUNCTION enqueue_rag_change() TO service_role;
GRANT EXECUTE ON FUNCTION manual_enqueue_rag(TEXT, BIGINT, TEXT) TO service_role;
GRANT EXECUTE ON FUNCTION get_rag_queue_stats() TO service_role;
GRANT EXECUTE ON FUNCTION retry_failed_rag_operations(INT) TO service_role;

-- Grant read-only access to authenticated users
GRANT SELECT ON rag_queue TO authenticated;
GRANT EXECUTE ON FUNCTION get_rag_queue_stats() TO authenticated;


-- ============================================================================
-- Initial Data / Testing
-- ============================================================================

-- You can uncomment this section to test the queue system
/*
-- Test manual enqueue
SELECT manual_enqueue_rag('jobs', 1, 'upsert');

-- Check queue stats
SELECT * FROM get_rag_queue_stats();

-- View pending operations
SELECT * FROM rag_queue WHERE processed_at IS NULL ORDER BY created_at;
*/
