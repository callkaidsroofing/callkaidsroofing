# CKR RAG System - Quick Start Guide

This guide will get you up and running with the CKR RAG system in under 10 minutes.

## Prerequisites

Before you begin, ensure you have:

- [ ] Docker and Docker Compose installed
- [ ] A Pinecone account with an index created (dimension: 1536)
- [ ] An OpenAI API key
- [ ] A Supabase project with the service role key
- [ ] Access to the `callkaidsroofing/callkaidsroofing` GitHub repository

## Step 1: Configure Environment Variables

1. Copy the template:
   ```bash
   cp .env.template .env
   ```

2. Edit `.env` and fill in your credentials:
   ```bash
   # Pinecone Configuration
   PINECONE_API_KEY=your_new_pinecone_key_here  # ROTATE THE OLD KEY!
   PINECONE_ENV=us-east-1
   INDEX_NAME=ckr-knowledge

   # OpenAI Configuration
   OPENAI_API_KEY=your_openai_key_here

   # GitHub Webhook Security
   GITHUB_WEBHOOK_SECRET=generate_a_random_string_here
   ALLOWED_REPO=callkaidsroofing/callkaidsroofing

   # RAG Service Authentication
   RAG_TOKEN=generate_another_random_string_here

   # Supabase Configuration
   SUPABASE_URL=https://your-project.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
   ```

## Step 2: Set Up Supabase Database

1. Go to your Supabase project's SQL Editor
2. Copy and paste the entire contents of `deployment/supabase_schema.sql`
3. Click "Run" to execute the script
4. Verify the `rag_queue` table was created

## Step 3: Create Pinecone Index

If you haven't already created a Pinecone index:

1. Log in to [Pinecone Console](https://app.pinecone.io/)
2. Click "Create Index"
3. Name: `ckr-knowledge` (or match your `INDEX_NAME` in `.env`)
4. Dimensions: `1536`
5. Metric: `cosine`
6. Click "Create Index"

## Step 4: Start the Services

Run the entire system with Docker Compose:

```bash
docker-compose -f deployment/docker-compose.yml up --build -d
```

Check the logs to ensure everything is running:

```bash
docker-compose -f deployment/docker-compose.yml logs -f
```

You should see:
- `ckr-rag-service` listening on port 8080
- `ckr-supabase-worker` polling for new records

## Step 5: Test the System

### Test the Health Endpoint

```bash
curl http://localhost:8080/health
```

Expected response:
```json
{
  "status": "healthy",
  "service": "CKR RAG Ingestion Service",
  "version": "1.0.0"
}
```

### Test the Search UI

1. Open your browser to `http://localhost:8080/ui/` (or open `ui/index.html` locally)
2. Enter your `RAG_TOKEN` when prompted
3. Try a test query: "roof restoration in Berwick"

### Test Manual Ingestion

```bash
curl -X POST http://localhost:8080/upsert \
  -H "Authorization: Bearer YOUR_RAG_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "Test document for CKR RAG system",
    "metadata": {
      "type": "note",
      "suburb": "Berwick",
      "date": "2025-11-04"
    },
    "source_path": "test/sample-note.txt"
  }'
```

## Step 6: Set Up GitHub Webhook (Optional but Recommended)

For production deployment, set up the GitHub webhook:

1. Deploy your service to a public URL (e.g., Fly.io, Render, Railway)
2. Go to your GitHub repository settings
3. Navigate to **Webhooks** → **Add webhook**
4. **Payload URL:** `https://your-app-url.com/webhook/github`
5. **Content type:** `application/json`
6. **Secret:** Your `GITHUB_WEBHOOK_SECRET` from `.env`
7. **Events:** Select "Just the push event"
8. Click **Add webhook**

## Step 7: Attach Supabase Triggers (Optional)

To enable automatic sync from Supabase tables:

```sql
-- Example: Attach triggers to a 'jobs' table
CREATE TRIGGER on_job_insert
  AFTER INSERT ON jobs
  FOR EACH ROW EXECUTE PROCEDURE handle_rag_upsert('job', 'id');

CREATE TRIGGER on_job_update
  AFTER UPDATE ON jobs
  FOR EACH ROW EXECUTE PROCEDURE handle_rag_upsert('job', 'id');

CREATE TRIGGER on_job_delete
  AFTER DELETE ON jobs
  FOR EACH ROW EXECUTE PROCEDURE handle_rag_delete('job', 'id');
```

Repeat for other tables like `quotes`, `leads`, etc.

## Troubleshooting

### Service won't start

- Check that all environment variables are set correctly in `.env`
- Ensure Docker is running and has sufficient resources
- Check logs: `docker-compose -f deployment/docker-compose.yml logs`

### Pinecone connection errors

- Verify your API key is correct and not expired
- Ensure the index name matches exactly
- Check that the index dimension is 1536

### Webhook not receiving events

- Use [ngrok](https://ngrok.com/) for local testing: `ngrok http 8080`
- Verify the webhook secret matches exactly
- Check GitHub webhook delivery logs for error details

### Worker not processing queue

- Verify Supabase credentials are correct
- Check that the `rag_queue` table exists
- Ensure the worker container is running: `docker ps`

## Next Steps

- Read the full [README.md](README.md) for detailed documentation
- Review the [API documentation](services/rag_service.py) for advanced usage
- Customize metadata fields for your specific use case
- Set up monitoring and alerting for production

## Security Reminder

⚠️ **IMPORTANT:** The Pinecone API key shared earlier in this conversation has been compromised. Please:

1. Go to your Pinecone dashboard
2. Delete the old key: `pcsk_3GUFms_99Rxx...`
3. Generate a new key
4. Update your `.env` file with the new key
5. Restart the services

---

**Need help?** Contact Kaidyn Brownlie at callkaidsroofing@outlook.com
