'''
# CKR RAG System: Real-Time Knowledge Base for Call Kaids Roofing

**Version:** 1.0.0  
**Author:** Manus AI, with approval from Kaidyn Brownlie

---

## 1. Project Overview

This repository contains the complete implementation of a production-grade **Retrieval-Augmented Generation (RAG) system** for Call Kaids Roofing (CKR). The system provides a real-time, searchable knowledge base that allows the CKR-Helper assistant and other internal tools to access and query information from various sources, including jobs, quotes, notes, and the company's GitHub repository.

The primary goal of this system is to create a "single source of truth" that is always up-to-date, enabling accurate, context-aware responses to a wide range of queries. It is designed to be scalable, secure, and easy to maintain.

## 2. System Architecture

The architecture is designed for real-time data synchronization and efficient querying. It consists of several key components that work together seamlessly.

![System Architecture Diagram](https://i.imgur.com/example.png)  
*(Note: A proper architecture diagram should be generated and linked here.)*

### Core Components:

| Component               | Description                                                                                                                                 | Technology Stack        |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------- |
| **Vector Database**     | Stores document embeddings and metadata for fast similarity search.                                                                         | Pinecone                |
| **Embedding Model**     | Converts text documents into numerical vector representations.                                                                              | OpenAI `text-embedding-3-small` |
| **LLM for Answering**   | Generates human-like answers based on the retrieved context.                                                                                | OpenAI `gpt-4o-mini`          |
| **Ingestion Service**   | A FastAPI application that handles data ingestion from multiple sources, processes it, and upserts it into the vector database.             | FastAPI, Python         |
| **Supabase Integration**| A PostgreSQL database and backend-as-a-service platform used for structured data storage and real-time event handling.                      | Supabase (Postgres)     |
| **Polling Worker**      | A background worker that polls a Supabase table for new data, processing it in batches to sync with the RAG system.                       | Python, Supabase-py     |
| **Search UI**           | A simple, brand-compliant web interface for manually querying the RAG system.                                                               | HTML, CSS, JavaScript   |

### Data Flow:

1.  **GitHub:** Changes pushed to the `callkaidsroofing/callkaidsroofing` repository trigger a **webhook**. The Ingestion Service receives the webhook, clones the repo, processes the files, and upserts them into Pinecone.
2.  **Supabase:** Changes to specified tables (e.g., `jobs`, `quotes`) insert a record into a `rag_queue` table via a database trigger. The **Polling Worker** periodically fetches new records from this queue, processes them, and calls the Ingestion Service to upsert the data.
3.  **Direct API Calls:** Other backend services can directly call the Ingestion Service's `/upsert` or `/delete` endpoints to manage data in real-time.

## 3. Features

-   **Real-Time Sync:** Data from GitHub and Supabase is automatically synchronized with the RAG system.
-   **Multi-Source Ingestion:** Supports JSON files, PDFs, text files, and direct API payloads.
-   **Metadata Filtering:** Queries can be filtered by metadata fields (e.g., `type`, `suburb`, `status`) for more precise results.
-   **Source-Based Deduplication:** Documents are uniquely identified by a `source_path`, ensuring that updates overwrite existing entries rather than creating duplicates.
-   **Scalable Deployment:** The system is containerized with Docker and includes configurations for local development (`docker-compose`) and production deployment (e.g., `fly.toml`).
-   **Secure Endpoints:** The Ingestion Service is protected by bearer token authentication and validates GitHub webhook signatures.
-   **Interactive Search UI:** A simple but powerful user interface for testing and manual queries.

## 4. Getting Started

Follow these steps to set up and run the CKR RAG system on your local machine.

### 4.1. Prerequisites

-   **Docker and Docker Compose:** [Install Docker](https://docs.docker.com/get-docker/)
-   **Git:** [Install Git](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)
-   **Pinecone Account:** [Sign up for Pinecone](https://www.pinecone.io/)
-   **OpenAI API Key:** [Get an OpenAI API key](https://platform.openai.com/)
-   **Supabase Project:** [Create a Supabase project](https://supabase.com/)

### 4.2. Installation

1.  **Clone the repository:**

    ```bash
    git clone <repository-url>
    cd ckr-rag-system
    ```

2.  **Create the environment file:**

    Copy the `.env.template` file to a new file named `.env`.

    ```bash
    cp .env.template .env
    ```

3.  **Fill in the `.env` file:**

    Open the `.env` file and populate it with your credentials and configuration values. See the **Configuration** section below for details.

## 5. Configuration

All configuration is managed through the `.env` file. Here are the required variables:

| Variable                    | Description                                                                                                 |
| --------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `PINECONE_API_KEY`          | Your Pinecone API key. **(Rotate the key shared previously)**                                                 |
| `PINECONE_ENV`              | The Pinecone environment (e.g., `us-east-1`).                                                                 |
| `INDEX_NAME`                | The name of your Pinecone index (e.g., `ckr-knowledge`).                                                      |
| `OPENAI_API_KEY`            | Your OpenAI API key.                                                                                        |
| `GITHUB_WEBHOOK_SECRET`     | A secret string used to secure your GitHub webhook. Generate a strong random string.                        |
| `ALLOWED_REPO`              | The only GitHub repository allowed to trigger the webhook (e.g., `callkaidsroofing/callkaidsroofing`).         |
| `RAG_TOKEN`                 | A secret bearer token for authenticating with the RAG service. Generate a strong random string.             |
| `SUPABASE_URL`              | Your Supabase project URL.                                                                                  |
| `SUPABASE_SERVICE_ROLE_KEY` | Your Supabase service role key (found in your project's API settings).                                      |

## 6. Running the System

You can run the entire system using Docker Compose.

### 6.1. Using Docker Compose (Recommended)

This is the easiest way to run the RAG service and the Supabase worker together.

```bash
# Build and start the services in detached mode
docker-compose -f deployment/docker-compose.yml up --build -d

# View logs
docker-compose -f deployment/docker-compose.yml logs -f

# Stop the services
docker-compose -f deployment/docker-compose.yml down
```

### 6.2. Running Services Individually

You can also run the components locally for development.

1.  **Install dependencies:**

    ```bash
    pip install -r requirements.txt
    ```

2.  **Run the FastAPI Ingestion Service:**

    ```bash
    python3 services/rag_service.py
    ```

3.  **Run the Supabase Polling Worker:**

    ```bash
    python3 workers/supabase_pull_worker.py
    ```

## 7. API Endpoints

The Ingestion Service exposes the following endpoints at `http://localhost:8080`.

-   `POST /upsert`: Upserts a document. Requires `Authorization: Bearer <RAG_TOKEN>`.
-   `POST /delete`: Deletes a document by `source_path`. Requires `Authorization: Bearer <RAG_TOKEN>`.
-   `POST /query`: Queries the RAG system. Requires `Authorization: Bearer <RAG_TOKEN>`.
-   `POST /webhook/github`: The endpoint for the GitHub webhook.
-   `GET /health`: Health check endpoint.

## 8. Data Ingestion Setup

### 8.1. GitHub Webhook

1.  Go to your GitHub repository settings (`callkaidsroofing/callkaidsroofing`).
2.  Navigate to **Webhooks** and click **Add webhook**.
3.  **Payload URL:** Your deployed service URL + `/webhook/github` (e.g., `https://your-app.fly.dev/webhook/github`). For local testing, use a tool like [ngrok](https://ngrok.com/).
4.  **Content type:** `application/json`.
5.  **Secret:** The `GITHUB_WEBHOOK_SECRET` you defined in your `.env` file.
6.  **Events:** Select "Just the `push` event."
7.  Click **Add webhook**.

### 8.2. Supabase Triggers

1.  In your Supabase project, go to the **SQL Editor**.
2.  Execute the SQL script located in `deployment/supabase_schema.sql`. This will:
    -   Create the `rag_queue` table.
    -   Create the `handle_rag_upsert` and `handle_rag_delete` trigger functions.
    -   Create the `get_rag_queue_stats` function for monitoring.
3.  Attach the triggers to your desired tables (e.g., `jobs`, `quotes`).

    ```sql
    -- Example: Attach trigger to a 'jobs' table
    CREATE TRIGGER on_job_insert
      AFTER INSERT ON jobs
      FOR EACH ROW EXECUTE PROCEDURE handle_rag_upsert('job', 'id');

    CREATE TRIGGER on_job_update
      AFTER UPDATE ON jobs
      FOR EACH ROW EXECUTE PROCEDURE handle_rag_upsert('job', 'id');

    CREATE TRIGGER on_job_delete
      AFTER DELETE ON jobs
      FOR EACH ROW EXECUTE PROCEDURE handle_rag_delete('job', 'id');
    ```

## 9. Deployment

The project is configured for easy deployment to [Fly.io](https://fly.io/).

1.  **Install `flyctl`:** Follow the [official instructions](https://fly.io/docs/hands-on/install-flyctl/).
2.  **Log in:** `flyctl auth login`
3.  **Set secrets:**

    ```bash
    fly secrets set PINECONE_API_KEY="<your-key>" OPENAI_API_KEY="<your-key>" ...
    ```

4.  **Deploy:**

    ```bash
    flyctl deploy
    ```

## 10. Security Considerations

-   **API Keys:** All API keys and secrets are managed via environment variables and should never be hard-coded. Use a secrets management tool for production environments.
-   **Webhook Security:** The GitHub webhook is secured with a secret to prevent unauthorized requests.
-   **Service Authentication:** The RAG service endpoints are protected by a bearer token.
-   **Compromised Keys:** The Pinecone API key initially provided was exposed and **must be rotated**. Treat any exposed credential as compromised.

---

This document provides a comprehensive guide to the CKR RAG System. For further questions, please refer to the source code or contact the development team.
'''
