#!/usr/bin/env python3
"""
CKR Pinecone RAG System
Purpose: Ingest CKR documents to Pinecone and run RAG chat against them.
Author: Call Kaids Roofing
Version: 1.0.0
"""

import os
import json
import hashlib
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv
from pypdf import PdfReader

from pinecone import Pinecone, ServerlessSpec
from openai import OpenAI

load_dotenv()

# Environment variables
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
INDEX_NAME = os.getenv("INDEX_NAME", "ckr-knowledge")
PINECONE_ENV = os.getenv("PINECONE_ENV", "us-east-1")

# Initialize clients
pc = Pinecone(api_key=PINECONE_API_KEY)
oai = OpenAI(api_key=OPENAI_API_KEY)


# ---------- Embedding Functions ----------
def embed_texts(texts: List[str], model: str = "text-embedding-3-small") -> List[List[float]]:
    """
    Generate embeddings for a list of texts using OpenAI's embedding model.
    
    Args:
        texts: List of text strings to embed
        model: OpenAI embedding model name
        
    Returns:
        List of embedding vectors
    """
    resp = oai.embeddings.create(model=model, input=texts)
    return [d.embedding for d in resp.data]


def embedding_dim(model: str = "text-embedding-3-small") -> int:
    """Get the dimension of the embedding model."""
    return len(embed_texts(["dim-probe"], model=model)[0])


# ---------- Index Management ----------
def ensure_index(index_name: str, dimension: int):
    """
    Create Pinecone index if it doesn't exist and wait for readiness.
    
    Args:
        index_name: Name of the Pinecone index
        dimension: Dimension of the embedding vectors
    """
    existing = {i["name"] for i in pc.list_indexes().indexes}
    if index_name not in existing:
        pc.create_index(
            name=index_name,
            dimension=dimension,
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region=PINECONE_ENV),
        )
        # Wait for readiness
        while True:
            desc = pc.describe_index(index_name)
            if desc.status["ready"]:
                break
            time.sleep(1)
        print(f"✓ Created index: {index_name}")
    else:
        print(f"✓ Index already exists: {index_name}")


def get_index():
    """Get the Pinecone index instance."""
    return pc.Index(INDEX_NAME)


# ---------- Text Chunking ----------
def split_text(text: str, chunk_size: int = 1200, overlap: int = 100) -> List[str]:
    """
    Split text into overlapping chunks for better context preservation.
    
    Args:
        text: Input text to split
        chunk_size: Maximum size of each chunk
        overlap: Number of characters to overlap between chunks
        
    Returns:
        List of text chunks
    """
    chunks, i, n = [], 0, len(text)
    while i < n:
        end = min(i + chunk_size, n)
        chunk = text[i:end]
        chunks.append(chunk)
        i = end - overlap
        if i < 0:
            i = 0
        if i >= n:
            break
    return chunks


# ---------- Document I/O ----------
def read_pdf(path: str) -> str:
    """
    Extract text from a PDF file.
    
    Args:
        path: Path to the PDF file
        
    Returns:
        Extracted text content
    """
    reader = PdfReader(path)
    parts = []
    for page in reader.pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            parts.append("")
    return "\n".join(parts).strip()


def sha_id(s: str) -> str:
    """Generate a short SHA256 hash for ID generation."""
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:24]


@dataclass
class Doc:
    """Document container with text, metadata, and unique ID."""
    text: str
    metadata: Dict[str, Any]
    uid: str


# ---------- Document Collection ----------
def load_docs() -> List[Doc]:
    """
    Load all documents from the data directory structure.
    
    Returns:
        List of Doc objects with text and metadata
    """
    docs: List[Doc] = []

    # Load Jobs JSON
    jobs_dir = "data/jobs_json"
    if os.path.isdir(jobs_dir):
        for fn in os.listdir(jobs_dir):
            if not fn.lower().endswith(".json"):
                continue
            p = os.path.join(jobs_dir, fn)
            with open(p, "r", encoding="utf-8") as f:
                j = json.load(f)
            
            base_meta = {
                "type": "job",
                "customer": j.get("customer", ""),
                "address": j.get("address", ""),
                "suburb": j.get("suburb", ""),
                "state": j.get("state", "VIC"),
                "postcode": j.get("postcode", ""),
                "date": j.get("date", ""),
                "status": j.get("status", ""),
                "scope": j.get("scope", ""),
                "tags": j.get("tags", []),
                "source": "crm",
                "doc_id": j.get("id", fn),
            }
            
            # Flatten notes/lines if present
            body_parts = []
            for k in ("notes", "findings", "materials", "line_items", "photos_caption"):
                v = j.get(k)
                if isinstance(v, list):
                    body_parts.append("\n".join(map(str, v)))
                elif isinstance(v, str):
                    body_parts.append(v)
            
            body = "\n".join(body_parts).strip()
            if not body:
                body = json.dumps(j, ensure_ascii=False)
            
            uid = f"job-{sha_id(base_meta['doc_id'] + body[:200])}"
            docs.append(Doc(text=body, metadata=base_meta, uid=uid))

    # Load Quotes PDF
    quotes_dir = "data/quotes_pdf"
    if os.path.isdir(quotes_dir):
        for fn in os.listdir(quotes_dir):
            if not fn.lower().endswith(".pdf"):
                continue
            p = os.path.join(quotes_dir, fn)
            content = read_pdf(p)
            
            meta = {
                "type": "quote",
                "customer": "",
                "address": "",
                "suburb": "",
                "state": "VIC",
                "postcode": "",
                "date": "",
                "status": "sent",
                "scope": "quote-pdf",
                "tags": [],
                "source": "pdf",
                "doc_id": fn,
            }
            uid = f"quote-{sha_id(fn + content[:200])}"
            docs.append(Doc(text=content, metadata=meta, uid=uid))

    # Load Notes TXT
    notes_dir = "data/notes_txt"
    if os.path.isdir(notes_dir):
        for fn in os.listdir(notes_dir):
            if not fn.lower().endswith(".txt"):
                continue
            p = os.path.join(notes_dir, fn)
            content = open(p, "r", encoding="utf-8").read()
            
            meta = {
                "type": "note",
                "customer": "",
                "address": "",
                "suburb": "",
                "state": "VIC",
                "postcode": "",
                "date": "",
                "status": "",
                "scope": "note",
                "tags": [],
                "source": "txt",
                "doc_id": fn,
            }
            uid = f"note-{sha_id(fn + content[:200])}"
            docs.append(Doc(text=content, metadata=meta, uid=uid))

    return docs


# ---------- Ingestion ----------
def ingest():
    """
    Ingest all documents from the data directory into Pinecone.
    Creates index if needed, chunks documents, generates embeddings,
    and upserts vectors with metadata.
    """
    print("🚀 Starting ingestion process...")
    
    dim = embedding_dim()
    ensure_index(INDEX_NAME, dim)
    index = get_index()

    docs = load_docs()
    print(f"📄 Found {len(docs)} documents to process")
    
    # Chunk, embed, and upsert
    vectors = []
    total_chunks = 0
    
    for d in docs:
        chunks = split_text(d.text)
        embeds = embed_texts(chunks)
        
        for i, (ch, emb) in enumerate(zip(chunks, embeds)):
            vid = f"{d.uid}-{i:04d}"
            meta = dict(d.metadata)
            meta.update({"chunk_id": i, "text": ch})
            vectors.append({"id": vid, "values": emb, "metadata": meta})
            total_chunks += 1
        
        # Flush in batches of 100
        if len(vectors) >= 100:
            index.upsert(vectors=vectors, namespace="ckr")
            print(f"  ✓ Upserted {len(vectors)} vectors...")
            vectors = []
    
    # Upsert remaining vectors
    if vectors:
        index.upsert(vectors=vectors, namespace="ckr")
        print(f"  ✓ Upserted {len(vectors)} vectors...")
    
    print(f"✅ Ingestion complete! Processed {len(docs)} documents into {total_chunks} chunks.")


# ---------- Retrieval ----------
def retrieve(query: str, top_k: int = 8, filter_meta: Optional[Dict[str, Any]] = None):
    """
    Retrieve relevant documents from Pinecone based on query.
    
    Args:
        query: Search query text
        top_k: Number of results to return
        filter_meta: Optional metadata filters
        
    Returns:
        List of matching documents with metadata
    """
    index = get_index()
    q_emb = embed_texts([query])[0]
    res = index.query(
        vector=q_emb,
        top_k=top_k,
        namespace="ckr",
        include_metadata=True,
        filter=filter_meta or {}
    )
    return res.matches


# ---------- RAG Answer Generation ----------
SYSTEM_PROMPT = """You are CKR-Helper, a retrieval assistant for Call Kaids Roofing.

Your role is to answer questions using the supplied context from Call Kaids Roofing's jobs, quotes, and documentation.

Guidelines:
- Answer using ONLY the supplied context when possible
- If information is missing or unclear, explicitly state what's missing
- Be concise, factual, and use Australian English
- Prefer suburb-local detail when present
- Maintain Call Kaids Roofing's brand voice: expert, honest, helpful, and approachable
- For technical roofing questions, provide accurate information based on the context
- If asked about pricing or quotes, reference specific examples from the context

Brand Values to reflect:
- Honesty: Provide transparent, straightforward information
- Quality: Emphasize quality workmanship and materials
- Reliability: Be clear and precise in your responses
- Professionalism: Maintain a professional yet friendly tone
"""


def answer(query: str, suburb_hint: str = "") -> str:
    """
    Generate an answer to a query using RAG.
    
    Args:
        query: User's question
        suburb_hint: Optional suburb filter for local context
        
    Returns:
        Generated answer based on retrieved context
    """
    # Enhance query with suburb if provided
    enhanced_query = f"{query} suburb:{suburb_hint}" if suburb_hint else query
    
    # Retrieve relevant context
    matches = retrieve(enhanced_query, top_k=8)
    
    # Build context from matches
    context_blobs = []
    for m in matches:
        md = m.metadata or {}
        prefix = f"[{md.get('type','doc')}] {md.get('suburb','')}, {md.get('date','')}, {md.get('scope','')}"
        context_blobs.append(f"{prefix}\n{md.get('text','')}")
    
    context = "\n\n---\n\n".join(context_blobs[:8]) if context_blobs else "No matches found."
    
    # Generate answer using GPT-4o-mini
    msgs = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Question: {query}\n\nContext:\n{context}"}
    ]
    
    resp = oai.chat.completions.create(
        model="gpt-4o-mini",
        messages=msgs,
        temperature=0.1
    )
    
    return resp.choices[0].message.content.strip()


# ---------- Pinecone Assistant Integration ----------
def assistant_chat_with_context(query: str):
    """
    Use Pinecone Assistant with injected RAG context.
    
    Args:
        query: User's question
        
    Returns:
        Assistant's response with RAG context
    """
    from pinecone_plugins.assistant.models.chat import Message
    
    # Build RAG context
    matches = retrieve(query, top_k=8)
    context = "\n\n".join([(m.metadata or {}).get("text", "")[:1500] for m in matches])
    
    # Inject context into message
    fused = f"Use this CKR context first:\n{context}\n\nUser: {query}"
    
    # Get assistant response
    assistant = pc.assistant.Assistant(assistant_name="ckr-helper")
    msg = Message(content=fused)
    resp = assistant.chat(messages=[msg])
    
    return resp["message"]["content"]


# ---------- CLI Interface ----------
if __name__ == "__main__":
    import argparse
    
    ap = argparse.ArgumentParser(
        description="CKR Pinecone RAG System - Ingest and query Call Kaids Roofing documents"
    )
    ap.add_argument("--ingest", action="store_true", help="Ingest data/* into Pinecone")
    ap.add_argument("--ask", type=str, help="Ask a question with RAG")
    ap.add_argument("--assistant", type=str, help="Ask via Pinecone Assistant with injected context")
    ap.add_argument("--suburb", type=str, help="Filter by suburb (use with --ask)")
    
    args = ap.parse_args()

    if args.ingest:
        ingest()
    elif args.ask:
        result = answer(args.ask, suburb_hint=args.suburb or "")
        print("\n" + "="*80)
        print("ANSWER:")
        print("="*80)
        print(result)
        print("="*80 + "\n")
    elif args.assistant:
        result = assistant_chat_with_context(args.assistant)
        print("\n" + "="*80)
        print("ASSISTANT RESPONSE:")
        print("="*80)
        print(result)
        print("="*80 + "\n")
    else:
        ap.print_help()
