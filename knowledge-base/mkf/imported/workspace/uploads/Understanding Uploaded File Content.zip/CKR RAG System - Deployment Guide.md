# CKR RAG System - Deployment Guide

This guide covers deploying the CKR RAG system to production environments.

## Table of Contents

1. [Deployment Options](#deployment-options)
2. [Fly.io Deployment (Recommended)](#flyio-deployment-recommended)
3. [Alternative Platforms](#alternative-platforms)
4. [Post-Deployment Configuration](#post-deployment-configuration)
5. [Monitoring and Maintenance](#monitoring-and-maintenance)

---

## Deployment Options

The CKR RAG system can be deployed to any platform that supports Docker containers. We recommend the following platforms based on their ease of use, pricing, and features:

| Platform | Pros | Cons | Best For |
|----------|------|------|----------|
| **Fly.io** | Easy deployment, global edge network, generous free tier | Learning curve for CLI | Production deployments |
| **Render** | Simple UI, automatic deployments from Git | Slower cold starts on free tier | Quick prototypes |
| **Railway** | Simple setup, good developer experience | Limited free tier | Development/staging |
| **Google Cloud Run** | Scales to zero, pay-per-use | Requires GCP account setup | Enterprise deployments |
| **AWS ECS** | Full AWS integration, highly scalable | Complex setup | Large-scale enterprise |

---

## Fly.io Deployment (Recommended)

Fly.io is our recommended platform for production deployments due to its simplicity, performance, and cost-effectiveness.

### Prerequisites

- A Fly.io account ([sign up here](https://fly.io/app/sign-up))
- `flyctl` CLI installed ([installation guide](https://fly.io/docs/hands-on/install-flyctl/))

### Step 1: Install and Authenticate

```bash
# Install flyctl (macOS)
brew install flyctl

# Or install via script (Linux/macOS)
curl -L https://fly.io/install.sh | sh

# Authenticate
flyctl auth login
```

### Step 2: Initialize the Application

```bash
cd ckr-rag-system

# Launch the app (this will use the existing fly.toml)
flyctl launch --no-deploy
```

When prompted:
- **App name:** Choose a unique name (e.g., `ckr-rag-prod`)
- **Region:** Select `syd` (Sydney) for Australian deployment
- **PostgreSQL:** No (we're using Supabase)
- **Redis:** No

### Step 3: Set Secrets

Fly.io uses secrets for sensitive environment variables. Set them using:

```bash
flyctl secrets set \
  PINECONE_API_KEY="your_pinecone_key" \
  OPENAI_API_KEY="your_openai_key" \
  GITHUB_WEBHOOK_SECRET="your_webhook_secret" \
  RAG_TOKEN="your_rag_token" \
  ALLOWED_REPO="callkaidsroofing/callkaidsroofing" \
  SUPABASE_URL="https://your-project.supabase.co" \
  SUPABASE_SERVICE_ROLE_KEY="your_supabase_key"
```

### Step 4: Deploy

```bash
flyctl deploy
```

This will:
1. Build the Docker image
2. Push it to Fly.io's registry
3. Deploy the application
4. Start the service

### Step 5: Verify Deployment

```bash
# Check app status
flyctl status

# View logs
flyctl logs

# Open the app in your browser
flyctl open
```

Test the health endpoint:

```bash
curl https://your-app-name.fly.dev/health
```

### Step 6: Scale (Optional)

```bash
# Scale to multiple instances for high availability
flyctl scale count 2

# Adjust VM size if needed
flyctl scale vm shared-cpu-2x --memory 1024
```

---

## Alternative Platforms

### Render

1. Create a new **Web Service** in Render
2. Connect your GitHub repository
3. Set the following:
   - **Environment:** Docker
   - **Dockerfile Path:** `deployment/Dockerfile`
   - **Port:** 8080
4. Add environment variables in the Render dashboard
5. Click **Create Web Service**

### Railway

1. Create a new project in Railway
2. Click **Deploy from GitHub repo**
3. Select your repository
4. Railway will auto-detect the Dockerfile
5. Add environment variables in the **Variables** tab
6. Deploy

### Google Cloud Run

```bash
# Build and push the image
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/ckr-rag-system

# Deploy to Cloud Run
gcloud run deploy ckr-rag-system \
  --image gcr.io/YOUR_PROJECT_ID/ckr-rag-system \
  --platform managed \
  --region australia-southeast1 \
  --allow-unauthenticated \
  --set-env-vars "PINECONE_API_KEY=...,OPENAI_API_KEY=..."
```

---

## Post-Deployment Configuration

### 1. Update GitHub Webhook

After deployment, update your GitHub webhook URL:

1. Go to your repository settings
2. Navigate to **Webhooks**
3. Edit the existing webhook (or create a new one)
4. Update **Payload URL** to: `https://your-app-url.com/webhook/github`
5. Save changes

### 2. Test the Webhook

Trigger a test push to your repository and verify:

```bash
# Check webhook delivery in GitHub
# Settings → Webhooks → Recent Deliveries

# Check your app logs
flyctl logs
```

### 3. Configure Supabase Worker

If you're running the Supabase worker as a separate service, deploy it similarly:

```bash
# Create a new Fly.io app for the worker
flyctl launch --name ckr-rag-worker --no-deploy

# Set the command to run the worker
flyctl deploy --dockerfile deployment/Dockerfile --build-arg CMD="python workers/supabase_pull_worker.py"
```

Alternatively, run the worker as a scheduled task or use Supabase Edge Functions.

---

## Monitoring and Maintenance

### Health Checks

The service includes a `/health` endpoint that returns:

```json
{
  "status": "healthy",
  "service": "CKR RAG Ingestion Service",
  "version": "1.0.0"
}
```

Set up external monitoring with services like:
- [UptimeRobot](https://uptimerobot.com/)
- [Pingdom](https://www.pingdom.com/)
- [Better Uptime](https://betteruptime.com/)

### Log Monitoring

**Fly.io:**
```bash
flyctl logs --app ckr-rag-prod
```

**Render/Railway:** Check the logs in the web dashboard.

### Performance Monitoring

Monitor key metrics:
- **Response time** for `/query` endpoint
- **Pinecone API latency**
- **OpenAI API latency**
- **Supabase queue processing rate**

### Backup and Recovery

**Pinecone:**
- Pinecone automatically backs up your data
- Consider periodic exports for critical data

**Supabase:**
- Enable daily backups in your Supabase project settings
- Export the `rag_queue` table schema regularly

### Scaling Considerations

**Horizontal Scaling:**
- Add more instances during high traffic periods
- Use Fly.io's autoscaling: `flyctl autoscale set min=1 max=5`

**Vertical Scaling:**
- Increase VM size if processing is slow
- Monitor memory usage and adjust accordingly

### Security Updates

Regularly update dependencies:

```bash
# Update Python packages
pip list --outdated
pip install --upgrade <package-name>

# Rebuild and redeploy
flyctl deploy
```

### Cost Optimization

**Fly.io Free Tier:**
- 3 shared-cpu-1x VMs (256MB RAM each)
- 160GB outbound data transfer per month

**Tips:**
- Use a single VM for low-traffic periods
- Scale up only when needed
- Monitor usage in the Fly.io dashboard

---

## Troubleshooting

### Deployment Fails

**Issue:** Docker build fails

**Solution:**
- Check the Dockerfile syntax
- Ensure all dependencies are in `requirements.txt`
- Review build logs: `flyctl logs`

### Service Crashes

**Issue:** Service starts but crashes immediately

**Solution:**
- Check environment variables are set correctly
- Verify Pinecone and OpenAI API keys are valid
- Review logs for error messages

### Slow Performance

**Issue:** Queries take too long

**Solution:**
- Check Pinecone index performance in the console
- Consider upgrading to a larger VM
- Optimize metadata filters in queries

### Webhook Not Working

**Issue:** GitHub webhook returns errors

**Solution:**
- Verify the webhook secret matches
- Check that the service is publicly accessible
- Review GitHub webhook delivery logs

---

## Rollback Procedure

If a deployment causes issues:

```bash
# View deployment history
flyctl releases

# Rollback to a previous version
flyctl releases rollback <version-number>
```

---

## Support

For deployment issues or questions:
- Email: callkaidsroofing@outlook.com
- GitHub Issues: [Create an issue](https://github.com/callkaidsroofing/callkaidsroofing/issues)

---

**Last Updated:** 2025-11-04  
**Version:** 1.0.0
