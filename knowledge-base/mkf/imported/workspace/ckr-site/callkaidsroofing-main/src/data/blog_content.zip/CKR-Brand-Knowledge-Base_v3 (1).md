# Call Kaids Roofing — Master Brand & Operations Knowledge Base
_Last updated: 2025-08-17 (AEST)_

> **Purpose:** A single source of truth for branding, comms, content, and CRM data structures for Call Kaids Roofing (CKR). Use this to keep every AI tool, website, ad, and message consistent.  
> **Owner:** Kaidyn Brownlie  
> **Business:** Call Kaids Roofing (SE Melbourne, VIC)

---

## 1) Business Identity

**Trading Name:** Call Kaids Roofing  
**Owner:** Kaidyn Brownlie  
**Region/Service Area:** South East Melbourne, VIC (e.g., Clyde North and surrounding suburbs).  
**Primary Services:**  
- Roof pressure washing / cleaning  
- Roof painting (incl. primer/base/finish systems as required)  
- Ridge capping and gable tile rebedding & repointing  
- Full roof rebedding and pointing  
- Gutter cleaning  
- Leak detection & diagnostics  
- Valley iron replacement  
- Broken tile replacement  
- Re-sarking and re-battening  
- Roof restorations  
- Re-roofing & new roofs

**Contact Details (confirmed):**  
- **Phone:** 0435 900 709  
- **Email:** callkaidsroofing@outlook.com

- **ABN:** 39475055075

**Add when available:**  
- **Website:** _[insert]_  
- **Street Address / Postal:** _[insert]_  
- **Licences / Insurances:** _[insert]_  
- **Operating Hours:** _[insert]_

**Positioning Statement (internal):**  
> We’re a hands-on, no-BS roofing service. We don’t upsell — we educate. Expect practical advice, tidy workmanship, and a finish we can stand behind.

---

## 2) Brand Identity & Visual System

### 2.1 Logo System
- **Primary wordmark:** Serif-styled “C all K aids R oofing” (classic, trustworthy).  
- **Secondary lockup:** Modern sans-serif house icon + text (clean, minimal).  
- **Usage rules:**  
  - Prefer the primary wordmark on print, estimates, and site signage.  
  - Use the secondary lockup for digital small spaces (social avatars, favicons).  
  - Maintain clear-space: min. height of the “C” around the logo on all sides.  
  - Never stretch, skew, add drop-shadows, or place over busy backgrounds.

### 2.2 Typography
- **Primary (classic):** A serif family similar to Times/Georgia for the legacy logo applications.  
- **Secondary (modern):** A Montserrat-like sans-serif for body/UI text.  
- **Hierarchy:**  
  - H1: Sans-serif Bold (32–40px web / 18–24pt print)  
  - H2: Sans-serif SemiBold (24–28px web / 14–16pt print)  
  - Body: Sans-serif Regular (15–18px web / 10–12pt print)  
  - Accents/Badges: Sans-serif Medium

### 2.3 Color Palette (in-use)
- **Charcoal Black / Dark Slate** (primary neutral)  
- **Blue gradient** (logo highlight)  
- **Safety/Accent Blue:** **#007ACC** (approx.)  
- **Safety Orange:** **#FF6A00** (used sparingly for CTAs or highlights)  
- **White / Off-white** (contrast and whitespace)

**Rules:**  
- Keep backgrounds light/clean; use Charcoal for headers or footers.  
- Accent Blue or Safety Orange for single, obvious calls-to-action — never both at once.  
- Maintain AA contrast minimum for text over color fields.

### 2.4 Imagery & Media
- **Must:** Real jobsite photos; clear before/after from the same angle; visible tools & materials; clean gutters/ridges post-work; roof texture details.  
- **Avoid:** Stock photos; overexposed HDR; filters that misrepresent color; messy site shots.  
- **Video:** Tripod or stable phone shots, landscape or 4:5 portrait for reels; cut dead air; 3–8s headline hook; captions on.  
- **Drone:** Slow orbits; 60–80m max; always tie a story to the footage (problem → fix → result).  
- **Safety:** Visible PPE where relevant.

### 2.5 Trust & Product Mentions
- Reference real materials & methods used on jobs: **Premcoat**, **Stormseal**, **SupaPoint**, quality primers and membranes.  
- Trust markers in print/digital: **7-year** and **10-year** warranty badges (use appropriately with terms).  
- Emphasize **valley sealing**, **pointing**, and **proper paint systems**.

### 2.6 Taglines (approved)
- “**No Leaks. No Lifting. Just Quality.**”  
- “**The Best Roof Under the Sun.**”  
- “**Professional Roofing, Melbourne Style.**”

---

## 3) Voice & Messaging

### 3.1 Core Voice
> **Clear, warm, direct.** Down-to-earth and honest. Confident without hype. We educate so the client can decide.

### 3.2 Do’s & Don’ts (language)
**Do:**  
- Use short, plain-English sentences.  
- Explain problems and fixes in everyday terms.  
- Lead with facts, show photos, then recommend.  
- Offer options (good/better/best) and outline trade-offs.  
- Use measured Aussie-vernacular lightly (“no fuss”, “sorted”, “right”), not slang-heavy.  
- Reinforce safety, workmanship, and respect for property.

**Don’t:**  
- Don’t use corporate jargon (“synergy”, “innovative solutions”).  
- Don’t overpromise (“lifetime”, “never again”) unless contractually true.  
- Don’t pressure with fake scarcity or gimmicks.  
- Don’t dunk on competitors — focus on our standards.  
- Don’t write walls of text; break into bullets and steps.

### 3.3 Message Building Blocks
- **Problem** → **Why it matters** → **What we found** → **What we recommend** → **Cost/Time** → **Result/Warranty**.  
- **Evidence-first**: a photo + 1–2 bullet captions beats a paragraph.  
- **Weather honesty**: explain weather-related delays upfront; give the next available window.  
- **Care language**: “We’ll keep it tidy”, “We’ll protect garden beds”, “We’ll leave it better than we found it”.

### 3.4 Microcopy & CTA Library
- **CTAs:** “Get a fast quote”, “Book a roof check”, “See before & afters”, “Message Kaidyn”.  
- **Buttons:** “Request a callback”, “Send photos for a quick estimate”, “Confirm inspection”.  
- **Form helper text:** “Attach a few photos of the issue if you can — it speeds things up.”  
- **Estimates:** “No pressure — we’ll explain options so you can pick what suits.”

---

## 4) Social Content System

### 4.1 Pillars & Cadence
- **Pillars:** (1) Jobs & Case Studies, (2) Maintenance Tips, (3) Materials & Methods, (4) Behind the Scenes, (5) FAQs & Myths.  
- **Cadence (baseline):** 3× posts/week + 2–3× stories; document jobs-in-progress.  
- **Mix:** 40% jobs, 25% tips, 15% BTS, 10% myths/FAQs, 10% reviews.

### 4.2 Formats & Prompts (copy-ready)
- **Job of the Week (carousel):**  
  1) Slide 1: “{{Suburb}}: {{Problem in 1 line}}”  
  2) Slide 2–4: Close-ups of issue + brief captions  
  3) Slide 5: “Fix: {{Method/materials}} → Result: {{benefit}}”  
  4) CTA: “Want a quick roof check? Message us.”
- **Repair Tip Tuesday (reel):** Hook (3s) → Tip explained (15–30s) → Visual proof → CTA “Save this for later”  
- **Myth vs Fact (static):** “Myth: {{X}} / Fact: {{Short evidence}} / What to do: {{Action}}”  
- **BTS (story):** “Today’s plan → Mid-day check-in → Wrap-up” with 3 quick clips.
- **Review snapshot:** Client quote + photo of finished ridge/valley; badge overlay “7-Year Workmanship” (if applicable).

### 4.3 Do’s & Don’ts (social)
**Do:**  
- Geotag suburbs; mention SE Melbourne.  
- Use real photos; consistent angles for before/after.  
- Add alt text describing issues/fixes (accessibility + SEO).  
- Pin best case study & contact options.  
- Reply to comments within 24 hours; save Qs to FAQ bank.

**Don’t:**  
- Don’t post generic stock imagery.  
- Don’t jump on unrelated trends; keep content on-mission.  
- Don’t share client addresses or private details.  
- Don’t claim manufacturer warranties you don’t hold.

### 4.4 Hashtag/SEO Hints
- **Local+Service combo:** `#ClydeNorth #MelbourneRoofing #RoofRestoration #Repointing #RoofPainting #ValleyIron`  
- Keep to 5–12 relevant tags; avoid spam blocks.  
- In captions, front-load the first 2 lines with the “why it matters” for the homeowner.

---

## 5) Web Content & Page Blocks (for devs/AI)

### 5.1 Global Page Rules
- Mobile-first layouts; readable 15–18px body.  
- One hero CTA; don’t stack multiple primary CTAs.  
- Real project photos prioritized over illustrations.  
- Insert social proof and warranty badges near CTAs.

### 5.2 Page Blueprints
- **Home:** Hero (value + CTA) → 3 service cards → Before/After strip → “How we work” (3 steps) → Reviews → Service area → Contact form.  
- **Services (parent):** Grid of key services with short intros; link to child pages.  
- **Service (child):** Problem → Symptoms → What we do → Materials → Timeline → Gallery → FAQs → CTA.  
- **About:** Owner story, values, photos at work; “We don’t upsell, we educate.”  
- **Projects/Before-After:** Filterable gallery; suburb labels; short learnings.  
- **Contact/Quote:** Form with photos upload; option to request callback; privacy note.  
- **FAQ:** Curated from recurring DMs/calls; link to tips blog.

### 5.3 Copy Modules
- **3-Step Process:** Inspect → Repair/Restore → Protect (explain coatings/warranties).  
- **Material Mentions:** Premcoat/Stormseal/SupaPoint where relevant.  
- **Weather Policy:** Explain rescheduling rules clearly on booking pages.  
- **Footer Block:** Service area, hours, contact, badges.

---

## 6) Sales, Quoting & Customer Care

### 6.1 Pre-Quote Checklist (Do)
- Ask for **address + photos** of issue (if safe) and **access notes**.  
- Confirm **roof type** (tile/metal), **age (approx.)**, **visible damage**, **previous repairs**.  
- Check **weather window** and **daylight** availability.  
- Manage expectations (“If weather turns, we’ll move to the next fine window”).

### 6.2 Quote Structure
- Itemized: **Description** → **Qty/Units** → **Rate** → **Amount**.  
- Include notes on **scope limits** (e.g., inaccessible areas), **materials**, and **warranty terms**.  
- Show **options** (Good / Better / Best) if appropriate.  
- Add **photo references** (“See Photo 2: cracked ridge at NE corner”).

### 6.3 Don’ts (Sales)
- Don’t promise exact colours/finishes without showing swatches.  
- Don’t give fixed dates during unstable weather; give windows.  
- Don’t “package add-ons” that aren’t necessary; explain value honestly.

### 6.4 Aftercare & Handover
- Provide **before/after set** + summary: what was done, what to watch next.  
- Offer **maintenance interval** (e.g., 12–24 months for checks/clean).  
- Document **warranty start date** and **conditions** (materials vs workmanship).

---

## 7) Legal, Warranty & Safety (templates)

> **Disclaimer (template):**  
> All recommendations are based on visible conditions at time of inspection. Hidden defects may emerge after removal of debris or during repairs. Weather may affect scheduling and curing times.

> **Warranty notes (template):**  
> Workmanship warranty applies to the specified scope only. Manufacturer warranties on materials (e.g., coatings, membranes) are subject to product-specific terms and installer compliance. Full terms provided on acceptance.

> **Safety:**  
> Follow fall protection and equipment guidelines at all times. Client to keep driveways clear during works where safe to do so.

_(Replace with your actual ABN, licence numbers, and insurance documents when inserted.)_

---

## 8) CRM & Data Model (for internal tools)

### 8.1 Entities & Key Fields
- **Clients:** name, mobile, phone, email, address, notes.  
- **Jobs:** client_id, job_address, description, estimated_hours, start/target/actual dates, final_price, status, services (checkbox set), completion checklist, payment block, materials list.  
- **Quotes:** quote_number, client_id, items (desc, cost, qty, unit, amount), subtotal, discount %, discount amount, GST, total, status, notes, validity dates.  
- **Invoices:** invoice_number, client_id, (optional) quote_id, dates (issued/due), subtotal, tax, total, taxable, payments[], status, PO number.  
- **Payments:** invoice_id, amount, date, method (BANK/CASH/OTHER), reference, notes.

### 8.2 Status Conventions
- **Job.status:** `quote_given | accepted | started | completed | paid`  
- **Quote.status:** `pending | accepted | rejected | expired`  
- **Invoice.status:** `pending | partial | paid | overdue`

### 8.3 Materials (JobMaterial)
- material, specification, quantity, unit (track Premcoat/Stormseal/SupaPoint etc. where used).

### 8.4 Completion Checklist
- photos_taken, client_satisfaction_confirmed, site_cleared, warranty_provided, next_service_advised.

### 8.5 Data Governance
- Use consistent **suburb names** and **photo naming**: `YYYYMMDD_Suburb_Scope_Angle_01.jpg`.  
- Keep **client privacy**: no public posting of house numbers; blur plates where visible.  
- Backups: daily automated; exports as CSV for accounting handover.

---

## 9) Extended Do’s & Don’ts (quick reference)

**Copy & Voice (Do):** factual, plain English, explain trade-offs, lead with photos, include timeframes/windows, reference safety and cleanup.  
**Copy & Voice (Don’t):** hype, pressure tactics, technical jargon without explanation, competitor-bashing, vague claims.

**Design (Do):** clean layouts, big readable text, one primary CTA, warranty badges near CTAs, real photos only, brand colors conservatively.  
**Design (Don’t):** clutter, multiple competing CTAs, low-contrast text, gradients behind small text, tiny tap targets.

**Social (Do):** geotag SE Melbourne suburbs, answer comments promptly, create FAQ highlights, alt text images, reuse case studies on web.  
**Social (Don’t):** post addresses, share unsafe practices, chase irrelevant trends, use generic stock.

**Sales (Do):** itemize scope, add photos to quotes, set weather expectations, give options.  
**Sales (Don’t):** promise impossible timelines, bundle unnecessary extras, neglect cleanup photos.

**Ops (Do):** schedule around weather, document materials, confirm access, respect gardens/paths, leave tidy.  
**Ops (Don’t):** trample gardens, leave debris in gutters, paint over defects without fixing, skip priming/prep.

---

## 10) Reusable Prompts (for AI tools)

**A) Case Study Post (Instagram/Facebook)**  
“Write a friendly, direct case study caption for a roofing job in _[Suburb]_. Problem → Why it matters → What we found → Materials/Method (mention Premcoat/Stormseal/SupaPoint if relevant) → Result → CTA (‘Message Kaidyn for a quick roof check’). Keep to 80–140 words, no jargon, add 5–8 local/service hashtags.”

**B) Service Page Section (Website)**  
“Draft a ‘What We Do’ section for _[Service]_ in SE Melbourne: symptoms, our process (inspect → repair/restore → protect), typical timeline windows, and materials used. 150–250 words. Tone: clear, warm, direct. End with a single CTA.”

**C) Quote Email**  
“Subject: Your _[Service]_ quote for _[Suburb]_. Body: 4 short sections — issue summary, recommended scope, options (good/better/best), next steps (book window, send photos, or request call). Include weather window note and photo references.”

**D) FAQ Builder**  
“Turn these recurring questions into clean Q&A with plain English answers (80–120 words each). Group into categories and propose one CTA.”

---

## 11) Insertables (fill these in when ready)

- ABN: 39475055075  
- Website URL: _[insert]_  
- Address: _[insert]_  
- Licences: _[insert]_  
- Insurance: _[insert]_  
- Warranty terms (full text): _[insert]_  
- Photo release consent template: _[insert]_

---

## 12) Quick FAQ Seeds (to expand)

- **How long does a roof restoration take?** Depends on roof size and weather; typically **2–5 days** including cleaning, prep, and coatings, with weather windows for proper curing.  
- **Do you do gutters and valleys?** Yes — we clean gutters and **replace valley irons** when needed; we’ll show you photos and explain why.  
- **Can you work around bad weather?** Yes — we plan around forecasts and keep you updated. We’ll shift to the next safe window if needed.  
- **Do you provide photos?** Always — before/after and key areas, so you know exactly what was done.

---

### Final Notes
- We do **not upsell** — we **educate**.  
- Every job is treated like our own home.  
- We show up, follow through, and finish.  
- We own our results.  
- We respect the customer, their property, and their time.