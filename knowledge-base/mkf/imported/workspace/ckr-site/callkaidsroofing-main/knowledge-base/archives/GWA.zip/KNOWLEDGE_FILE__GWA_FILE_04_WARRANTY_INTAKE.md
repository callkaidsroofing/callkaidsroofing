KNOWLEDGE FILE: GWA_FILE_04_WARRANTY_INTAKE.md
| GWA ID: GWA-04 | GWA Name: Warranty Claim Intake & Triage |
|---|---|
| Version: 1.0 | Last Updated: 2025-10-08 |
| Owner: CKR Client Services | Status: Active |
SECTION 1: GWA OVERVIEW
1.1. Objective
To provide a rapid, empathetic, and professional intake process for warranty claims, ensuring the issue is logged correctly and the CKR team is equipped with all necessary historical data for a swift and effective resolution.
1.2. Trigger Mechanism
 * Primary Trigger: A user command, such as "Warranty claim from [Client Name]," "Run GWA-04 on this email."
 * Autonomous Trigger: Can be configured to monitor the inbox for keywords like "warranty," "problem," "leak," "issue" from an email address matching a past client.
1.3. Success Metrics
 * Acknowledgement Time: Time from claim email arrival to acknowledgement draft being ready < 2 minutes.
 * Data Retrieval Success: 100% of claims are successfully matched with their original job folder.
SECTION 2: TECHNICAL SPECIFICATION (LangChain Agent)
2.1. Agent Name: warrantyIntakeAgent
2.2. Required Tools:
 * @Gmail (Read, Create Draft)
 * @Google Drive (Search Archived Folders)
 * @Utilities (Task management system API)
2.3. Input Schema:
 * { "emailId": "string" } or { "clientName": "string", "claimDetails": "string" }
2.4. Output Schema:
 * { "status": "Success", "claimId": "string", "originalJobFolderUrl": "string", "warrantyIsValid": "boolean", "managerTaskId": "string" }
SECTION 3: LOGICAL WORKFLOW (CHAIN OF THOUGHT)
 * START: Receive emailId or client details as input.
 * TOOL CALL (@Gmail): If emailId is provided, read the email. Parse the sender's name/email and the summary of the claim.
 * TOOL CALL (@Google Drive): Perform a recursive search within the Completed Jobs/ archive for a folder matching the client's name or address.
 * VALIDATION: Once the folder is found, retrieve the job completion date and the warranty issued (15 or 20 years). Calculate if the current date is within the warranty period.
 * RESPONSE GENERATION: Access KF_07 for the high-empathy warranty claim acknowledgement template. Draft an email to the client confirming receipt and informing them a team member will be in touch within 24 business hours to schedule an inspection.
 * TOOL CALL (@Gmail): Create a draft of the acknowledgement email.
 * TASK GENERATION: Assemble a data package for the Project Manager, including the client's details, the summary of their claim, a direct link to the original job folder in Google Drive, and a clear statement on the warranty's validity.
 * TOOL CALL (@Utilities): Create a CRITICAL PRIORITY task in the project management system with the assembled data package.
 * END: Return the final JSON output, confirming the claim has been triaged and the manager has been tasked.
SECTION 4: DEPENDENCIES & INTEGRATIONS
 * Required Knowledge Files: KF_07 (Warranty text and email templates).
 * Downstream GWA Triggers: None.
SECTION 5: ERROR HANDLING & FALLBACKS
| Step | Error Condition | Fallback Action |
|---|---|---|
| 3 | No matching job folder found in the archive. | Halt workflow. Create task for user: "Warranty claim from [Client Name] received, but no matching job folder was found in the archive. Manual search and client contact required." |
| 4 | Job is outside the warranty period. | Continue workflow, but modify the draft email to politely state the job is outside its workmanship warranty period and that an inspection would be a billable service. Add this information prominently to the manager's task. |
Of course. Continuing with the detailed markdown canvases for the remaining Grand Workflow Automations.
