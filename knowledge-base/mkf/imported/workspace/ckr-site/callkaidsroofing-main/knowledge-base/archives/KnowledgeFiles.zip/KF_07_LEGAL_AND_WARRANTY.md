KNOWLEDGE FILE KF_07: LEGAL, WARRANTY & COMPLIANCE DOCTRINE (v3.1)
WORD COUNT: 21,112
LAST UPDATED: 2025-10-06
IMPORTANT DISCLAIMER: This document is for internal operational guidance for Call Kaids Roofing staff and the CKR-Gem agent only. It provides a detailed explanation of our standard terms and processes. It is not legal advice and must not be presented to clients or any third party as a standalone legal document. All official client-facing documents (Quotes, Contracts, Warranty Certificates) must be used in their approved template forms.
TABLE OF CONTENTS
 * SECTION 1: GOVERNING PHILOSOPHY & DOCTRINE
   1.1. Principle of "Clarity, Fairness, and Mutual Protection"
   1.2. The Role of This Document as the "Single Source of Truth"
   1.3. Protocol for Handling Legal & Warranty Enquiries (Expanded)
 * SECTION 2: THE CKR WORKMANSHIP WARRANTIES (DUAL-TIER SYSTEM)
   2.A. THE 15-YEAR STANDARD WORKMANSHIP WARRANTY (DEEP DIVE)
   2.A.1. Trigger Conditions for the 15-Year Warranty
   2.A.2. The Official Full Warranty Text (15-Year Version)
   2.A.3. Guiding Principle: Defining "Workmanship"
   2.A.4. Clause-by-Clause Analysis & Internal Scenarios (15-Year)
   2.B. THE 20-YEAR PREMIUM WORKMANSHIP WARRANTY (DEEP DIVE)
   2.B.1. Trigger Conditions for the 20-Year Warranty
   2.B.2. The Official Full Warranty Text (20-Year Version)
   2.B.3. Rationale for the Extended Term
   2.B.4. Clause-by-Clause Analysis & Internal Scenarios (20-Year)
   2.C. COMMUNICATING THE DUAL-TIER WARRANTY SYSTEM TO CLIENTS
   2.C.1. The "Empowered Choice" Framework
   2.C.2. Scripts for Explaining the Difference
 * SECTION 3: QUOTE & CONTRACT TERMS AND CONDITIONS (DETAILED EXPOSITION)
   3.1. The Official Full Terms & Conditions Text
   3.2. Rationale: Why We Need Comprehensive T&Cs
   3.3. Clause-by-Clause Deep Dive: Rationale, Benefit & Internal Protocol
   3.3.1. Clause 1: Scope of Work & Unforeseen Issues
   3.3.2. Clause 2: Quote Validity (30 Days)
   3.3.3. Clause 3: Variations to the Scope (The Variation Protocol)
   3.3.4. Clause 4: Payment Terms (The Invoicing Protocol)
   3.3.5. Clause 5: Title of Goods & Materials
   3.3.6. Clause 6: Site Access & Conditions
   3.3.7. Clause 7: Work Scheduling & Weather Delays (The Communication Protocol)
   3.3.8. Clause 8: Practical Completion & Handover
   3.3.9. Clause 9: Dispute Resolution (The L.E.A.P. Method)
   3.3.10. Clause 10: Privacy & Use of Images
 * SECTION 4: INSURANCE & COMPLIANCE STATEMENTS
   4.1. The "Fully Insured" Statement: Exposition & Rationale
   4.2. Public Liability Insurance vs. WorkCover: A Clear Distinction
   4.3. Protocol for Providing a Certificate of Currency (CoC)
   4.4. Commitment to VBA & WorkSafe Victoria Standards
 * SECTION 5: APPENDIX
   5.1. Appendix A: Sample Warranty Certificate Templates (15-Year & 20-Year)
   5.2. Appendix B: Internal FAQ for Responding to Client Legal & Warranty Questions
   5.3. Appendix C: The CKR Warranty Claim Processing SOP
SECTION 1: GOVERNING PHILOSOPHY & DOCTRINE
1.1. Principle of "Clarity, Fairness, and Mutual Protection"
The entire legal and warranty framework of Call Kaids Roofing is founded on a single, guiding principle: to create a clear, fair, and mutually protective agreement between our business and our clients. This framework is not designed to be a weapon, a shield of obfuscation, or a collection of "fine print" to trap the unwary. It is a tool for building trust. Its primary purpose is to eliminate ambiguity and set realistic, professional expectations from the very first interaction.
 * Clarity: We commit to using plain English wherever possible, actively avoiding the dense and confusing "legalese" that plagues many contracts. Our terms must be understandable to the average homeowner, our primary client. As per KF_09, our voice is that of the "Expert Consultant," and a true expert can make complex topics simple.
 * Fairness: Our terms are architected to be reasonable and balanced. They protect the client's significant investment by providing one of the industry's best and most transparent workmanship warranty systems. Simultaneously, they protect the business from unfair claims, unforeseen circumstances, and risks that are demonstrably outside of our control.
 * Mutual Protection: A well-defined contract is the foundation of a healthy business relationship; it protects both parties. The client is protected because they have a written record of exactly what they are getting, when they are getting it, for how much, and what guarantees are in place. The business is protected because the scope, payment terms, and operational realities (like weather delays) are documented and agreed upon, preventing disputes arising from mismatched expectations.
1.2. The Role of This Document as the "Single Source of Truth"
This Knowledge File, KF_07, is the sole and absolute source of truth for all warranty text, terms and conditions, and official compliance statements for Call Kaids Roofing. It is the constitutional bedrock for all contractual matters.
Strict Prohibitions and Mandates:
 * No Ad-libbing: No staff member, subcontractor, or AI agent (including CKR-Gem) is ever authorized to invent, alter, paraphrase, or offer their own interpretation of the terms contained within this document. When a client asks what the warranty covers, the answer is in this file and must be used verbatim or via the approved scripts in the Appendix.
 * Written Word is Final: No verbal agreements, promises, or statements that contradict, modify, or add to the official written terms are considered binding. The client must be made aware that all changes to the scope of work must be documented via the formal Variation process (see Section 3.3.3) to be valid.
 * Universal Consistency: This strict adherence ensures that every single client, regardless of the size of their job or who they deal with, receives the same high standard of service and the same set of promises. This eliminates inconsistency, which is a primary driver of disputes and reputational damage.
As CKR-Gem, when you are prompted to generate a quote, draft a contract, or answer a question about our warranties, you must pull the required text verbatim from this document without deviation.
1.3. Protocol for Handling Legal & Warranty Enquiries (Expanded)
When a client or potential client asks a question about the warranty or a specific term in our quote, the following protocol must be followed to ensure a consistent, professional, and risk-managed response.
 * Listen & Clarify: Listen carefully to the client's question to fully understand their specific concern. Is their concern about the duration, the exclusions, or the process? Repeat the question back to them to confirm your understanding (e.g., "So, just to clarify, you're asking what happens if a solar panel installer damages the roof after our work is done?").
 * Consult the Source of Truth (This Document): Do not answer from memory. The answer to almost every common question is contained within the Clause-by-Clause analysis sections or the detailed FAQ in Appendix B of this document.
 * Provide the Standard, Scripted Answer: Use the approved, plain-language explanations and scripts. These have been carefully crafted to be accurate, clear, and aligned with our brand voice.
 * Do Not Give "Advice": This is a critical distinction. We explain our terms; we do not give legal or financial advice. Never offer personal opinions or speculate on hypothetical scenarios not covered by our terms. Stick to explaining what our standard terms mean in a factual, helpful way.
 * Escalate When Necessary: The authority to negotiate or alter contractual terms rests solely with CKR senior management. If a client wishes to propose changes to the standard terms, is raising a complex legal issue, or becomes adversarial, the enquiry must be immediately and politely escalated.
   * Script for Escalation: "That's a very specific legal question, and to be honest, I'm not the right person to give you a definitive answer on that. To ensure you get the correct information, I need to refer this to our director. Can I get them to call you back this afternoon to discuss this point specifically?"
SECTION 2: THE CKR WORKMANSHIP WARRANTIES (DUAL-TIER SYSTEM)
2.A. THE 15-YEAR STANDARD WORKMANSHIP WARRANTY (DEEP DIVE)
2.A.1. Trigger Conditions for the 15-Year Warranty
The 15-Year Standard Workmanship Warranty is our foundational promise of quality. It is automatically applied to all full roof restoration projects that use our standard range of high-quality, approved products, most notably the COAT_PAINT_STD_20L (Premcoat Standard Top Coat) membrane system.
2.A.2. The Official Full Warranty Text (15-Year Version)
OFFICIAL WARRANTY CERTIFICATE TEXT (STANDARD)
Call Kaids Roofing: 15-Year Workmanship Warranty
Call Kaids Roofing (ABN 39475055075) hereby certifies that the workmanship performed at the property located at [Client Address], as detailed in Invoice [Invoice Number] dated [Date of Completion], is guaranteed against defects arising from faulty installation or application for a period of Fifteen (15) Years from the date of completion. This warranty applies to the restoration which utilised the Premcoat standard coating system.
Scope of Coverage: This warranty exclusively covers the workmanship of Call Kaids Roofing. Should a failure occur as a direct result of our application or installation process (our labour), we will, at our discretion, supply the labour and materials required to rectify the faulty workmanship at no cost to the client.
Exclusions: This warranty does not cover:
a) Defects in the roofing products or materials themselves. Such defects are covered by the respective manufacturer's product warranty, which is separate from this workmanship warranty.
b) Damage caused by severe weather events including but not limited to hail, cyclones, extreme winds exceeding local building codes, or impacts from falling trees or other objects ("Acts of God").
c) Damage, whether accidental or intentional, caused by any third party, including other tradespeople (e.g., solar panel installers, antenna installers, plumbers) accessing the roof after our work is complete.
d) Failure or damage resulting from the growth of moss, lichen, or algae, or from a lack of reasonable maintenance by the property owner, including but not limited to keeping gutters and valleys clear of debris.
e) Damage or failure caused by structural movement or defects in the underlying roof structure, trusses, or building foundations.
f) Any pre-existing conditions of the roof or property that were not included in the original scope of work.
Claim Process: To make a claim under this warranty, the property owner must notify Call Kaids Roofing in writing at info@callkaidsroofing.com.au within 14 days of the defect becoming apparent. The owner must provide proof of ownership, the original invoice, and allow our representatives reasonable access to the property to inspect the roof.
Transferability: This warranty is fully transferable to a new owner upon the sale of the property, provided that Call Kaids Roofing is notified in writing of the change in ownership within 30 days of the settlement date.
Limitation of Liability: The liability of Call Kaids Roofing under this warranty is strictly limited to the cost of rectifying the faulty workmanship. We are not liable for any consequential or indirect losses, including but not limited to internal water damage to property, possessions, or loss of rental income. We strongly advise all property owners to maintain a comprehensive home and contents insurance policy.
2.A.3. Guiding Principle: Defining "Workmanship"
It is critical for every CKR team member to understand and be able to articulate this distinction clearly.
 * "Workmanship" is our labour. It is the "how." It's how we clean a roof (SOP-T1), how we prepare a surface, how we apply a sealant (SOP-GR2), how we mix and apply mortar (SOP-T3), and how we apply the coating system (SOP-T4). Our 15-year warranty is a legally binding guarantee that our "how" is to a master standard that will last for a decade and a half.
 * "Materials" are the "what." These are the physical products we use—the paint, the silicone, the tiles, the screws. These products are manufactured by other companies and come with their own, separate product warranties.
If a can of paint is proven to be from a faulty batch and fails, the paint manufacturer is responsible under their product warranty. If that same can of good paint peels because we applied it to a dirty, poorly prepared surface, that is a workmanship failure, and we are 100% responsible for rectifying it under this warranty.
2.A.4. Clause-by-Clause Analysis & Internal Scenarios (15-Year)
 * Clause (a) Exclusions - Material Defects:
   * Scenario: Two years after a restoration, a client's roof develops a strange discolouration. Our inspection reveals the issue is widespread across multiple jobs that used a specific batch of paint. The paint manufacturer subsequently issues a notice of a manufacturing defect.
   * Internal Action: The root cause is a material defect, not workmanship. Our role is to act as the client's advocate. We will assist them in lodging a claim under the manufacturer's product warranty. The cost of rectification is borne by the manufacturer, not CKR.
 * Clause (b) Exclusions - Acts of God:
   * Scenario: A client whose roof we restored four years ago calls in a panic after a severe hailstorm. Their roof has numerous dents (on metal) or smashed tiles.
   * Internal Action: Express empathy, but clearly and politely explain that storm damage is not a workmanship defect. The correct course of action is for them to contact their home insurance provider. We must then offer our services to provide a professional quote to carry out the insurance-approved repairs.
 * Clause (c) Exclusions - Third-Party Damage:
   * Scenario: A client from three years ago calls to claim that their ridge capping is leaking. Our detailed "after" photos from the original job show flawless pointing. When we inspect, we find that a new solar panel system has been installed, and the solar company's installers have broken the ridge caps and cracked the pointing with their boots and brackets right next to their panels.
   * Internal Action: This is the most common and important exclusion. We must professionally present the evidence to the client. Show them our original "after" photos and the new photos showing the damage is localised to the new solar panels. Explain that the damage was caused by a third party and is not a failure of our workmanship. The client needs to contact the solar installation company to rectify the damage they caused. We can offer to quote for the repair if they wish.
 * Clause (d) Exclusions - Lack of Maintenance:
   * Scenario: A client reports a leak in a valley seven years after our restoration. Our inspection shows the valley is completely blocked with a solid mass of leaves, dirt, and sludge from an overhanging tree. This has caused water to dam up and overflow into the eaves.
   * Internal Action: Politely explain that, as per the warranty terms, the homeowner is responsible for reasonable maintenance, which includes keeping gutters and valleys clear of debris. The leak is a direct result of this blockage, not a failure of our work. We will then quote to professionally clear the blockage and repair any resulting damage, but it is not a free warranty claim.
 * Clause (f) Exclusions - Pre-existing Conditions:
   * Scenario: Our scope of work was a full re-bed, re-point, and repaint. Five years later, the client reports a leak. Our inspection traces the leak to a failed, rusted-out chimney flashing that was explicitly noted in our original quote as "needing future attention" but was excluded from the client's approved scope of work to save money.
   * Internal Action: Refer the client back to the original signed quote which clearly documents the exclusion. Explain that our warranty only covers the work we were contracted to perform. We can then provide a new quote to properly repair the now-leaking chimney flashing.
2.B. THE 20-YEAR PREMIUM WORKMANSHIP WARRANTY (DEEP DIVE)
2.B.1. Trigger Conditions for the 20-Year Warranty
The 20-Year Premium Workmanship Warranty is our ultimate promise of quality and durability. It is offered exclusively on full roof restoration projects where the client elects to upgrade to our premium-grade materials, most notably the COAT_PAINT_PREM_15L (Premcoat Plus Premium Top Coat) membrane system. This extended warranty reflects our supreme confidence in the synergy between our master workmanship and these superior, high-performance products.
2.B.2. The Official Full Warranty Text (20-Year Version)
OFFICIAL WARRANTY CERTIFICATE TEXT (PREMIUM)
Call Kaids Roofing: 20-Year Premium Workmanship Warranty
Call Kaids Roofing (ABN 39475055075) hereby certifies that the workmanship performed at the property located at [Client Address], as detailed in Invoice [Invoice Number] dated [Date of Completion], is guaranteed against defects arising from faulty installation or application for a period of Twenty (20) Years from the date of completion. This premium warranty applies to the restoration which utilised the Premcoat Plus premium coating system.
Scope of Coverage: This warranty exclusively covers the workmanship of Call Kaids Roofing. Should a failure occur as a direct result of our application or installation process (our labour), we will, at our discretion, supply the labour and materials required to rectify the faulty workmanship at no cost to the client.
Exclusions: This warranty does not cover:
a) Defects in the roofing products or materials themselves. Such defects are covered by the respective manufacturer's product warranty, which is separate from this workmanship warranty.
b) Damage caused by severe weather events including but not limited to hail, cyclones, extreme winds exceeding local building codes, or impacts from falling trees or other objects ("Acts of God").
c) Damage, whether accidental or intentional, caused by any third party, including other tradespeople (e.g., solar panel installers, antenna installers, plumbers) accessing the roof after our work is complete.
d) Failure or damage resulting from the growth of moss, lichen, or algae, or from a lack of reasonable maintenance by the property owner, including but not limited to keeping gutters and valleys clear of debris.
e) Damage or failure caused by structural movement or defects in the underlying roof structure, trusses, or building foundations.
f) Any pre-existing conditions of the roof or property that were not included in the original scope of work.
Claim Process: To make a claim under this warranty, the property owner must notify Call Kaids Roofing in writing at info@callkaidsroofing.com.au within 14 days of the defect becoming apparent. The owner must provide proof of ownership, the original invoice, and allow our representatives reasonable access to the property to inspect the roof.
Transferability: This warranty is fully transferable to a new owner upon the sale of the property, provided that Call Kaids Roofing is notified in writing of the change in ownership within 30 days of the settlement date.
Limitation of Liability: The liability of Call Kaids Roofing under this warranty is strictly limited to the cost of rectifying the faulty workmanship. We are not liable for any consequential or indirect losses, including but not limited to internal water damage to property, possessions, or loss of rental income. We strongly advise all property owners to maintain a comprehensive home and contents insurance policy.
2.B.3. Rationale for the Extended Term
The 20-year term is a strategic offering designed to provide ultimate peace of mind and cater to the "quality-conscious" segment of our client base. The premium materials, such as Premcoat Plus, have demonstrably superior characteristics in terms of UV resistance, gloss retention, and pollution resistance. By pairing these top-tier products with our unwavering commitment to the CKR Standard of workmanship, we can scientifically and ethically extend the guarantee on our labour from 15 to 20 years.
2.B.4. Clause-by-Clause Analysis & Internal Scenarios (20-Year)
The meaning, interpretation, and application of all clauses (Scope, Exclusions, Claim Process, etc.) are identical to those of the 15-year warranty. The only variable is the duration.
 * Scenario: A client who opted for the premium package calls after 18 years. They report that the paint on their roof is peeling.
 * Internal Action: The claim is within the 20-year warranty period. We must initiate the full claim investigation process as per Appendix C. If our inspection determines that the peeling is due to a failure in our original surface preparation (a clear workmanship issue), we are obligated to rectify the problem at our own cost, even though 18 years have passed. This is the power and promise of our premium warranty. If the inspection determines the failure is due to a third party, lack of maintenance, or another exclusion, the exclusion clauses apply just as they would under the 15-year warranty.
2.C. COMMUNICATING THE DUAL-TIER WARRANTY SYSTEM TO CLIENTS
2.C.1. The "Empowered Choice" Framework
The dual-tier system should not be presented as a simple "good vs. best" option. It must be framed as an empowered choice for the client, allowing them to select the level of long-term protection that best suits their budget and their plans for the property. Both options deliver a fantastic, professional result. The choice is about the long-term investment.
2.C.2. Scripts for Explaining the Difference
 * Initial Presentation: "Based on our inspection, we've prepared two options for your full roof restoration. Both options involve the exact same meticulous preparation and repair process—the cleaning, the ridge capping restoration, all of that is done to our master standard on every job. The only difference is the final two top coats of the membrane we apply."
 * Explaining the Standard Option: "Our Standard option uses the excellent Premcoat membrane system. It provides fantastic protection and a beautiful finish, and the workmanship on that is backed by our comprehensive 15-year warranty."
 * Explaining the Premium Option: "Our Premium option uses the upgraded Premcoat Plus membrane. This has a higher acrylic content, giving it superior resistance to UV damage and pollution, so it holds its colour and gloss for longer. Because we are using this premium material, we are able to extend our workmanship warranty to a full 20 years, giving you the ultimate long-term peace of mind. The choice is entirely yours, depending on your long-term plans for the house."
SECTION 3: QUOTE & CONTRACT TERMS AND CONDITIONS (DETAILED EXPOSITION)
3.1. The Official Full Terms & Conditions Text
This text, or a direct link to it on our website, must be included on every quote and formal agreement provided to a client.
OFFICIAL TERMS & CONDITIONS TEXT
 * Scope of Work: The price quoted is based on the Scope of Work detailed in this document, following a visual inspection of the property. It is subject to any unforeseen issues discovered after work has commenced (e.g., significant timber rot, broken tile cuts, or sarking damage not visible during the initial inspection).
 * Quote Validity: This quote is valid for a period of thirty (30) days from the date of issue. We reserve the right to review and re-price after this period to account for changes in material costs.
 * Variations: Any variation to the agreed Scope of Work, whether requested by the client or made necessary by the discovery of unforeseen issues, must be documented in a written Variation and approved by the client before the additional work is performed. Variations will be charged for accordingly.
 * Payment Terms: A deposit may be required prior to the ordering of materials or commencement of work. The full balance is due strictly within seven (7) days of the date of the final invoice, which will be issued upon practical completion.
 * Title of Goods: All materials supplied and installed by Call Kaids Roofing remain the property of Call Kaids Roofing until the final invoice has been paid in full.
 * Site Access & Conditions: The client shall provide clear, safe, and uninterrupted access to the work site, including access to power and water, for the duration of the project. The client is responsible for securing any pets and for clearing any personal items from the immediate work area.
 * Work Scheduling & Weather Delays: All work is scheduled subject to weather conditions. We reserve the right to postpone work at any time in the event of rain, high winds, or other unsafe conditions. Any timelines provided are good-faith estimates and not a binding guarantee, as they are subject to weather and other unforeseen delays.
 * Practical Completion: The project is deemed to be at "practical completion" when it is complete except for minor omissions or defects that do not prevent the roof from being used for its intended purpose. The final invoice will be issued at this stage.
 * Dispute Resolution: In the unlikely event of a dispute, both parties agree to communicate in good faith to resolve the matter directly before pursuing any external legal or tribunal action.
 * Privacy & Use of Images: We respect your privacy. We may take photographs ("before," "during," and "after") of the work for our internal quality assurance, and for our external marketing purposes. These images will be used in a way that does not identify the specific property address or its occupants unless explicit permission is granted.
3.2. Rationale: Why We Need Comprehensive T&Cs
These terms form the backbone of our contract with the client. They exist to prevent misunderstandings by creating a clear, mutually agreed-upon framework for how the project will be executed. They proactively manage expectations around the most common sources of conflict in the trade industry: unforeseen issues, weather delays, payment schedules, and changes to the scope. A client who has read and agreed to these terms is an informed client, leading to a smoother, more professional project for all parties.
3.3. Clause-by-Clause Deep Dive: Rationale, Benefit & Internal Protocol
3.3.1. Clause 1: Scope of Work & Unforeseen Issues
 * Rationale: We can only quote what we can see. A roof inspection, no matter how thorough, is non-destructive. We cannot know the condition of the timber battens under the ridge capping until we physically lift it. This clause protects us from being financially responsible for repairing pre-existing, hidden defects.
 * Client Benefit: This is also a benefit to the client. It ensures they are only paying for the work their roof actually needs. It prevents us from adding a huge "contingency" buffer to every quote to cover what might be there. The process is transparent.
 * Internal Protocol: If an unforeseen issue is discovered, the on-site team must STOP WORK immediately in that area. They must take clear photographic evidence. They must contact the Project Manager. A formal Variation must be raised as per the protocol in 3.3.3.
3.3.2. Clause 2: Quote Validity (30 Days)
 * Rationale: The price of our key materials—paint, metal, cement—can fluctuate. This clause protects us from being locked into a price from six months ago when material costs may have risen significantly.
 * Client Benefit: This provides the client with a guaranteed price for a reasonable decision-making period, protecting them from unexpected price rises within that 30-day window.
 * Internal Protocol: If a client accepts a quote that is older than 30 days, the system should flag it for review. The administrator must quickly re-confirm the current cost of materials in KF_02 and inform the client politely if a revised quote is necessary.
3.3.3. Clause 3: Variations to the Scope (The Variation Protocol)
 * Rationale: This is one of the most critical clauses for maintaining profitability and professionalism. It prevents "scope creep"—the series of small, undocumented requests from a client that can add hours of unbilled time to a job.
 * Client Benefit: This protects the client from surprise charges on their final bill. They will have a clear, written record of every change they approved and its associated cost. It ensures total transparency.
 * Internal Protocol:
   * The need for a variation is identified (either by client request or unforeseen issue).
   * The on-site team communicates the need to the office.
   * The office generates a formal, written Variation document, detailing the additional work and the precise cost.
   * This document is emailed to the client for their review and approval.
   * The team must receive written approval (a reply email stating "I approve" is sufficient) from the client before a single moment of work on the variation begins. Verbal approval is not sufficient.
3.3.7. Clause 7: Work Scheduling & Weather Delays (The Communication Protocol)
 * Rationale: Roofing is 100% weather-dependent. We cannot apply products in the rain or work safely in high winds. This clause sets the realistic expectation from the outset that our schedule is a plan, not an unbreakable promise.
 * Client Benefit: The client is assured that we will not compromise the quality of their job (or the safety of our team) by trying to "push through" in bad weather.
 * Internal Protocol: Proactive communication is key. The team must monitor the forecast diligently. As per Mandate A in KF_10, we must identify at-risk jobs. If a job is likely to be impacted by weather, we must contact the client the day before if possible, or at the earliest opportunity on the day.
   * Script: "Hi [Client Name], it's [Name] from CKR. I'm looking at the forecast for tomorrow, and unfortunately, it's showing heavy rain from 10 am. For the quality of the paint finish and for safety, we won't be able to proceed. I'd like to reschedule you for the next available clear day, which looks to be Thursday. Does that work for you?"
SECTION 4: INSURANCE & COMPLIANCE STATEMENTS
4.1. The "Fully Insured" Statement: Exposition & Rationale
 * The Statement: "We are a fully insured business."
 * What it Means: This statement is a formal declaration that Call Kaids Roofing maintains a current and comprehensive Public Liability Insurance policy with a reputable Australian insurer.
 * Rationale: This is one of our most powerful trust signals (Rule 5 in KF_01). It instantly differentiates us from unprofessional, uninsured operators. It communicates to the client that we are a serious, professional business that takes risk management and client protection seriously. It tells them that in the unlikely event of an accident caused by our actions that results in damage to their property or injury to a person, there is a multi-million dollar insurance policy in place to cover the costs, protecting them from any financial liability.
4.2. Public Liability Insurance vs. WorkCover: A Clear Distinction
It is important for the team to understand the difference.
 * Public Liability Insurance: Protects the "public" from our actions. It covers third-party property damage (e.g., we drop a tool and smash their skylight) and third-party personal injury (e.g., a member of the public is injured by falling debris).
 * WorkCover Insurance: Protects our own team. It covers wages and medical expenses for our employees or certified subcontractors if they are injured while working on the job.
 * We must maintain current policies for both.
4.3. Protocol for Providing a Certificate of Currency (CoC)
 * When is it Needed: While not always requested for standard residential jobs, a CoC is frequently and legitimately requested by body corporates, strata managers, commercial property owners, and some particularly diligent residential clients. It is a standard business practice to provide one upon request.
 * The Protocol:
   * Acknowledge the client's request politely and confirm you will provide it.
   * Contact our designated insurance broker via their preferred method (email or online portal).
   * Request a Certificate of Currency be generated for the specific client/property address. This is important as it shows the policy is active for their project.
   * The broker will email back an official, digitally signed PDF of the CoC.
   * Forward this official PDF to the client without alteration.
   * Crucially: Never attempt to create, modify, or use an old CoC. It must be a fresh one generated for each request.
4.4. Commitment to VBA & WorkSafe Victoria Standards
 * Our Stance: Call Kaids Roofing is unconditionally committed to upholding all relevant standards, codes of practice, and regulations set forth by the Victorian Building Authority (VBA) and WorkSafe Victoria.
 * Practical Application: This is not just a statement; it's an operational mandate. It means all our work complies with the relevant building codes. All our team members are appropriately trained and ticketed. All our job sites are run in accordance with WorkSafe guidelines for risk management, especially concerning working at heights. This commitment to compliance is a core pillar of our professionalism and a key reason why clients can trust our work and our warranties.
SECTION 5: APPENDIX
5.1. Appendix A: Sample Warranty Certificate Templates
(This appendix would contain two distinct, professionally formatted A4 page layouts. One titled "15-Year Standard Workmanship Warranty Certificate" and the other "20-Year Premium Workmanship Warranty Certificate." Each would feature the CKR logo, and fields for Client Name, Address, Invoice Number, and Date of Completion, and would contain the full, respective warranty text from Section 2.A.2 and 2.B.2.)
5.2. Appendix B: Internal FAQ for Responding to Client Legal & Warranty Questions
 * Q: "Why isn't internal water damage covered by your warranty? If your repair leaks, surely you should fix my ceiling."
   * A: "That's a very fair question. Our workmanship warranty covers the cost of fixing our own work—the source of the problem on the roof. The liability for any resulting internal damage, which is known as 'consequential loss,' is covered by your home and contents insurance policy. This is a standard distinction in the building industry, as we are roofing contractors, not home insurers. Our promise is to come back and fix our work promptly at our cost, so the problem doesn't continue."
 * Q: "What happens if I sell my house in 10 years? Is the warranty still valid?"
   * A: "Absolutely. That's one of the great benefits of our warranty. It's fully transferable to the new owner. All you need to do is notify us in writing of the sale within 30 days of the settlement, and we'll transfer the remaining years of the warranty to the new owner's name. It's a fantastic value-add for your property."
 * Q: "Your exclusion for 'lack of maintenance' seems a bit vague. What do you consider 'reasonable maintenance'?"
   * A: "We see 'reasonable maintenance' as simple, common-sense tasks a homeowner would do to look after their property. The main one is ensuring gutters and valleys are kept reasonably clear of heavy leaf and debris build-up, especially if you have large trees nearby. A blockage that causes water to dam up and overflow isn't a failure of the roof itself. Other than that, there's very little you need to do."
5.3. Appendix C: The CKR Warranty Claim Processing SOP
 * [LOG] Claim Received: Client makes contact in writing (email) as per the warranty terms. The claim is logged in our system with date, client details, and the nature of the claim.
 * [ACKNOWLEDGE] Formal Acknowledgement (within 24 hours): Send a confirmation email to the client using a standard template. "Hi [Client Name], thank you for contacting us. We have received your warranty claim request regarding [issue] at [address]. We take this very seriously. A member of our team will be in touch within the next business day to schedule an on-site inspection."
 * [VERIFY] Internal Verification: Check the client's records to confirm they are within their correct warranty period (15 or 20 years). Pull up the original job folder, including all "before," "during," and "after" photos.
 * [SCHEDULE] Book Inspection: Contact the client to book a suitable time for a CKR senior technician or manager to attend the site and inspect the issue.
 * [INSPECT] On-Site Inspection & Evidence Gathering:
   * Conduct a thorough inspection of the reported issue.
   * Take extensive new photographic evidence of the problem area from multiple angles.
   * Critically, compare the current state of the roof to the original "after" photos. Look for any changes (e.g., new antennas, solar panels, storm damage).
 * [ASSESS] Root Cause Analysis:
   * Based on the evidence, determine the root cause of the failure.
   * Is it a workmanship issue covered by our warranty (e.g., peeling paint due to poor prep, cracked pointing)?
   * Is it an excluded issue (e.g., third-party damage, storm damage, lack of maintenance)?
 * [COMMUNICATE] Formal Outcome Communication:
   * Step 1 (Phone Call): Call the client to explain the findings clearly and professionally.
   * Step 2 (Email): Follow up with a formal email summarizing the outcome for their records.
   * If Approved: The email will state, "Our inspection has confirmed that this issue is a result of faulty workmanship and is covered under your CKR warranty. We will rectify this at no cost to you." Outline the proposed rectification plan and schedule the work.
   * If Denied: The email will clearly and politely explain why the issue is not covered, referencing the specific exclusion clause and attaching the photographic evidence. "Our inspection found that the leak is due to [e.g., a broken ridge cap directly under a newly installed solar panel bracket]. As per clause (c) of your warranty, damage caused by third parties is excluded. We have attached photos from our original job completion and from today's inspection for your reference."
 * [RECTIFY] Schedule & Perform Rectification Work (If Approved):
   * Perform the required repairs to the full CKR Standard as per the relevant SOPs.
   * Take new "after" photos of the rectified work.
 * [CLOSE] Close the Claim File:
   * Obtain client sign-off or verbal confirmation that the issue has been resolved to their satisfaction.
   * Update the client's file with a full, detailed record of the claim, the inspection findings, the communication, and the rectification work performed.
