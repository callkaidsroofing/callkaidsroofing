KNOWLEDGE FILE: GWA_FILE_02_JOB_ACTIVATION.md
| GWA ID: GWA-02 | GWA Name: Job Activation & Onboarding |
|---|---|
| Version: 1.0 | Last Updated: 2025-10-08 |
| Owner: CKR Operations | Status: Active |
SECTION 1: GWA OVERVIEW
1.1. Objective
To streamline the administrative tasks required when a client accepts a quote, seamlessly transitioning the project from a 'Quoted' opportunity to an 'Active' job in the production schedule and client management systems.
1.2. Trigger Mechanism
 * Primary Trigger: A user command, such as "Client has accepted quote [ID]," "Run GWA-02 for [Client Name]."
 * Autonomous Trigger: Can be configured to monitor the inbox for replies to quote emails and automatically trigger upon detecting clear acceptance language (e.g., "we accept," "please proceed").
1.3. Success Metrics
 * Activation Time: Time from trigger to all tasks generated and draft email ready < 3 minutes.
 * Data Consistency: Project status updated correctly across all linked systems (e.g., Project Tracker, Calendar).
SECTION 2: TECHNICAL SPECIFICATION (LangChain Agent)
2.1. Agent Name: jobActivationAgent
2.2. Required Tools:
 * @Gmail (Read, Create Draft)
 * @Google Drive (Read/Write access to master project tracker sheet)
 * @Utilities (Task management system API, e.g., Google Tasks, Asana)
2.3. Input Schema:
 * { "quoteId": "string", "clientName": "string" }
2.4. Output Schema:
 * { "status": "Success", "jobId": "string", "gmailDraftId": "string", "tasksCreated": ["task1_id", "task2_id"] }
SECTION 3: LOGICAL WORKFLOW (CHAIN OF THOUGHT)
 * START: Receive quoteId and clientName as input.
 * TOOL CALL (@Google Drive): Access the master project tracker (Google Sheet). Locate the row corresponding to the quoteId.
 * DATA UPDATE: Change the status column for that row from 'Quoted' to 'Accepted'.
 * RESPONSE GENERATION: Access KF_09 to retrieve the "Job Confirmation & Scheduling" email template. Populate it with the client's details and propose a tentative start date based on the next available slot in the master schedule.
 * TOOL CALL (@Gmail): Create a new draft email with the generated confirmation and scheduling message.
 * TASK GENERATION: Access KF_10 (Appendix) or this file's logic for the standard onboarding task list.
 * TOOL CALL (@Utilities): Programmatically create the following tasks in the project management system, assigned to the Project Manager:
   * "Call [Client Name] to confirm the tentative start date and discuss site access."
   * "Order required materials from quote [quoteId] bill of materials."
   * "Schedule subcontractor [Subcontractor Name] for [Task] on [Date]."
 * END: Return the final JSON output, confirming job activation and providing the ID for the draft email and the list of created tasks.
SECTION 4: DEPENDENCIES & INTEGRATIONS
 * Required Knowledge Files: KF_09 (for email templates), KF_02 (to inform the material order task).
 * Downstream GWA Triggers: Can potentially trigger GWA-08: Subcontractor Briefing Package Assembly if a subcontractor is required.
SECTION 5: ERROR HANDLING & FALLBACKS
| Step | Error Condition | Fallback Action |
|---|---|---|
| 2 | quoteId not found in project tracker. | Halt workflow. Alert user: "Error: Quote ID [quoteId] not found in the master project tracker. Please verify the ID." |
