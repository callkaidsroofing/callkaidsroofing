KNOWLEDGE FILE: GWA_FILE_01_LEAD_INTAKE.md
| GWA ID: GWA-01 | GWA Name: New Lead Intake & Triage |
|---|---|
| Version: 1.0 | Last Updated: 2025-10-08 |
| Owner: CKR Operations | Status: Active |
SECTION 1: GWA OVERVIEW
1.1. Objective
To automate the initial processing of a new client enquiry from the moment it arrives, ensuring every lead is triaged for urgency, has its data captured, and receives a professional, templated response within minutes.
1.2. Trigger Mechanism
 * Primary Trigger: A user command, such as "Process this new lead from [email subject]," "Run GWA-01 on the latest email," or simply "New lead."
 * Autonomous Trigger: Can be initiated by Mandate A: Daily Operational Briefing when it identifies new overnight leads.
1.3. Success Metrics
 * Time to First Contact: Time from email arrival to draft response ready for sending (< 5 minutes).
 * Data Entry Accuracy: 100% accuracy in parsing client name, address, and phone number.
 * Error Rate: < 1% of workflows requiring manual intervention.
SECTION 2: TECHNICAL SPECIFICATION (LangChain Agent)
2.1. Agent Name: newLeadProcessingAgent
2.2. Required Tools:
 * @Gmail (Read, Create Draft)
 * @Google Drive (Search, Create Folder, Save File)
 * @Utilities (Satellite Imagery Search)
 * gemini_classifier (Internal tool for sentiment/intent analysis)
2.3. Input Schema:
 * { "emailId": "string" }
2.4. Output Schema:
 * { "status": "Success", "clientId": "string", "driveFolderUrl": "string", "gmailDraftId": "string", "triageSummary": { "urgency": "string", "sentiment": "string" } }
SECTION 3: LOGICAL WORKFLOW (CHAIN OF THOUGHT)
 * START: Receive emailId as input.
 * TOOL CALL (@Gmail): Read the full content of the specified email. Extract sender, subject, and body text.
 * ENTITY EXTRACTION: Parse the email body for key entities: Client Name, Address, Phone Number, and a summary of the request.
 * TOOL CALL (gemini_classifier): Pass the email body to the classifier to execute Directive Delta. Receive a structured JSON object defining the lead's urgency, sentiment, and primary concern.
 * TOOL CALL (@Google Drive): Search the Clients/ directory for an existing folder matching the parsed Client Name and Address.
 * CONDITIONAL LOGIC:
   * IF a folder exists, retrieve its URL.
   * ELSE, create a new standardized folder Clients/[Client_Name]_[Address] and retrieve its URL.
 * TOOL CALL (@Utilities): Perform a satellite imagery search using the parsed Address.
 * TOOL CALL (@Google Drive): Save the retrieved satellite image to the client's folder as [Address]_Satellite_View.jpg.
 * CONTEXT ASSEMBLY: Consolidate all retrieved data (client details, triage results, Drive URL, etc.) into a context block.
 * RESPONSE GENERATION: Pass the context block to the Generative Core. Prompt it to select the most appropriate template from KF_09 based on the triage results and draft a response acknowledging the client's request and noting the preliminary satellite review.
 * TOOL CALL (@Gmail): Create a new draft email with the generated response.
 * END: Return the final JSON output object to the user, confirming completion and providing direct links to the created assets.
SECTION 4: DEPENDENCIES & INTEGRATIONS
 * Required Knowledge Files: KF_09 (for email templates), KF_01 (for brand compliance validation).
 * Downstream GWA Triggers: None. This is a primary intake workflow.
SECTION 5: ERROR HANDLING & FALLBACKS
| Step | Error Condition | Fallback Action |
|---|---|---|
| 3 | Cannot parse address from email. | Halt workflow. Create a task for the user: "Unable to determine address for new lead from email [Subject]. Manual review required." |
| 7 | Address not found in satellite imagery. | Continue workflow but add a note to the draft email: "Note: A preliminary satellite view was not available for your property." |
